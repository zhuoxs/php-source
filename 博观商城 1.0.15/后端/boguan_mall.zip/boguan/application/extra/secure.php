<?php
/**
 * Created by Boguan.
 * User: leo
 * WebSite: http://www.boguanweb.com
 * Date: 2018-3-24
 * Time: 15:32
 */
return [
    'token_salt'=> 'boguanwebleo',

    //Ngrok
];