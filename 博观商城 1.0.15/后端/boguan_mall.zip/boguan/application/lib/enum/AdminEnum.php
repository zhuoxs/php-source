<?php
/**
 * Created by PhpStorm.
 * User: leolu
 * Date: 2018/8/27
 * Time: 22:44
 */

namespace app\lib\enum;


class AdminEnum
{
    const User = 0;
    //cms管理员权限数值
    const Super = 1;


}