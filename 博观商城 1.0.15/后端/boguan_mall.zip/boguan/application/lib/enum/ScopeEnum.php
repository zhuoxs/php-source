<?php
/**
 * Created by Boguan.
 * User: leo
 * WebSite: http://www.boguanweb.com
 * Date: 2018-3-26
 * Time: 17:49
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;
    //cms管理员权限数值
    const Super = 32;

}