<?php
/**
 * Created by PhpStorm.
 * User: leolu
 * Date: 2018/8/7
 * Time: 22:40
 */

namespace app\lib\enum;


class UserEnum
{
    //普通用户
    const Normal = 0;
    //店长
    const Manager = 1;
    //员工
    const Staff = 2;
    //业务员
    const Salesman = 3;
    //会员
    const Vip = 4;


}