<?php
 namespace app\api\validate; class User extends BaseValidate { }