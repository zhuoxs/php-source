<?php
 namespace app\api\service; class Base { }