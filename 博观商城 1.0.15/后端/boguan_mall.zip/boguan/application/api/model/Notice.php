<?php
 namespace app\api\model; class Notice extends BaseModel { }