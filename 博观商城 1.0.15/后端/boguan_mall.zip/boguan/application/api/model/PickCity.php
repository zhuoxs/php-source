<?php
 namespace app\api\model; class PickCity extends BaseModel { }