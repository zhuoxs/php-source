<?php
 namespace app\api\model; class Promise extends BaseModel { }