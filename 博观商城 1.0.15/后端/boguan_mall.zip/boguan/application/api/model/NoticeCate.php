<?php
 namespace app\api\model; class NoticeCate extends BaseModel { }