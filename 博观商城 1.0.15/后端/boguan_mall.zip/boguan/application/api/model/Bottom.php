<?php
 namespace app\api\model; class Bottom extends BaseModel { }