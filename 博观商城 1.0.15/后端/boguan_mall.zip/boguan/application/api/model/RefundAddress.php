<?php
 namespace app\api\model; class RefundAddress extends BaseModel { }