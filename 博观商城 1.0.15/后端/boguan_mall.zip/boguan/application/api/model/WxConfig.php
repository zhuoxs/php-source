<?php
 namespace app\api\model; class WxConfig extends BaseModel { }