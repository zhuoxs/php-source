<?php
 namespace app\api\model; class UserAddress extends BaseModel { protected $hidden = array("\x64\x65\x6c\x65\x74\x65\137\164\x69\155\x65"); }