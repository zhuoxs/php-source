<?php
 namespace app\api\model; class Vip extends BaseModel { }