<?php
 namespace app\api\model; class UserBalance extends BaseModel { }