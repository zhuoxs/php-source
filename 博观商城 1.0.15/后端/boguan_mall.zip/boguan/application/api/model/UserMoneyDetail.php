<?php
 namespace app\api\model; class UserMoneyDetail extends BaseModel { }