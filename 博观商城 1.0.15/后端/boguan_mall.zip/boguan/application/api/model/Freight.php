<?php
 namespace app\api\model; class Freight extends BaseModel { }