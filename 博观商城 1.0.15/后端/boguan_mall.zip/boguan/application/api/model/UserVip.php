<?php
 namespace app\api\model; class UserVip extends BaseModel { }