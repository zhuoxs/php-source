<?php
 namespace app\api\model; class AttrValue extends BaseModel { }