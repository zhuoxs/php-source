<?php
 namespace app\api\model; class Help extends BaseModel { }