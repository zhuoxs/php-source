<?php
 namespace app\api\model; class Home extends BaseModel { }