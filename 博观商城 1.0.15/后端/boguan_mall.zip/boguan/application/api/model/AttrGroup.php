<?php
 namespace app\api\model; class AttrGroup extends BaseModel { }