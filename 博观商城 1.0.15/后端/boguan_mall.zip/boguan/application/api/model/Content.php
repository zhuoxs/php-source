<?php
 namespace app\api\model; class Content extends BaseModel { protected $dateFormat = "\131\x2d\x6d\x2d\144"; }