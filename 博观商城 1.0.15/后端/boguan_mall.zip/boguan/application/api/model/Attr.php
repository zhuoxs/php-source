<?php
 namespace app\api\model; class Attr extends BaseModel { }