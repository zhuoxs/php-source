<?php
/**
 * Created by Boguan.
 * User: leo
 * WebSite: http://www.boguanweb.com
 * Date: 2019-4-10
 * Time: 10:45
 */

namespace app\general\controller;


use think\Controller;

class Base extends Controller
{

}