<?php
 namespace app\boguan\model; class PublicUser extends BaseModel { }