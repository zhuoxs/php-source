<?php
 namespace app\boguan\model; class PickCity extends BaseModel { }