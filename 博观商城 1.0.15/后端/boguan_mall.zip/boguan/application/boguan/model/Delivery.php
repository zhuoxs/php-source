<?php
 namespace app\boguan\model; class Delivery extends BaseModel { }