<?php
 namespace app\boguan\model; class Attr extends BaseModel { }