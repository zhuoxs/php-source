<?php
 namespace app\boguan\model; class SmsSet extends BaseModel { }