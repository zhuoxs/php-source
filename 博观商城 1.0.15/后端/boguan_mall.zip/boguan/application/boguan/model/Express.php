<?php
 namespace app\boguan\model; class Express extends BaseModel { }