<?php
 namespace app\boguan\model; class PublicSettings extends BaseModel { }