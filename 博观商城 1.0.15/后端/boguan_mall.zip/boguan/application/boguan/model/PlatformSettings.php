<?php
 namespace app\boguan\model; class PlatformSettings extends BaseModel { }