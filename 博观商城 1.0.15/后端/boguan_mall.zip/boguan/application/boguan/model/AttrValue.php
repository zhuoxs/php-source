<?php
 namespace app\boguan\model; class AttrValue extends BaseModel { protected $createTime = false; }