<?php
 namespace app\boguan\model; class Video extends BaseModel { }