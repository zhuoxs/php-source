<?php
 namespace app\boguan\model; class AttrGroup extends BaseModel { }