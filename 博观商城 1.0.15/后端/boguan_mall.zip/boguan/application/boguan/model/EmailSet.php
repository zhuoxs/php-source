<?php
 namespace app\boguan\model; class EmailSet extends BaseModel { }