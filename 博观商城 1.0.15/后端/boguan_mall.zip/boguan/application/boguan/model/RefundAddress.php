<?php
 namespace app\boguan\model; class RefundAddress extends BaseModel { }