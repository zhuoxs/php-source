<?php
 namespace app\boguan\model; class UserAccess extends BaseModel { }