<?php
 namespace app\boguan\model; class Promise extends BaseModel { }