<?php
 namespace app\boguan\model; class Vip extends BaseModel { }