<?php
 namespace app\boguan\model; class Bottom extends BaseModel { }