<?php
 namespace app\boguan\model; class Home extends BaseModel { }