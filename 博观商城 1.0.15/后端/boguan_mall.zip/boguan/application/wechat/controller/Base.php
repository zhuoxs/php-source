<?php
/**
 * Created by Boguan.
 * User: leo
 * WebSite: http://www.boguanweb.com
 * Date: 2019-4-1
 * Time: 15:45
 */

namespace app\wechat\controller;


use think\Controller;

class Base extends Controller
{

}