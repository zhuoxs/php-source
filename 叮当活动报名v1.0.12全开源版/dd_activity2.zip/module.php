<?php
/**
 * dd_activity2模块定义
 *
 * @author 易福网
 * @url
 */
defined('IN_IA') or exit('Access Denied');

class Dd_activity2Module extends WeModule {



}