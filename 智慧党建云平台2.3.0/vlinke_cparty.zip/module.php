<?php
/**
 * 智慧党建云平台
 *
 * @author xiechunbing 732680577
 * @url http://bbs.we7.cc/
 */
defined('IN_IA') or exit('Access Denied');

class Vlinke_cpartyModule extends WeModule {


}