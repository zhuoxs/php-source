<?php //ICB0 56:0 71:dc1                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPxah3Hd3zlLUyPoOEfQPm67Gq849jSY5XDEfjd5X47XD12gYpylgDzlEcoEse0RUqtzkx7D1
ds9bWDBgMD6Q59dHAO6e7dGTSijKxraJ34WpekBzcOhaEA5SnGh+UxUKfoonifnqm0SFxlDloiqk
xkGH/fFognEd+prfYtMYa+GjptB+HbCZQ3TKQ8pKXKRnBkCLLsVsFZA9bM95/vZJiprgRr6u28Qa
9Oc6YRWrO+muSuW6lsxp6yXv8mvrvEieP7dyKRSfNHv7zDAjQeBUR0eYwa6IOajrmpsQ1KV0IhH4
9x132s8aYpWus+fWE4faUFkSNlGGxCzL8v1FO83pLao8JNQWhCvjrtv2wyNuj4la7PhszScaZcrv
dz43cGinsTUQitYSKRBqnKgkwlSGLle1ilOTiTV1kF6YMYXS7oehBAwHW7GKPrKVptBpbl+D/u7/
a/z65iFtg+89jO4Z/DnrQaTyTy2l/zuakyA6GnMOVSXT8Y8hWI8Z3qSvvrRhwFpCU1yLwmB8YBJj
BwrNR8cz3TC8fqfg8eb9kYt27cbShwEinNuumwyrt+zBpq/MUZEwuHT/1zIa/3Kg3TwtemRHPLp7
/7pSjKZPiU8zKeDIQEpb4JFsearDtl7OcwuIBrIMHnONHBTl2T/AMyAtVErrUtjbierbLzavn6bB
mjVtO5N1SQc1hZ5O6A5tXGNnVQiPfJ5me8pjuzDr7gTWX4321vWrVmN19FJkef/W6U3+El5jSsRe
PRpkQZVms9NX/U7M9dtC1wFguekrHayvqeNnEr92B/mz3PFw4TSKxsTUXbGLSc5v0D+Zu2fnGVdU
UgPQZF5lrEBv8rC5tKGrr/4nDCD7afkaQStW5FN/SXMsCa5gn+A9EmBc3Yzj0JHrBlHBuKVgiOPI
mP9iyVJYd4tTAmsSdIBvA3Kr8JePZ+xIztTHewWI/pSUs6WNrYMeoZJu2+Jdtb4n8zsfvh5MM4TF
A6TNR1DllKcVDMs6q7+l+SmFSoK34UY7gkkpKoxexTg201DlkzZqrJAnMNGqM63/rLMj861PK5ON
f9URypSnTcOYAVqno7EYOmMU55AZIsakGDhhWQXC77FjGq2Ln0Rf1UnQOAmxMJKzf0bmC9fyHBfY
kzDOxVqpGcGMWOUbeadDFbDMFdIyc46+0WjpnDzSY/bdfRF8+bhIlYL6Q3Pl739ZqxvvI3VgX3L0
5fwmkte02/5aUoXegqdLEMp4Jbh5vxMFCVbmlQ0SdYqxJx84JFsuB7jIttYSfHAH8tRD/ilbf9ZV
PumHK9BhGjTVQq9opvCtToM/3REIdXu+3FiddcFgDxDid0Ns1YRjYlN9NapetUqL7l3on4vy21Hd
yrnnwe1kkslPR9DePt3uec4gLVLxTG5R+dTnsttPA39hNzA7P222XqDiMSRrLQjVTmEPGbZO+kkp
EBwQjn+4P37FpVXKt0cjXETSvxSAroOzjPPaTJ4uMAEwiaMwTvQkhPdPwuvmdODJGuppAiZSV2bD
Z1WCC5NjmzW6PuI2UoNC4ljzFh6ZjN79aes2iFnoYe0qOnYuE+8ppuYBMrqA3boQ1Z3wENqRIGF3
9iIg6ulCJfSq2pqUTgWc4QQvAlgx7p/mo4hJXJ/0HmMJ45OM7LiorO9Dx0VDx8tLZYqHx4g0UXAp
yhqgB/0kNsCDCVpZ/m88sJ/1WbCcuJP5oMIf2EPg6z8MW/O9xfKHKWaWbQVLOl48eDC32MO14hKA
Y+1oLuDM3FKTkhjs3d5Kp3+RjjiezZ+wtDcRzmU/s81RCn3bydGKKF4E3lgfGo0DT4NLrcoCpoQe
/gaPbMoDLZPj7gF7YiBF8oIL1YAtcc+E8KWm++LB/oK4qFnCjYT7BC9rTxX+U/cn46pdtVCB97CB
v5Rma7lwFfi7ixbrvdis4o89PXU6rkegk7XpCZ8uGl2OgBX/zdN+vZ7JX6GPAShwfI7a2rf8Jihf
PXjEDEIf3oPsZKa+U2DKQvY4/nWwxmgvQJEkVf9T+mJyZ0GGOf3tN8VAyZEI8navtDOqyEReX3Iw
sXfKo2JT4t2JDyrzwfZSHM4tRCyXGiPQ22bWinj6WYSK4AOPYYCsJMClIYRzc8EKC7bg6p48okTL
KVYNaPZytTVW1h1lTA28zfppgRbF+BINY5ars7go/dU7aPlcxXu7JYrCuOVgpYiIgoX8G2qeet2o
K4dPS5Rw0tljjRIy9DC==
HR+cPrwcZCO/S7NfhHuPvSzNoxP35k1ayTGrgkC+fz45S8fyhWYqsTseoXqnENHdwQMX1eob3yVE
PCfCYPR+lyAsrDYT5Yb0wDahPxNqvpBt3bG74XOXRxvQvkpoDAUE4IlNMbuCy6Ol30wbIbsj/uqM
0afLTWbx60GGOBosRApl0yIMn3Bc53ePjENjEvCSU9Q6N/rEhaJWFrZsPemrccutbmV+6iUIidVh
OWNtLbI+p5+a2F2UzAtJra3j8G/xeaXBSUsZIr7v6p5bZAJmeC1aNrjmEPVGVxO5RvjBQj/hBh16
BjFuaFI+Ygu4oq4FiGAGsNWevyKD95yFbCi5TKkieb2215EPQxvmFTWlv2E8SDQy2W0clWUAB0hz
WbbeRn12r909t2cAYNy4rrd/oPUy+2FAugE5A0JbrgtCvfm6a19u2NlIEeNTddAsCTsutgJgI7a2
ewFFYsO79hlP1tGf/PUDG8xGN7xOl48ad1ufDXFo15UTZ/DUei2pKaWg9l3K6kW8uP2Z6dmw+cv0
WjOso87zJ3SPQ5bEcmWhot8x04k4Vq0/ABg8vumIak2FSqWsw1WUbUAcjcOTWp4J3AUi8CbwwbJf
1CcY7KUYH8U3om+TU91O3dQc9V6nNM3+BcVlMU1kLiax3mpuroiaORIPQmhPTaVJB8K9kYNf3OxW
dAaCTNlyNz/YU+cjSMzU1/8Jpub5tw6bwJO3Sng6a5Rjvy9sBsueJhVew8/sL+VVHYarke07XRvB
DnRNMY4Yks5HG2k7SM1tmhjqIttVs4rBgQidMtPvDaGSKoCO2ZLGxAhGZhJ93xJMDWOuJKjuyab8
GOQurqH2f5HZl1l3Il6b+RSik98huC3lg3yTiJIEuVfV/dvqwHLBSm/IUHQjSZKjSH/XWFHMKKLQ
56kMqi2Zk+s9RujjjxSXgpyfJhkPytI9/busZrBA/eqcmjD80yUTduKSM1nd8e11WUQp7pDro7uF
6LuhdpiJ7pZJ00WRMQ9ZPA7amRum+yPFy0AntHBSxB6C4L54rICO+ic3wqQMvzPRaaijWs/bRLiz
I7UcNYlhyrhLqOtVqASUnlHetoja+coUIFrQMCYyRgy0bBejLSYrj7F26+jsxlcegEJl92ytRnhY
kBrrstRTSRuL7WOnMb93J/jkyKd/WQ665HWf7tBlmzGIyry6w1A7/+k5UZEQbfkxuEkhHx3Nl0VO
Sr5gQJAA70k3O6nKq4rzr4DqelzhDREGeuE42/urJ+CvvvN6p1FRaPqHm4XvJcYDgnHGduYnfZEz
D5AzDvp3J+Si4bb57wAzmE076bsSYujA8On+fvDSm/mggHcVSF4qq2hw5triv4Hdz3FtJ32dm+Gd
QyQHAwIZztl7E0==