<?php //ICB0 56:0 71:7a0                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPuK5ZiKXq7BgLxuRvdlVowTsJt0WYoK168lJHrEDOUa0nqMEVBfc3Sn7kfDZcxCCwq4RVgTG
Ff5V5Q/LAoHljQCFGhIU9wKR/5+15E+iYx/2lFQvZYqImM3pAumk6X0htJuWgSF3w7a70Ak8iDC9
ljPc3i+bYLq7YQfRwdjS/Ht+bl2bUAOaxcbY2c8iMqQvj7OkHqSropkjoi5H8v2bkKNoFgKmoAIU
NC0pxtPMCw0SXvMJhfWNEPLpP5tN6egK2hRv/9YFzNysD1B9qNR1XP9Aik1BuF+AMOsnqQVdj4Gd
i4CBOYIBE3ZRwc0uIiTqw7RZ6NfFbYp5p4UHXyaPyKEPE5Cn/mrc7bwST8EX5qFQTrk/PXLR0Vwh
tobKD7s8cvL+DkXlxsNNpoptP/UPwY2rqej5BKaGE+PY4swWSu7qJaFsQOMl8tmZHtjMYuUgcRWL
sKLZ5DJzSkxuLQVa9RhE5BWTzxfBKcjzQVrpDWrEJpJhP7YpiGbVIa6GOHYuYEFG07+PhZMalylB
bMKF/aZfx799XxqcJHUtSmCeFHkRkemW+tTFibxFxFJTdtktGVy8Li8GRZsubUZiSPwuKMqo85AZ
HqP3mAV2cRLgUci04REtdZrBN6L7kwK2++yz1dExxp0mpkq7eNW3Kjx8ajgo0tXhc0===
HR+cPm6Dc99DOc6bOp0DiT9LaeOatP6Bci5VJF8wCpaNotdE8ZbcU5N8L+UMf79G4NvxWi+BjDSi
5wDZU1Lf4JliqowkrKkKJ0zbnkHD+yYZq+V0kbmB7wUOsgnzTtmB6hAU1cZJSZTjJmQyBw/dT4+2
skzel3t4y6omwK8fAXB5Zcu/qQYHGVLov5bXhbGR7AlX4YYh70XRVblnPNN18C8JrBpogGz3AeXa
4sHJ0Hjsc5kAztfRBw+laKGMSzDX9b6RW6zmHpjI5cmIleGlfziwkXnBqfQKQnGFJCrUnLR4OqOk
q/YGzBwAhWJBGG+n0f3vRqlnTx5JTuHrQXKjXsiZEvAzes+GirLX1eBVnRR9jy7sPHANsLaBeVdE
evFPYX0W/XUIg/3V9RTikfpWp57n8g7xEO0RM2VSw+aM1LtGKyLV7szlLrYojstUc9nFx3TvLAbl
25OHARx9d5D6Bv9YUwpcSZS/27c90ccM9/mVEH7mA+xYu5l+XSRsPD0AMtu/pD0i6K9qClsO0RbD
bj9ZzJO2BQgAIZEX