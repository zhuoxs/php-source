<?php //ICB0 56:0 71:a49                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPrDgx/iLizFyYzzws0Vb2TDiTQGeXzro3whJ6vYFtzBrmC5BYpyK8ntadqBnso5S0gG6c0DZ
+wUgL7VmpEMv++pnxFZ/+PTSibh0AXlHBJv9RXBvWpsKojenIUJOu8CoSNMMls4wiMVybmZDfjHm
u4HO7kJqvCClzSTl5M19gw8/UXvOXHMjN0lYlrxViJeMJiDwHZcM6MUH56iwkLluKVqcV2x1wTT4
hnyibcmUiRjux5DkOQFGE+rRScM6yYiuHB9UhlnGpf5XYT/5d50oXxNb2BugBtAzuUsFy032j4Gd
i4CBOYIBE3ZRwc0uIlbxmfmIAEohnqamPzVwXSakABKEpSII2t0KfzVcfVeTNnKB7rLvNzWR8lAV
98+BqsDbaSpfStHhhMUEznpM/YrSA3U/N0oIaodW0yTvbzLlcy0r3DTFnpvLIOFhn7kGH9WHLWrU
0bk+yVbwACGDehr+NdFHShBcoiO7tKigR9Zud8EhPXYYni8qkt+TUTavWPN0vpP+a/v37qZiJhxr
XZD26CR7qC9aKE+31XissSHC7kquntw4k/bfSSTYlZA1htGoCCe3eMibmPQUex82y+RYNi+4qvXQ
/Ypg0MJJYe/jH048IvmhjZwrNBH5JYiE4REwoEMRlICjgoxx+ecXoeq5nXUZ0mixom7JnQfA4RcL
u6V7QtF/LJBs1B2s/DucJ07SFcx4Gd897Md6URCiO22sjIDgap/n4YBi3H5jB6B3DeWmbnSaHiE/
89kaL4KkQDmUyD8POLOMQEl46sc/8U5XmFdVVrS9/snf5d+DfzLkOt9qjofTkltff6GDgmMM7ODl
mQpIKpgAmIX6zdqqs3Aq/4Ic9b80l7fUg6UpVzExChPAqewqanyCmDFGklAGWD7vcf1Zk9Sr/eME
zkTPidmhb7Rqp/illGqdc3XZlTsdE4ZgtRsnE2zwYyai7dZVxPkupxF/c3B+f9Gp7tobW+RXZ36s
Fx+bmk7sIvffBuxLr3VvJURMgSCP5w/cp0tR7Gx19hdfFbkncJLZDh6N1afylT+mg73w32J3y6Ql
H9IpTq3qUpaNeTXIwmsuux5YwlOIkshL0TdX/MPydNfi0oiploACsCbpQD61DQ1tOVbU/Sl2K5W8
WYVgu00XsCPnqXEXdWOjRPn53sBP6F52EjETQ4nJ5x20uUxuUL1uoE5Q4hIrqSq80UdkQamjAjbp
I89XXNGBIUpsUBL4YRJP+HLJdH5dT93M7NevrzjRiZ0SRZLh9LrFaSRVoQVxleuG5hx3QwbHBquD
CUKrUl/KWocT+R6DpneM8W3SqjrcVNkhJWDjfFd7h5CXMfRP5xk2VOrx=
HR+cPrmCbOT8x6seVh80fDm6bSgRnHw6N0JrKySh24FAvBc+nziYzZtmiC5mVe+k3Hhgjr5DggE5
kSsX0SHlqbRr1Oc6Q6NvbkuK7bNYgeLxfOXMGuy3lkaAoivftNtz0g4DbOzCh4Y6ElMk6Fs4Z22b
GqFckMYqETMSy5/0tBHfGFUXZ5v2d7I//YCN0UJkSByK9V0iHmNLn3R3UMNXMy/iqwKStEMU43ap
udsLO9eikX0VoaPL4Z+qjVtg+YBCDPewlfOAJBAVZA5O3FM/B6rCcDvYwsxLdtUyiQ0iqIVchM5N
HYxJ+93qlegk1Cj13x42aB1zzV+8qreL/SUfoIs7GY8XzNXXUa98w6jloRtDM4dfCuK7a3GiKHIW
3yMWWaNrPeR6Q0PFVZWrfmadBbwwgbmbOdqKBXkyidTqhAXYTjEAxjok1kxKCK5JmVSkVVt679a8
6DjucGNxqnctmNBuFQtONqd8PVOgrIonLBuDAxejc2UpDeC4WwOYce07KFsdFvMdJD1iyui4jiDE
26jZ0lRLsVGXSHhNdLp1sKJyJJAERr5YzzF8e36+ZqZIn3kosFOLOQnZs7WoYhkktY4C5ujIFxQg
f5QkcegHAMacQEAUJxkowMw/jjndqViQ7xcuxIQU7gG3T+idLpkouF5xymhhG1tX11ABWG0q2RNq
zHHFEbltCohC83EOR2MKSnZCUhnXOmqVhn221N9Bo0ydv/6LxLW3SZvRFw1wk7tQFc9aM+6GzP01
qB0pi2dPqAbGiTHw3frF3TqxbXL7TGHEIos4wnO5nVaSl49GAQoEOFlzef/R2cS4nA5sRgY3s1vC
kCj2jaJK/wgm21DogFDuGFc4GD3CDLlLfLozudEoYEQcAsICbFchgri8SSNwmNB09HJRY3CufRdU
BTgVAqwTyhxxLjjde3LmmIlTuL9SgcgfEFC7VaxgAF4A37eJJfZ4t5TEkTBcP80=