<?php //ICB0 56:0 71:a66                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPwn2zD9wgypbQFTXyKe84fcXzeNQ8GpZUA7Jm0ral1mZdIER691TsRNzdI9NVBNC1urG4E4q
iL8Kg1vMnOT5QeZjdPaN/8/6FKYbwMbXtZJSAwsVEhf0NZ2ae65noDOXrrpFIKItE5OUj95rNfQ0
N+jvieE4HOTQrVjsaU94vf7C9iP2GkEp7bHacwD+fw0kOoeF++tOAqPABXUO8zvTEz+m04LD+/Tm
u0qYvNBcMk+EZNF4Nci/3IAAm+QSJGSr+XT9zrxV7JU7141G1BnNwR0ggMMk3eUsKsvk+UFyj4Gd
i4CBOYIBE3ZRwc0uIaTrSmU3+0S27EvruTUYkiqo7igNXWaRzUxLHnX9bFVi8LqMAv8xBs+dn3Ge
luVUbP8oUDzbxoqXKGN21/inUmdoohe75MjxLZGPeyMCkGXZCh7607cYEWrl9Nga0S98lAWESuqC
vfxVZqpKdAgO422hlM4o+sxA7Mgi53KIaLngSTH9BgZB7rwKU5rQIgHlTWC9irCW/fF/gQVB5eH8
zcbTL29B0JAsKU4bcIAHjzrcPUrCTPA4QktBoW1JllC+PpWwcQxygciSRak88BCS562Z+kyeOLZq
bt3fWLP366h58nU23clxGWUiZmQhun4tXYN/Tt3agEs7cRBjHj9sDagj4bv9iwjPLkwjaj2o5s+8
VMnvc1LbdnA+M9WpncVwMKjkZGozvfAbi2rW6biMkUwe7XVDp/f3+dvom6L72Zv6QPAbc+YwMCcp
Puu9tvYmSwuUK0+prJRIILVZQl6OS7rOb6JZ6ksF3srF4MdC2ysltyNJfo9c+guqLWEGDHvdv0xO
iggVAL8jiTdLWP0hUJ20FG2RX8GRBX/SxkZtLn2t23LK8V0s7zgTo1fD9CNzgPueR1tyZuM+O5zN
lgIZcRk77CA4H+n0tuKsczxCz35l4vQX9b/RdWOLfpg9JG/7Na9bC0vfGA3GKxeDlNhk9J1dRX5I
Q8Bo0pt5/yTEqcls/RBygJwmHCfwXXSYkB3vNC/yTCBsIpgB2MuwyYQyJC75M+qOgYUxpSKgtkSO
slgz3BNn+bTr8XBcmx9gHP7V7UNo57jXwiZW9LtFceiS76t/UPY0q8v9Bcpubyxl5gyjUiREocYu
mI9cBmMCuJFCr7wcJP5Wt9yRAJtb9rcjyQJRsa9bDZ9S8r00ZSPs+IGhvMScD1GYVPVMEXrJ+JrG
Dv1HRc0sd8q++bPZvql1TueSkcTpYcfhFK95BTbPtrq0PYLEjysEW7iXIJLX76WxHM5KERJPSi64
goS3Q9w+DNjOYzlUywhrieiYcpKq7Ji4puOYWcoDFw/5JuQ1TkIw+amvYrGgEpvsmnwUbC8c0l2p
hqjpMVe==
HR+cPuS2Uz8hqL/cMRtkyG2lAbwl0hus8DH5Hz8rlEvtriM4bPK8z1JojaivUL6I4jwyBBpaMnjs
3YlHfHErs1eq6RVH8tkG0t8nCvSYyPSvbKNVIA3nUE7a/TyVq5nl5SgnU4rpa8I3AEsSJtqBemrv
UIplEs7jcVmN0G5IHIQyXJ1QIJqxXJbpzXRLW0/WNVch785R/vsejrNJFhbKVPAakasZ6bScGnGB
5CJq6+mINKS9AiKAYUFo/g11NWZw0oBFSJy8AFfw+jwKNSVGvNOu0QC9CANImQKoLUQSiVnRrSb6
BjFuaFI+Ygu4oq4FiGAGKtJSDGufDRPi/rEqBGT08dR0yCUjGajxuVkNupaTWFsQo8YDxynJZ9gA
igOrTovSgfwJe3iQTsIMFIdz7DL7QPEJpq5XHBdeKYVv3KLUX+FUEunfFp+JFHXFWpCmgDPUVisJ
z4CF0O9UFKtj3DLpJx1uPrMdiDBex2wsAM9UekGJnA7mvM6V04pLuQUHbqi8RMXjj/bR9MH8/TZf
tspCJXUi9bDcYvqYo2AXkODwkvldBXBLuAQp+IIgb/W+36cQs+u7PKJ1a2ORN5iEJC1N43kgbca7
FhyN1+MX71Zf9VDVbyUoEGZnqjWLLXFaPUhsl6XKVO0E5Zw7bd3E7XungJt33R3N/eVdDTkCXYp7
h4bGe4F6Az4g8Vxn41bIjf3QefLlTA9X8HmFd8lJKGLij25i0dCMHo2GctNPMqQCRVk5px81rDhE
7ctQMQBfhAk8s06d1EOKHzeeQf8YjRzWXg2azZMcQrKhkxhk6K83lDj1k35LZozktmbM+JcT5JP2
nzg5jy4XeKMwm/wu6p0104wgA6CKN0L5m0xAuuEDGGy3ZIlOAa1O8tFHfKIjJKFkIrZvLFoaJX5e
ilya2rJHuGBXIe48rAZoZZ2qW4+TAedSMA6MzCc+9Kzy/tGsWB1PHdk19Ijh5Q/NvBI6