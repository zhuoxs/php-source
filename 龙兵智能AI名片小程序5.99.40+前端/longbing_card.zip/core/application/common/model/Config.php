<?php //ICB0 56:0 71:a51                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPtB/HncSCKJYqwTAZBzHtUpKCqjTCNhy/wxJOW2vKQs6tTjkixwfkqJDyypTSVj5VAOaVzIA
eNKD7WMfTggrWOx9STCnPGK5JL6HXV2O3K6gjImkvV8BC2rYOJqbvnSw6aw+SQFuszNEMIi4Csw/
oKbOXvfwOwi4/9XXFOcgatNNGu6W0sMGgHZK2cupyb35D97lk7yxyFq0PO1vtJah5hfvRh8S5Pjd
o+awK5VLHp9Uiiq+VjqGiG4d4rl6RoUlaCyhQi4q6F2dTSUYOf+ML7BO6GWztoun7VL6hC3Gj4Gd
i4CBOYIBE3ZRwc0uIWrpSxcka5H48ISpdzToXSaAGzIWAPLoLE3IIJGhDPk35j1JDuQTSrjbd20Y
JT0hExaIsnyXRvxmO/oO7rW1ltsf0Zq8DEI0oYYOIydlgv5+avIjPcUAcdAxwZFCczTINE8YDrDa
zzB/UvaWQWbHEeUQDe/P+qa3hHKjS0zVGv2AsihKfjVcykYV2x2k7oqItVp76/gkl/bMY1MXQJtT
Eezqk57sIEXxD65uAuRFfwQwLXh0oOcKtP1WKl7KumK1rBTdo2IBWQChfudvXfQm5dzCbIxR0F6s
HzbssacsCsjnuzdusMPN0tuPYUCt9OpM1ViQhKkKMCMo24Xwb2U2RnktZXiXwtYw00LZ/3h0+mZ4
eEF5satqXAmGfMjHVUqjm6ZFuF+C69Nk5OqUu5xIHI5pe4etMcFgT0XRWiaV6Dva1LB5pioJCqKL
uoUjQIvFnfAG/hqUoQmc0tcxtV0peJRys/ZdWFHaDE6NgMDeltaVqoTryGCnheFKbX+Ae/Rw4aI+
Da8erlSHPlvZI1z4HEfK1Ioew0XB/xaT8eTiOVg9ecDr5q7zK/kRA7STyhpr1Jj4ZhjEPofzCrnS
WhPyovpjGOBamWv/wYzv22DwD4hPH++nuV7fDbsYImyAs9N1gSVVedwLGbPvF/Hn0GDfWlSS1tlE
8ScCrnbBeOUqG+3XAUlRYC/QVe5hZ8q/Q0gQNZJhNpItf7oP0Xqso1moVP5q0iElMdhdu2uSxPZZ
1Yq2rs3QLhThce8ZEST1f4ywQmDXIZ7nxlNZbdlHQOcE5LTSFQJ0cJNGUQt7mw9eCiIeOGgHRj9Z
QYcFqMs5Q9IBNPsDjVCqc4Z/JBFpIM3KPIySvHAsRFi5ToXsFdTAK5ZMCIgB54+PTdfDi5TPAbNJ
fnMyp5i1WIL3kK6wL3f6esp2oT87DBnRHfAxCRJVG79rmDLFHwG9ZoMDWk7GD70jnUyGX+iYwWN9
fSus0kaZyFXfsDzcmerse/g0Pg4qARht3Wt430LsLAgVZoWgxerna3AHesvrvOe==
HR+cPt2YaLqZTcgIKHm4VYSGh6mwbfuZzsqOGEWLtbc7nYMvZwFHinYynYGoD4zPzsMyahr8Ab+T
gUNDbYLN7gkhmcp6IMQQxBSHgT9eXB3TsCRuhEuUtQ0vywHzLzuUunIlQiOm+GYCxhe228UxHlp4
TofYyhnYvvATD0y2czoHSryKFrT8yC41CqVyAPKp8MpoHG3W8Rp1anyPGfixypkhHG+cee6BUGea
N7TmBbUIXKvyr9KnwHZAA+5/bdboSZ/GB0GJvVLoKwUzvbDLi91LYoUfoNdrmPe180PlihCHIKOk
q/YGzBwAhWJBGG+n0f2cSzfUeZfSov5kqNOjXpuYCF+Jqnsa8XA/j/OH1CDVAW/lPMiILz9hOzNs
dgPF2udvWgv6aAugWbfGnH05/akm4ldiaaTBmKJU//xjAm3yluKNAwwcqp5DaUiohcnwIReLHiVN
ToYO08YqAYR+vly7JPFcyJuVbtbPqAaPpvyKPLPees3OfkzwS52o3crM9n/6E670wV60gxqKi8zj
/JTyExvtFLKAZtmY9gUoSxKzMKBQTMUXs2GMWhWnRcBXw2kpH+MUbe2WbljIngqkWUrfhzIqotOE
WNFNIWLdvjyUFJgb4TucL2UQnu9SswiW/LPy86ya24GnLvukZpYubKJiRGxKGbnRdnp2K3SoD7bL
SsfSVd0Ku33ay3SHkKaEGQSRRlUnU+Z4V7IqVv8qY03rDxpaNI7JjXIYBqrGQ3zSQjr9ZiXml2eA
2aCCq5m0uXoa3u40VgobQtU3O9fS3JaNFQi2atZaLCa3ChoV2We9g7IceMvanBqOG51316DDOo/o
mKm7vIsSDod7Ts20dyj0TvnY4XWppwPFt/oClZ/cZW3SfPmpvDSAr0bBH/kIjc0fl1OK4W4juoyz
6MK12G+uFW6SNe9fORewCjWHE28bd3YnOpBWKJzWARg0E4K9P/8ZzhBh1R99h1FOtEq=