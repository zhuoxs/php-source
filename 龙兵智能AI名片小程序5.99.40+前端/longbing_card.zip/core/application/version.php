<?php //ICB0 56:0 71:fec                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPwzacXnIoNvJGDKFF+uUWt1PdH4SmEuMKTsW8j8TIdYUuCOKCGzPX4skZEPAAbFtuIbVtDc1
BRthtMsY/2d2+l/fRc1LqdRe8btjaqsuwMH0Ho6/69umzMBGlOFDVnnC0ZDRjR5rqy3Jb//0X52a
AQym2cx0rze4y4khnbgf2Rz41l3fXpLdCZfBoDVYhxo3wwu15VUUsrn8/loRGjNbwK10t8Q9245U
ePf5Xkjav8JTs0j5yw0RcdfdW9yoXCQbAUe7jLKjDytTYEeDY8/T182iqdO8y3I/2VfeNWvs8hH4
9x132s8aYpWus+fWE4eoUTWqZjXmgV4GSPv7UT/HMN1IQHSnG7vAwAd6Gc5CtpCrA8TKId4a9z4i
TEEMPb4OU3RjljtZJMTtOOfuWrSuHl4cZAMRErddcDa+Lt2nKaydGNn3PkWJSOGjQ3OQE9gKdqAg
15TnqbG0TC+r61QpcJ3cB6rs5tR/7ky4bQ7ul897cT8vOesnW8Lu2o2IJfg4679qiN4dx0EpUhPc
11KTrMWh37pCrT54riEAoiLuOrrzMcR9qUtVmO8eRfWTsFFtNwNgtoKV92a/mLLJkeu2GLY+KWAZ
I6JLbV+wb9jj+uP1kY4V4q/ecHyXAo89MA6F6aJd7sSBG8gWBkBvBasPWKKMbPSJiYYORcxz9zmd
J3coAcwk91qK/sXYom9AXy/28YU+ITLu2RoyalgWC5zJt22gQutjRfwHcpZVWzSinXJzJ0aiur8H
dHlhg6x2pt/h/+cv5fxvAO+9D0w5kDxCq39VHMmXkH1Gdxaua3Uw9G1vQC+cokJ1svFOBGeMjXLv
TxgUMPinUrvQqaYALmtldSaNH4lU9OCoYVergKOTjFIfjHXGNxevAX0HEAfTKPifA5Otq5BmwktR
3opMAkwMdeF+uBAzZdQkQAslKL5bWb/dwErbtK4fvGQZcuMyX1JBPzEvYQQgHOsRyYZGIIyqENtU
yLM7otyNTdqDce8NYnCavV5FS3YJ0Om0L4IwyqIkgeDxMr+GmdgagY137zOBfcJMfuTBJUTr9nhh
80rHP933BdwH1Z7+fWrINtoc6rzYZ0Cx/9F/h9ZDgIhnby9FgITirEO8XbjT18YRqrbBjAjzUmMb
zajhHdZ4tYw4Py7T6ybfFPxB7QoRwma350KZ0fI68uUVETSSQJckRu2/J2tl7XTQj2U0Q5Ris903
RWSY+CoTpzdT9NpVn2gNsaCYaBFshkuaghIz4LntsLwQf3vQY7VehMVFnzOWXHZtNpMhJhB01bbs
ut1tA5nQHVbmzNL17VBC3ZJsFI4kqzSGmMK9+/1jqlVqYiA9rnW7BHwjW/WwUA5nwEM8Z8UDxXT3
tRW9V8Tl2FKmyHrMCVzrfn9KZAS9zqNiTNEvqpCo5k551UAp8mu9OJq8sc3XleGx2MEKYxcra0bL
yULEAWnJab0f8aD/OHIMRjGpEkqE0kUCoNkWG+gvRzxq+xgb0d84nKlGlnZHmXInDn38uki/wh32
cXZfnHBUFwofglWor42y7UhcUdG/aFze3nD4nrIVJmOMflxjl0FmTWdm0a9bCUjcydjx6EEBqd7l
u13uJh2J2dsGUVvl7oNPV7XqL2yWaCUub5HjbD+9wL3+TpJKfIF90p65lc1R32qdCGAsiiolGkR9
yzpxA55/AGWJ9ZfD2feCbFBax5IPhLpNoidtKSE3BqzwcNHHcbPtCCaQ//jK8z21wzvEJNZXd2vK
6XAbSJxQz22VSkALjp1QiBmlZKBKw07f6DUQ1Q59NMLeyRjmsB+fNCJ4upFm0FqRGo8P8NFQ4+UF
XSm0umifqdfFdWFUDZwYmJyG6a7aDAbfanepjQ4eKOL8hq0DCj3ergO9EAoQij27SsRE5QC9TVBT
57qiwnxaRyGEFQHgT4olG2Fw4noMGKV3GiaFberEBrozMLJkpLjpYFhrxYp+G53cw8jEs2HfZWW0
XUrXtRKoUj1sF/lQUbgZj3XJeeGVvqGegPqvhBFLXNq+KzRikBRxA5F5/PdL8fvbu9hOuFcQpN+J
GYZTa648uzO6w88Wa3cQgRtCU36MiZs8YvRa/PHsOt7/LF/4hTJGzWLFdruL4lpQNZJGLuyEB4DH
TS9EmdUb71e4YCC1/K5IYwU7Zrjq8S1gOg02ggZnZWTlBxzIS7AlImeX73GKyi66QNSSBz8eURc6
4nPz6hGmJj/NLgZ0sqSSGOExBQqMT2o0i6y2Y1E5egutRonUqlhVUQsYpDNRBH0Kb9zCTEKbo9bE
4MJF4HzoQLoALFJ8Nplaurl55uKvNTTmm9oEHRjF5GGn5A0PK+622S3jODxPOHfiG1k5+PFBzl82
cTaPC5TRqFsgoO9ruOwCaPObnChhRALwRpeN3hxarv0VNFO/k0wAlONvXcBvFKvaSwt8qtB6pTtC
kwOg/cXUJIOpm/DqGqnMbrpCXB5dnwD+vVsLwIVzqBrOZvtCHCJsTOmXC22dc93pyxVwBAWaUyjb
61heEKf8o1Pp44UT8H8Fg5ZuzJt+AGyGHcxhxk9PaX5oJ2heZiLH5avSc/pXL3cMPksoel1DrjhQ
Aqxr2gLCjqipBg7K0FTH39+1ReIz+QfVnf2cklDUAO2KiXLvoEHsmF1UyiL318InfQdZu72IzdzJ
WIQY+BcGtQOdRkEYeYWIlfgQHXzdbu3FMUwkQ05rodgY0yHQt3XPQS5+Rx7cxbctAyRos1517vXh
tzsUpD/mW2o+1Fm6XgmKiQ6C4PDFZrBi9km==
HR+cP+7hJhBEIRE5/5NRaM/ZkyMEfEgGwd+WSg/J5YYIf69NXMdTr9V/y5ww7ShXizRS7AqewJzp
DqXX5j1RZxt5Ob29wfKpkOsLB1cdW3j2JTffCPmKZKZMWsxxcKkFwlx9tISFwnk3tqJ499ryFhr1
86Wmxyeif92DkA3/5e1esIrxLchcfhfql/FwPSeUz2FvMnRt8Qf8a2nRjoYNjQHz+MJiZ2JslM/T
fsw07DYE2k55d4OV4wAe2TxPC2isuOWe5d0kYEiKVL5PESd1doO+Uq6uKN08wfppvnVqBSVuHYxJ
+93qlegk1Cj13x42a7rzwtQBllvNvmgjwIs7DI9f//kGnK3JQKNBuLBgze5LUflGw/aEey1SvsAM
VifUe8zZ3FJXGp+Fx3wZQ9zSoX9Su8JHPSAAYGJNxrzwKeTzr3N2QxjvUy254vkJmY1egqHthQ4a
3vPWLF0iHlkVJgtzQTF+RspNd/Ar4yAuRlIzHQX21roa8PemZQ4h5+HYOgIlPx7yKR9X4jiRlXrj
7kMIcJPZexVX4fQCp4jGvkcOy//Ax4wWBVaNUPck2V9jV736ltnNnPQGPzsYJ3OVOh/EKMC3kGu7
X8rHts8SP4Nbyb2HSNPjQgegf/F/Ye5a6B92WuI4hAC5WTu+50LSPYsO4IZYcmpj1yonU91LhU+E
mNXn1akaylPOXGt5Tae3csLSc9CpfGsQsxR9KeCe5abo0f46/Nh9LtD4k3CzEBFwFhqO9y3lKzuG
HtjubxiZN+9iVYZbyCAiC0PNfOJ8xtsfpnXGY+aizbsxH/ZVAAzdD1/u5bHku2/Y2aRv8bo5BgqE
t7kO6Gya9nk8G702ez2BH8BFjgR3FW2IYSb8OICqt1I79YuRvIUptVNmk0RGfey=