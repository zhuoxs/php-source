<?php //ICB0 56:0 71:138c                                                     ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPu0mYHeJ7t9TWOCSEOnsu2B1uFZuj/N5SU6YbvE4O+QR4Ine//zdhNLNMGJsTs3OVmmMnsXq
RsYDFXtBh+E1RLLYE9Nsd0YjbTAcKBmK1j8i9YwnekcNYp9sKpLRbxbXBf8LOikpTgjvfhNqyGaL
dJK2SYazJSazxCKhUuGGG4yLDVUpmL+oOrRjHfgteoEIQMBL0RWRkL+JFZ2STbBR/aPPI477dYGZ
z8yfZKm7m627JQfjFgmgc3j8jtY/wWe5vsfbv8MlVlOHxHILan1jtl8DSW0Gzcp77tysEimCshWG
j4Gdi4CBOYIBE3ZRwc0uIY5nmhlPz/Z3ICDrI4Tnlis80Ht8kFme2XOD4HV7hmkr16tLNa0vuorb
OgCvYS8m/1P3NaWPJJfBSLGxWX5UurHbvrPT8BGgQGUloOx70Y6YBZZyvYNFgZJFK+75N8r+/5DT
Qk0mOvca+FAXnDlyR8JRJcSki9B/6Kp/aMI+OBHykBEWHijoYFrDczScTWDmJuL8RemB6ieS/Yl+
B4O8nTMVCDaH7pgKvNMJcwmgQxbHp5pWzHe7xAx45FxZq1JWsy6d7gvKcvXRCjIVT04BRLEafhxI
6eXmfXwUr6ITitWrTC+SbqT9hC+qhudGo3Lu39Dz7VPBLh8sAV28aOUSvPJSFyWpQXEOXoQDGsqd
E6yL5AoO46XT+QXl1Jx9tpYgHkoGsBk38K3cYgUeDUZILLwHywVju/gkpisLgWNJEbF1wB+URAny
246Judx5Dcfpfn8fuQiEfnhqeYbKk81ptyYPN3IQCRFCoe2EwkJZo5hLw1mZfCTf/8yiZVrAHLMD
1PAGwTVxHoWR33+ahhihhBysP6hiPvMIjv9V79ESNIVcJoUO0My2TycFVC2V1fJXjprHO5U78jl9
TCRSomlCIY9iIopWIsQmy6vkStHvSC1CA2P1YuUygb3aT7LB/CtASOKTmdlFHeDRfXlZCXXreuaV
1ZS1CsjZD57XYRV0T0QqbJz4Bmkw8Gq1ZCaGsmD+lvrXO0N+ylCInZN/vO8gMfXLab5mPgVTp4kP
5Xrz6ms9XeLikLq+7x8434CQuVVMvGKrYmy+WaxGMZPstUW21ZkGiWoTkA3TSlPJnbPu+sD+yHgf
HvIa75ltHpwV8dn72VFN4liAV3NNra4C7IFDAa5FGzuS3B554hTGBSVXLLxWHYSln4OI/Q+dncRd
1iRS0Pf8zXOR5FFr3Q00sMsfarmB4IOkvh0xgGQIHhkd7ibc3p437znYlEzWKdQNTlte4KPdNHe1
l5BpiA+VpgQRKdiwjvaQW810wda7lIKLgw4HuaaDqSZbm+WoDry94gl9GGmeyprcZFePnsz7e8SY
Ahq0N3t/U9JWHw1THLYwKE+kg813ortwwK1SucY54p+tNa3XzMO5evSfTl0jWqTzspCXRLfIDKdL
QO7ORbbp4xqGySiOEgR3IcMV5ehqhvqXPbRthdXkMu+tCjJN/ymbRxX2YWaHXPu+2YM6b7vLhCrq
jN6UQM8eihUcAkRUpgq1Ay0jkb8rzVMNWe/OnJHVMet+sMml0PkiOik0P04rjOBqUt8If3SvtxJY
38/ucS+SHZ3e35knxa5DFodC0Xs76eE01MzjPcj5YZBK/71oQKMvdQDD/WzinhHds0s6kpPiYftH
VsDrSJ7dP+TLJ28PGN8k20+8Dpbx0KxoVkjj4PcaJlnChUv7ueixmUpD4Q1t/B25UAPaOQv8B2ax
5HPLgdjVJ+VjrSZKK48GpC/7A/6KugZtVtXXsQWNsFFGXgQB/ycEAkE4kArylLYqI0ojxIsCbGJA
JxjtfMePvMgnBQHQvXlX8h3vA2F+nHbnNC5DaCJr+NyT9TU4cYkTxGxx2T8+GeAARZ9ft1Pd1zhi
uxQoJ71DPIhDnfcrO1v/696TgHFMwipNPPqW7BiQSbAzWEs16+ssD4am5IrqkZ6MIctDHU9FDKde
Yf2tlOKjGbcE9ms87NNfosS5GYAQGiNFpUYd2+XgtKarqPOJ25n8tKLlLmfSXkkCztyrIzaG4SYv
CTGiISSWvGiqJy0YQHOCoWmY9WcaGnygdKDcjPuDJD5ccQGbXUGPgew012wwX9nUidpSVIZtGiNg
m2zcm4pBHkswDfcub9VCQbcUlArocS+wu4dnTYxXiJMc8bNdPA9G9PIW3HiOr0E699YU23DWASHw
PeSRfV38sK9D3PdiuJtYWxzhMSzMwmht1QrYrOtfiYnZXqyZxf8a2rm9mIPcBm3fTBjY538XabrJ
pzmEyKbrieL6KIQWZhoNcViLUBjnWdkbH1WEaS8+bck9DDJwwVzoDTGoRyNL2FLFNo3PYm8aFdDo
xHKN0hF0jtwNFMTB+Ox/B0YZ3Shd0yQbRal86HUl56nCXGPfxQELYkirsDV/nvemyOt9GzYdWTck
X24ZDXFcnE0ZbQm9dNtGxNCYq4AR/fZKbla7wxJyi8O7bAmdQdhKW3sgLIfKoFy48O6o/1MiWq7P
cxs6/AY4ztLHYwamdAdFhAGWBOdvnqa5zm/2uAicSwgCuU4oN2eKjefnUSDu/IW2c0V0vuyOXPt+
pQo4xDms1Uvaj05i5qwD6FBR7wDBekYv1dZ28hO8KNWemD57/9mAeTToHlAHKiXnabP3VODp651P
GzLPFNeCWAvBFKz8J9RvVQZYVQu4Deu/K7KFvZbSMgfo1RxWxwzYvbI9O8+sQ4J/J0bADwQY+r6a
ruaPd8EHm0vKsAnIAW0iYr4a/gQ3xpTlbjUjYh/oX5kgYUKl/nxtyoDyGtrin84cPfYdztaTdRoV
Mxv2JvZVwHo3FQjh+FBHV6h2ZeRaB58aWrAn+JQLLC4pD/rroLczq+Kq5ElmdUZRBPYrAy+jRbb2
pCn6nRjLbyUS4cBhvaN94O3TKaQzZzlwpeTmlY11BK2KKk8wRzp/vhhkK7+IsOLtxNgkj50xJIlf
ak/iruhqwqDfPbXkl/w90b0Ie0v2ufgFN1HBtAYKOgud8FXfDQpSrJ7vk/9DER0Yqnd9NbdDCawr
dIcBfbUCw3bhBrMhc+zLEGyHGIOwTlrAlYBy90kYSGqBSvZOmArrjzi5mqM2N/1PBw+ciuhDQoiA
4t53x4waOIG8CR8CV3IltSI4sXjfKnQrFKifL16cRJ9cDhm45cWLEW58NWI0RuTsY+D1oUgaRQ/8
oB+iZpleOly2Xbyzn0qWddAy1sIo1UG9S6J3vV342FhR3kK4PAJariwe9xBITTKMJLvsjzsa14u7
9/g4FwTfwsR978kTcna9ZB70IweiD039fgmL7wwlAsrQN7dv0RIABAq1pmnLSyAEbs9FLCCdZCvH
w3uVHa0UMjHfLNSfIzjboIILJqOdKGF1m1PAjwYAq+o9YUdgfD+yhCMVu19BwKqDwa3siwHfIvze
9YMffDsPnnZhkZU1K+Pdgbzxc6oYlnm581AtgQmw43cRkchIpuNVBEJp72uZlTcLPrMn0FuvzVod
3/lb4oIC640wKfdHFxzz947kNywL7SLrhVM+nBTgf3SId0eIP0Dbvw7wkPouxgBUs85BBhIxJyTu
YanbMFbuf/Fek4XE55CFU1Q5deeZh1Viu1bwBuN/C4kxzMJrlX0BLWr2fIUeTKTjq7/5dxHHO1Jd
NM67BURcYPnqgByPhS1FMW688h6ylnUhQyy9cW===
HR+cPpSAtIqhwIK2MRL83gQ47uhyu7OOAwmdJxFJDubntW1VIOhnLnIKwPCqqMx7edIAvIwCvTBn
tcAkwN43PweQy8524JDoGEHw5bZRqoE25AHf9/qISXihOV4SgYJvUtVuG+kICjE2K5NQYh1tQYQ5
iC2EuH51H9fjgLvPO89yDp7hetj0/JS8bujRbQTzoX96es82s8K8Ybv9P3GjNKqzM6JJX1/W9FYs
8gVbNLCWx9awKF7mi83JENgjpBfiOL9DtGmH6/5DQgkvZagk1+5anONuT0lu7D8xkIp9dUYbHYxJ
+93qlegk1Cj13x42a0XpkdIJmwNJeNsnyoq7EY8ZN5x8nSfydCalkgBhidHOtAWK8VfMch/682PK
dXvP/QdEDoqXcOYF+M3zuVXQV+O2TYa0rHtRQwkzk18FAZd+IYuvrQsF2Ep+6U7fT9xKBEShoaKC
sxhO+Rk8Qx/oWm2100IXx2RREPoy9tYcH116vxKpuWb4vq1NUQL/sUhHo7oH5QSg96vuyybi2rBa
2rAILsDfufpAO0MuK/B2IUNWl4aKa0LDkIj5q2A1xqZ7tEutjc6SGOlhgmf5VkGd8lJyNGG6HZU9
pvIm9Imn8igdzIFGn4HzHO3jWjBXjojNN9e8sqHOelZ2MrHLEf49ri1xdSviCcSc1CThDSvYi9Gs
K49JWJemUhOFHfHkwE/IsZfKqjk0TOUwC/X64CHM+YDClPf+ldLuLPy8uwRPPAWg3DzWJ601daxh
fo4A8XZpKvsrDxw3/+JMt1m1U0WNj+y6LbhS96nuhqAKwfBL3BhoQ0NZW4GDexRN5mYxoZ7jSd88
jlLv3Vgj8xAi94RmaHoAa5W36QdPrQyRFqBe250C9o3N7rNMwLiEUORzMvE3CZ9IerqMefhMooC8
AKUP8xLqQQWArk2O45OXnTmGpJLgAr/bTthdpkujps2UY8oiJUBnGLJV9qYHdsyYtix97TQNeVS/
CLY7o5BOeYCCz5tUb50Ksf8DV1TJPuU++7HGr7Za2e9QOFGk1mTzVn8SB5fuGxwh6c7p6adyqimI
9bgCUC+Wc/ufwYUPCuzpTeJmGdMCD4n6yAn9HtbugZr/bubH4DoKHYJeWsGe+QpyVKVGQX52m2zi
GRBTrf4p2uU8oQ1qkDFOf58bQJ7juy4ZD8tdPn39khpo3blcTdnPOsADkePaus3uaMIVkbP1DZe=