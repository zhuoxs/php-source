<?php //ICB0 56:0 71:a5d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cP+aNDtws/o6BSIIYebtr7WmL3Cx38+GCwi4uBUsnzhJsHw3JDPRdSVSnVlsFhoV9Yp+Bbaxv
oyJoHhh3BxwPqfF/SsmDzbBlmaOetMNskUtWqMNV0mMlcTz/8CMr8QB9UBxJDd4CsI2Ec3SUWLXv
EKHsInhLBJsesEymyYPYzr3mAK/sdQNYAwF673yki114TeHBsNLeNHLaSWho8/K9ICJEHkkgMNV7
Mr61Y+syvEiYa7laly9PEQI0DC5lPB1z0TaPefmKiG7XZCpZ8js7IUzxexoVd1gMP8yMBbLa2+Lu
j4Gdi4CBOYIBE3ZRwc0uIlyjUlVjWtZCw7SRnaVHlSrGVB/6idFCo/vlnl2x3GAf6N9CE/kopnHa
nnu+kbxpc/IYunVuZL3JlP/5CWZlwh1Zki1/yUnVgZ3lmmgxm79TKx5kA0K6A2auP7WP3cU0m393
RgPcP/DJsn5JafWNx8y/cyz2zTT4i1PCT+hbqBfTV7oXBqdT5hrimKKlAaIGbIg26SUWFzuqb849
iFIy06SqcwiklaTlstwA+LxRtu8MxPa6UYA8HddUN2v48jCFpvDq0I+UtnWVn1FEfZcYIyrjkZXh
jyuV7pr1so90rpIzcku1ykIWBxL506QqebjQn8EoprOoK3bqclxO+wj2Abkic5NuHG3QM5raOl6U
cWhFsJfabNvVln0xLIiNAWUwyAhMmov1LRydMsckb8/HVBA/hnxdInC+UOfCnsNvSfeI/LqDZSBn
Mi94effxJ5ZaBQ5KBXyEDb7Mm46TTrVBKNpkdAORYpHMDPhqCTFL70SuZjw1VZQUlJTQy32p86OU
1G98JbgpUC3KcN/sp3S25ZfkxMu9AivzjoYt1Mdx/YD5OxlHOf3TnhjYr3QKkTfNckFLwiCC+woY
bO+p8JS4p9Bq6KA66Lr1ajKrRqVuDdoswP/bb+0R1wM0Rb5oVCgR+IKxWWeoqpwbe4GksQvGHTq3
eUb+WiHYQXjBcvBoPKP3LMWMUj1dRxWW0NuqJWcs4RnqjtXCP2rLWjB87j5K0KLLiEEOXwstkIVQ
NXwC4nGR9K10euGZhcLVPSOcHN09LkurJdxDm6s62RRGFLN/GLqhdD45XSCbMkc/Av6MDc53m/jG
Xb5z2sIaOPHnxMemOaRIDvkla5SQExbj9jeR6Wd87nS7mKOYFbGHHPs6Mws6Z1xanqUN9sN0QayK
VXzr82zbqCT5koh1c2lqKLJhIVdGKYviGmLRTnG/09rXekzsaqOaLBLdwp+2rmlAi1loHSqJbOaU
CGnT7P4PyYPYgbSYQD4IwigvG8puqrBjUU79Rj6+9L4GyS18juuolUJEY1o6PwnqRFwe6clRJG===
HR+cPptHxEk+8jNCB6zvo1ve37hHiP7w4kAcNuxJrtbLZLMr5l6Sr17TgRfELG8NQKjFOB+i390k
+bm0davS1hDH+jRRjXukY9pjvhCe03PvRS5CAL0gh/tSZbNI8JsZATyl/ALzAWp6uaRGWlPM9Yip
0iC/dm8TQaXCYSXO1cQw9/dMu81/g3hSr08f52ZPqIEIFHtebx4AbZW7J6MlRTJVLOQkHqkqmwSs
H64V6JQx1XcJpZIcQXQYb5LTxt3nyNhIUhNGu6ptM2CNtcC0T6aIzHCWX8OZOgM5iVP4KO/IHYxJ
+93qlegk1Cj13x42aBXoSmiSspcbdVogZYq7Q2DN/w+ZQTbZ0/j/f2WzfjN54dweeh3xzZyhLfWb
9kwylaIE//AWHxlixMxmtpLOkiNEPAqYVODtKiKN1bEKXh00/zCEIzpjG01ts/Qtxy7iz4QoxN6T
JEDcFR8eAwOCAgUQWHD0Ow7JXzpudN2nZFm0A+wws+6lbP02VUiNGrNNEdUyePzaVoki/es3goMy
+0aHRii9Hz9H93W+FNSZcw+KMd460IQNKW82xiQD9MwdD+HPQ/IXL1xN1lDwohL/htcmb+e2ExnB
3wrwqupq46edDSqzYiM+oLudHewXvSr7d2sGQZx9nSsjJAognEIfWkkJq8rDsM2+2JhGnWxzirql
7psb+k/YV3DrvS1nOLbaNJymIbjjpMW1W5HghHjli0VGxI33zbx3ytJ4sF/He0UUqEM2MF+f+bpp
WWvUntJSIoPPyQ1NZxaMrgQpZeA/dYBmMKzEh8fYD5pQUYDv87io/wBQaC6NVINSzOvH1wpxtxnO
ABFiFIerJ7+G596L6O8j6q5fJSM5PitxltTBaryTZLtvrnL8MrZSX9SeMt5dTDdbxp1A+hTylyBT
2l4=