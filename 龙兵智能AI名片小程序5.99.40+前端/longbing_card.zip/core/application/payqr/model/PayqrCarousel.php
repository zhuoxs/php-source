<?php //ICB0 56:0 71:a4d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPuNr7LWzKkQVKq28UtxONk5fcUNFhR5y9l+YOZMVBWN7W/xfrifXIF9n7X+ZlPaKRJSlTBT0
rpGMQWubOAH1WDgXNaBESzYmLt+WGB9JjFMhKyltcwN9YCtetydRdfUGy/vNx863lhAqURU08qbW
4kZ1lf5FIWGtp3EmSlUONTVH0tPD2D0P/eDUyD92xAGbKKltrrLCKDLGViTd6p/w6qN7CJ54eg85
G3J75qqDufr3C5Dw0nk1Jyop92ZVXZ1JboLqkE4AJvXm3GI+KeWzFiQjWKIHOSHDKV6RXrU7qhH4
9x132s8aYpWus+fWE4gxTQUh2AlB6adY/Uv7aOV9LFyCyEFSCz0sBvLtnk8Y2TZIUdxcAf5yBzrj
env4JpyjJ7Jq1+p3dIekJIwe5DvAnkx3hFi34LfnFKdksvTsYW8dVlRfzJSZSRisAdASfG6i5Bub
sdLvcshcxkHN03TzSZcuyXgUFX+AoTc4tiPo/TZ9B7tn2YIuCSAbxozaOEODgy0nwGF6UwCnVHaz
eZx63cy6FTP5GeqO+7VDD/woBauh5ECPmkZA5flEMReTEFebeaN0jzmul/jV6GoBJIS2MEFG8sJW
7dwrqMeDWEvJZhmbjYiKAsFV9GZNftwHuH6FSYGz+JB/YYcgoEVtrvO30lVDR54QiIYpkql7Rf14
8xea0Gs4dahziYqTE4G4r/gFnBfGL0zlRejM3Ps0bX8XTFU6JDz4GJzd9NEya3xDJmkPW6jqR/MM
EvhGYGLqYvI40fxUN0u24o+PCdz4eENglVS/KXn3VuOPQxGzf+NtIgeM9UtPac16fyXep65vaO9u
4yM69jQdZamRQJMzTRDKKZNEZeizTogEapwJmay3tJfz0Ezdgps9dbyGDhDCTQQBhBlERw7G4UDi
d2KDkJgEbyBDPJAuLCwR7BjboaBYmLX379Sj0wNyAFdYrAjYmOKZEEkUMzqqH79eIZlEYiFjLjvQ
b0o3+G3cSuOss7iQVBz2pS6NhELR/cLWsK2+u7dJlWVuumBdxP/31zFQkM1HVc5Zye1f0rFuP8OP
kpWuEQ1+e+J6pucZUJLoJ2UDsPbI2qAuC469H1BKOleVzvEexUoJuDgxxtLlSGxQfs7a6S/AyHQ3
9Jjg3o/k7Mqmo9UJyNf0jTBr3PYiFTCEalHwnm+GNT/sZh92+OfQ+zscYcNt5Wg5VZkSp4YLfVvr
5E4dq176uMBgbdV6dlZTEElwfh4NAzKqWuQLyO3msEBMI/IAiLMqX35hjVam98Lh0DRt/ti3CmIr
l5t+FRb/yEkFdNC/YcvEZnpPYGCHgRU9M+ylLybLa6hA2nPZlWC5fR1uEMm==
HR+cPuh2aYGQ5cSBY7m71pTd/+thxzGmCRP+CO/JE7Nnny50TuF1LhWZiGr24gJRz4GCBi2OCtFs
n4ZXguotNfJ9SnJHL6vMf2KvKhCHXivngIvlxRJfsK9J2flu7UHw+EU/i10nnzu4mX3vn/HNzUjN
nO9Cpn8teB4PdzUj3FICcuXJc9YQ3oFa60bjEBULnxmeiHNbwG2dDHrWVZiC60G5oIh3rIpztyHS
v2ZLO46HricWRJVvsqQKVlA3PdT6CqaFhM+4y/NsfxNFDKMqSTG6RXZYJVJm28uDECzf8flEHYxJ
+93qlegk1Cj13x42a0juBNQWYPFBqGkcUos7E28Y/mXPIBZ7jSzY/TaqjQxxboH7nMpRJJEduNB5
VZvxdUK6EuFuSNJTSgghczvMEZiDoA8OOIKt6ED0lD7yyGg2AxOUGsdNrbHmKYcR7zCLBqOCz+65
GXPnW7qUJ+7Wfjln8kEQQ6DG/egoviKmgZXFvzhNPue29i3amBHfK9CuNO6+aeTJ6dsc3TMCWsxg
q4VtyxsAxwavcMVyzuLg/pv/olqMm12M9iwvqjfxoIQ/gM8MoKVNyu6/ulyi6pJkhUl1ovXz1/PW
Tp9Txs8EfRlWfaLlXkBdeUVqwvkk3OU0V8niXnrH0OhfFnuqJBN9VR/fMqhf86u5dcpPcsTOhSnX
6rwoNSzsE1SzAjSF3MNBuyat7iwFuEKLqzXgjKVES0wniCN3d7SBq1UbBIVnGTtHmtbuo/5J8/Zh
o0NDQtxjY5UXImm3DV8f32P+zmJJyrvfW9eH7Gv4wfF8LDQ8YB9+Ag5f5xVaQ9uYNjSjQXJ0MCzz
mfOZkjLErDTCe6I2FGA0/YiG+2r23/bU/7FYg5CzpxIcKoRpRXivvgZqd+1AyPUOvTMf/YAZl9dG
AazedSSgQINelAnIvWHs