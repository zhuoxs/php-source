<?php //ICB0 56:0 71:a45                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPxd26entA/yIesLtZw+clhu6SZyjYmDF6QVJa9ZRqzy/kq5H/XwmTNas70Dvz6Gx2/VcZHd3
QSp8cs1tWXSkUBJeTlVNlj3FsCQQ3BfwzcbIOkQzSxgQnky/uEWuBB6YQAEV6lp5lHCn7H3m6EZU
dwpjBWX6yeZDD55Tp2pJbnvhFqwzAo1JjD7AIFjfASNzJcpY3kJK5XOGxUsKpYyVg9mf/A9BAj6t
yoIKfzE0gQ3Hwf2biVYZw9hXlM7/ZFrHGrfykGOJplv2SgYgFJC792ffprdsdMFac+dG6496j4Gd
i4CBOYIBE3ZRwc0uIWbyRH9gmc5Sia0KxKSfYSaa/ylcjACIBQpIXGN9vn3Y/KxeuYmKhCxEMiGi
zDKWsZzGJKhyiSLykxDFvbNs5Yc1wgxABLfXxB/vDzhJYYjfEpU+fATBOfV8DDU+BIEKWTYVDWsV
6fyAyLKc6cvTdKVQLdB7Yt5Mzz9+NnqFig8ss09SZK/iiT5Ol/mNueUylFNz4WBHazF6zxHbGq2C
LeZ/TFPTqon1VrW9XEIVvm+WT4sg5JxsJHsgRmrbfO+JArsMYCJLJAV7WkxvM3Z7KgNboZV2YQPe
cp5CBBlqTll/TZYI8IEODky05wGz+CTfjZ1pl54d9yXlcADrbKtcLLwyT1LkICbMoYJpq/Q3tLRc
tcJ/rNgqHDLxyrDzD5j1SYtq06z7vhTbjIDvzGa6xE3J1FsyoxrvmmHT15Q6eEOo66Uw1FkFjNRa
jqebPQp1u1/stqRKcFrgeHo2K99O4kZCq9QCcLw5OWzsK33Bn3t+gQEN8MsgfwVTJdEYgaXrLyeq
e+sjZXioorKWVbiciJGtaybGp4IebKbkczLqcnwWfaFGSAtotqxUIfksgPxMQwURJbfwA7P3HK7m
X96nJ00ZWbxvFGeD+m5dZmhIU8jdMMYFHYglDLQ+htYoIg5c7QppZLfFLa7Gx+gqUpqLRxm13Kue
UAu+8z6BJPNpgDkkE5mu/WxL/tjBYh2P5SUadsXHNDDkoGNvMZIKwGBvRpVAEyqLj5auPukgNRU6
fA0SPxOo9asrcMyn0nQbtUzLOUSdiHIcv1DbUm9X3T+VpOoKmRp6kCgilUkslqRyKV6CraHx1CWq
80B86WGXDIfDhLmKjr0tMpMGqnEHLMi+sP9256YxIJwyVf7dvmP6rHv8iOG8VZ+d34DCpp3G5l2E
Y1LJ/gM00qSAQJyAnxgDxNqtkDQ4SbZ1psQUc83RtCUy4djD5o7B0/uiwhvi1YC1fveaNrZZhciz
GyJ+ixqgO5WppdmfuSS8d54g3b4NB3upQXai7UVqtF81gDrqaZ0==
HR+cPq8r4EuZ1+d1KOk5pG5ih9y8BeyoMWEQdCWYcxwWHHpKG9aMJ9Ffv9CzzzD4ye6Ptio+VkAS
N9SDStO24hAm7x9v5Z+JrP5+HCzQ5oX0worRT2j8E+ikyukJaMypexTiNK5iQhO54vWxuI8QNvqp
D2h1icZyfoUC8qiKN0vngxeldPZi2J8hWKhACl8pQkPIbkRj2/L76Qn/f38hcp3aa50pqk7GGyBr
zGCOeIWCxfWxvmyezMfyM3deHFVVzVNuMH+6HL3sSUxbxdTsr767yvWY305srmXKQZL9kXzCJqOk
q/YGzBwAhWJBGG+n0f1mSS81v/OPVCsHiw0j1pWYKV+9XZLSsFbdntU2XW/SYd/x1jMM1kgYiXUT
1s+f1pO1eW3xVKQe9KzLaQpf7C2Uh5bFQ+qeDf20j5jzL4QF+EoFnynZGayZGnHFtSrcLtUiYI09
rkLb+NsSvJH043xyOiNnJi/GM502tmC9DIw+XCK1PCyen5ExMZrr1OgfkRZF5kKGCQML09Uyt2sE
0z/3DmNzcfyd5RjRdOBnSXYnVWQN+y17Km8Fm3iCZnlmvwnZuIAYoglJK80WqpJ0wZr9U5SGidZU
uivfAaR248JD0cgCaO0GswZSv6lj0yw857D6XZwxEbT5gHBTbnya7DrSdAJ6ua1FS3UT4vSCD+U/
qoa6ek88Av0h3OHQQ4EbqmsODzew4CoPJNvh99LRprus3TjzgoIXhOFZgB8ZzKfWAHLmEM1tzIn4
pD6SNfuQe70GYuukMPB2LKTqT99L5yspcDBTMLN10bXVlp7V8WsMaFWfIcugtPe2jXBokDxF74NQ
PYQP3aqmv7//i9v7ttZlLo6NmNt+Icipvc4mrKd+Q2PGor0498BKYrOT7Yy67VexkIAdpwghns9r
