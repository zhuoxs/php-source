<?php //ICB0 56:0 71:a82                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPmL92QB6bl6LzFoSWLxr1bRm8H0fSNtqwCauu+i46Yteuxtu+aNuWD0GdxOiB9sYJvg3b9uU
ag/isqvyo4h9c+K7E7C258OYFkRY7xd1KWXtL8p5MNicKGRSirODNfgedsAeiZwzc4xKUpalZYpg
wOpw2riI4Cr9J56qJVrQsuQ8Ml76mIwL3uRnwYoUdgFWbsUZTC/2QQq0UwEEHFjYpB3nEF3u7MrW
crD0GZI7a41KbMPPBsacc9hs2y4Z/i/bj6XXKUClzIs9/QK8uh3EITWQaVOBTeHrjbOrJrskHkwq
H2UmGmjY98iuEDlgO3XAAtcbpuliD0tYJJM5rwAwpLp/du2PN1W4P6x1OJ3F/QPXUm4ccaojD1b9
IQ6qJfCf4lAvSIldnFid1TP3Zxgr4vfUNKecMThyBC1taBzcOlguXM9zTAsA/jXmulB+aAYSXP1V
1MzQ+OHMxDtEdnYWg5qvs+n3/gDLBBzBvos2FgImw7YdSilC8MvjVGLAZ/lRvPmDVrI4jCVlPqLw
pCmrBNnCukj49CiwOb5c2XfGpeM9w9QvcbXTwbw9bizSDw1NiBpBLSfqda2KCgOEbwUNOxnTfrR6
QVdExpacTrLHhzZItZKIX2mBapXT2rLDZJeWr6NlJz0hfIUSOYkPnS6Fz/f0cQsa2+ZniEtHjEzy
JerXAFzmU1vmw+KLqGBYbJTJlM37Ky2jcs9piratSwqAKIa8PDM8Bty3Z7ruDjzIzo2v8RlSg+jS
/kGI4CKWxy55CN4QAic9nzaXPzEk2ioFjxfLyLs/zAFmn2eCzkX/px1PHUuumhLLWX1YNF/Tqkpd
JRTaOtEDm2hQhS9ckjCSwxSX9PWKI0QesHFUxx7MQO8ZAhkjXXq0RvEzJVfkJyIsQjoPMPFi194c
7UZ0RMGQO1ectYcM6wH3vv/VJ3ReTB2DAW+YXjiPTxUQiAj+J7xEdv1MWWAfw2qRDBmd7ptx7FVX
SBATMqbhqmdPAei5Vg5GuMJOQwOYQeSPilq7XcXPCyGP5R8ShJb7lt+TPutQfpjdw+Wtc+Jd29dV
MriUuAIV6C9n+HI/S2+Ps2EhnjAD3gbBh7frNGK8w5rlFYXbN2a5DVbypxHn7JhthRd4gW/onFG3
WElU1+FOdoDSp4TBxV2dAFSguOgPxWTQ+MtUlZiiBFYAepsMcsPwZTmzfGLgE3xVpHwW89IM5cmW
f2/P1PcWp1cMVadldIicksH8bsy+FjolZqQF5rLxIqsDLNQY2Gc9tGUsdY1gc1oOhuexk6u1btuv
sj4Yd51CC+takc8n9FIkBPITcxO7yNNFLKmhBmM4C5u0kO1tTCpxTnxcO1kQKKVhvmn+XniV+HUD
nLZjPO5hlrTHu0W9cQ6hDT26GXv0eckB0wS==
HR+cPys50wZ2L/YFy3kMYyYbb+oqE9g/UcyUEEupfzeDMt92KnYySr5NWxDgcI+mVks59yqtgefr
+F/P0FLj2ZrqcPhwT8dQQ5JNHxFTpVU3+6ytmhrSAcdWofvKuV3emZY6/3wFMUS1YIELLLckqGFy
5y5Z5TgyZCjURp1D5yV+oBzcThuL02QDMho8opEIivBfmALy8lIDg4InBLScGr0kDvoJEpDHMOID
YiL+I/nR717swwRfgqQB/mdCa7iFgvtE1A/FQFUSAkkweuICrcTdXospN6Sou90nmi2rq/ed1y0b
HYxJ+93qlegk1Cj13x42a6L+O3Pdljq8fizURos7Q2CT/s4lzYe0ewyOjdOQX6B+p232VMaXqqym
ZVewfgZIzfq+15qgVaVYcaKmVoTb2A3BhMWZt6u/25nSoCr38m9ylVZ5B31RKwnz4N05Mv3QohdL
tUXauCv2yhD5wWvgRCK2ciCn0mAQ6Y0Y3+gAuUstUCAC7igA8DqcbqnwAolvOYWlpSJxPE2bCdDl
ueoAY6pPcg8VS2F+GDqqIyof5iB43kfwL6JirGmhmeGXtDZzTslesureUro394dEQ1P5ZygXxU/m
0NpTzF0pEaT+YcfvtDIjCPiqnNKQpBLdXRbD/MXXVatt4OHsE3dkUyFYnFxQYeObbtoOBpTLFozX
oKSpQcEZsmI445dh9uLj+mPr9V4AX3YdK566B3SRuLPXGvubnHvQDdVAs1Po8j+eCvaLk6DLy7jJ
bJjioiTe85RRHfs06VQUpksNPEEsmm5BRoM080SpSFrzzxeP6LUQJJL8GAk8AkU7/6O2iGJtXjL0
yCRpAYadV/gHUlKqXgsVlxgxqMzuFbDiKcNahnNLSLe+0gxFjtrLDDoQKczOfqbBL0+0SxV578EN
9G+pnbDp6XPobiNhuy8CHq2faTSiqm==