<?php //ICB0 56:0 71:a7e                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPpLNYhBHl0w5n+8VaTjN7ROS04FAQhD7eehJjiyoUEk5PRN3232SxerGVCvlboVCOZTSMGPx
wgT5NdgH8b7pEXkJmjfYD5nOQ1XLe7pmO5eXMtLSgZu127R85j7OQKqftbX5scXSvth0zC2xe97E
hjiB6pY8/8YDOIVokXZoyAu3zg+9jcBqlzshVNU/CcFSh5PmuNM1UH/bKWQ69D/fQy/Veok0IYsR
MXBcgHyxBsgiCXUBkOWByzHFZLH9mp9KDGQ+Adb/zr6MzztnpErxYe6rDxE/WDxubZ7BIDQvj4Gd
i4CBOYIBE3ZRwc0uIeztaHRQKmX/4Sv05jTw8ijLekckW62zHx+C+KylrqPzkZwroIajG6ZfbNuI
iqcnYADhfghWXVTb/E4S9/qaPtSIlAQcm9LihE5gDkZCFRLMo3/5CUJS8Dfg9CuAvDBiI/33Qo96
720nKLgNPaNWPzEf3+qNrGv0PzGsXmNZjg3OdxdxeQkCMg234SDiKYlWzkJVNWtexTD235W660mP
3sbeagtDA8igsBHd1wRU9tzOIkC3UPLUKm9Dl9CJV5dvrXxBJBCTEbgVMS2JvqJp7afSlLIjrPEL
+0G77d8qbNzDWgFBskD/jDZQI838iJ8a8uID8ThpfEH5kcVVoSObQPZNNhLWexWQmmXt/eDDC3zR
WlJkuerjFqZ/lMvCgKYFd5U9p3U1DlpSyq6VZxbHTeZXGKoXOGVTJJlj669h2MTQ2VMeQbm2zeS3
s32aMoAd6z5l/zED9+EfVuSNJmtSm7j7pkic/vye+pZBdLMYfeymeaa0Xhk2sYV/bSVRo6F2sxHa
xnEJ14o6rLokZ9dWv1a7JI0NyFBol/+in7cjxjIzRdNneYXbupMxkXCYN4NVvE9VxyFLbqWnV0oR
9LCE4gw88etycl9v8as4oeWjR1ppmq66hEtKSIzeHZW61XRm75tDZcRTFd65UyDx/3tMGfCRbkDF
H7fY7BrnArtPGtNz4DAC3d0YSP56Guq4BpK6yylgzq98GnYAMbV9jD8De6+NhvXV5nyqZltTtkfi
tLJMWC/ukHCKWz8rpCvaQJsLNygq9jEUUfVst/EwTr46KXMtTBjmbshhGg4QzE9pq755e8+t8Cy3
WSz4ng0BAWR6WnsQDrOo0kxCJVc06Faj8HX61Z8dOoF/fzm4KXjGxZtJoiDURMA3zt/edsYC9I7t
mDiI4DQ7ysUMoMjpkI/QjhxikgLi80RBFccyCAD3jrXSXoiAI5nxCPFmC8XlR12NesM6NC4GMzbo
FHwsgXsCcT47BamMVFgYX2PGcdD4+kjZbkjE8NGJpC9mCM9tQSJh9BnII8LG5PNCY6VX+INDAcAI
BpXB6NgUgVGCV0eQPei6AW4wfPA8RkG==
HR+cPwYV630BVU47kI6D4ugkvbkDgDcku4z2Kj0LeVTfsumI+sr6QdwoL7rfkKRCR50gXBr34Ad1
yJxFxtQS423UKe1ZAz5D3jUuKE2rwQIk35DZfsndt7Hpq++ppBFI452JqroqxZ51WoYfS7DqTy+G
lG5IAHl4l/tBCTOTppsW+elKrFfMqru7sNU05cDdlZWXoQU9HDZBE8i3lIVzjoslYi1Xc6g9IHbb
hf904wbgv4hIJEfnQwrTRSi7ihHh9jqhD811/FFMYSf7i3CXojI58uLy5WmZlf2OOI7h1PVKrKOk
q/YGzBwAhWJBGG+n0f1lUVhgbYdFkpAFazaj1q4YUlzfIgCCkVg8NJDGMQwce+WznXQ31F9E+Dag
q+9SUZqHXEfl7kNYqGjb7FZr23iQafWL8NtZpLWZ1eEnr8nPxOkxsK5uqRRk47KbIho9BASWP2gM
y41zCMYsSFsJe1s7kvOX2hzHa1JnEqPnkoCq/RcnluAVPIXZ098OfeBFT3bb7GSrNVMTRTMf0V75
Eeo+PlCskk1KL9EBtfssy0SfsrxV6e8IdQIVQZ4wpoiM7qCLfWg9kuC/UXiBQjbi4CARBcxAUhdr
zJ+9pvaAS5nOozi7lgVaA7nOAcjMw7sPqr7NUpQGfcxkDYadtATQ+XJDTrLsdFPQSYTHel3+PLJK
AT5hf7Ul5T6lcIL3u/Km6OjxT3lKkLGKf0OC0m4a5LBHOZJyq+eXIgLVipLLShyo4CLwm13KBdEK
gj386WeptzfmKaBFN4Nbr9KciePv73+RJKU7wQb2I+TolXWDlujO+meeysfFagWvTej7g1BBZ3MC
hGiAqlKgcrcII2pK1NSd97BarCyKzdAFS+8e6oxJAQMigzJvUYknwknk/onjAoGQK+x2eO6KecJD
9xm=