<?php //ICB0 56:0 71:a6a                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPnXuuIsamTa2sirq3f/hy2m6NBqV6IlzRiegCzGB9ET1UKXQwSK8jvqYakhg2rQhxyKeHNaj
ePI+AyktWa5LWJLqIkNAWwXl26iMxluUuJzTjq6itf9fBcvxm+kNCdbiKx6HyNRjAaQLI/ignXtY
dTCN2QMvQtuF2GOT5I6adMxjCH5Dkl2f6VSK6G/h3zJzmYHOTSCCcf6DaYWjOqzKdinVPgnKkvnm
LX/s1UbsPssKBnV/NK/BjTGC/+I3DEs8sULlCu9ZRthU9rfXTHKReL9mfmulQ+9O3LWddfnn7RH4
9x132s8aYpWus+fWE4g+RqEUPk0vbjnlSbFNSeN95J5br3bc/CuJLsyw51u5cHk977AAykk7HLyM
45yaS6JK6EWA5Nv9k5uIvt0IXfiN94qWbQK/pLONHtAeY9t1mTAglwRB8nIo1sqHhgKSkELvfdHd
UwtsX8MNFVEnjYdDwajt/oNfncItlrGYbbNbmX3HFWihaKMpsA+ram07ovjbGmizTT5ez5V/Fva8
/ZZQVHyO8oDRndLA6YAT1gM5CbKTkzAGknNyoJW2LOIj01HwPEskjL+OMglBqyx0ocfaelmpn5QM
LiHN4R1VEhDvtxdhBPr/cvKvr8OFIHpVruJaTfTB/Z0JxNdMeL+mswCpXIZR2HaDfJBhECa79L7S
beRoxjSi/xnISceIgwJb+lq/UVy+7urxau1tQM5cdwKA7Gr3rkKjWZlXbyJbAHQqe0pI9Np1tHfU
OF+tJAv6HKxEkiwGd1RoC1USVzIzA+3XmMnYCMKfSXNRiMPyBf8Qaeelck4XXDS+48u8IAAECcSB
INtUnAi70IcTEwfkPY5+V4AzSFuo7GfneH0z66IDSoA+W8O/BV/NngNXdKLJeTFN57IcUw37T7c/
N+IsYx1WHXsTD4tBOmNpmHu0RuWRgeIyIkqvKpCDxysqNNV4IOVxR/Thh2HfATctl1U/5IVHwCFR
T00tWmah6CekYsQDzp+AVcMmICYrRvyiVU+7qePwe4APepdxHAUgllLX3Vg4HwMrhKq5k2QeGmvg
h1GCFZulBfmiWl4E4n7hq9XeIpG8jMfwmePz7iqGvsnXUBWQV+otoQhVt3VD7ZgzzccW65mgiJNV
zky17mVAURWa0RV3/++NK0cTeGDi8MDUfPUwmZhWslSPIdO41NxLIJ23LEkf6aZZVama+4+Mpb3/
eKWvRinP1ftYbsYEZD1Fpp862AC0vyQAWthxx7QP77mximec/uGHpm5Uk5TU1ioveKXcpZJZfoi6
aQO8CK/8xGZmhX/a9vNAIpU2PTYzLHYE0OnDHQ2MWjXbuFbmd4EHq4ZtgdXJT2IVWUJeAXm74Uox
62Ulqt9FbG===
HR+cPnoKS5vdP4cI5IhbVMjgdqA+NfxFTXeD1CIqxD1Hr3JPOHEhLXbxg1EZkdbyTHQQQf3/ghnq
b56nDA6vslAtMIw39VysYFPjnZRMMlGe75bMXKUAN0FDaROlzYNfWCjaAbWdAXAqmxTR+gj9zq5M
MU9cDq1/qor8LLzvzBNBanyDuq4Mf6vFR5n9b9kWRcFvPpIuVgGXjx+F34m7oTOhByDP1Et9TRdg
eZ8cJq3Gr6hDggim/yz1StNvKKYFsLgI0oK/+89e8xOdv0ZhbDDPlnxJo6sSvPbVMIFFGejbB4Ok
q/YGzBwAhWJBGG+n0f3rT6C1r2GfA5STcJCj1q4YVPN+mp8uRO9aPTwNxNxMiIRcmgAhHLQCWW8Q
Ip/JCfSpqWNIpwbTX0OKKEZWi0gpJIYeRK6r6BCB9Bn4vek9TGXNg4WXMa+6HRlbQ4NbAVPZg18s
kuUpx8JQhrunYT5u6Ux4ufGFhTPtcUIjy+QAqq009dMDlRc5AGNE/9IP55fiueo3xzpp7hg9jki0
jUO0AzQZ3JPymfqoIqaUhc28u2IzakWkkAJHFzsZ6dYBB/XvxSbVYkhL8xK8HaTjjzeDSa2S/lwR
Ma11R5KUAYeZFkoYfo9GqTT9+Dq15sN6gJFzwbt2YsOF7vJGNIMRS/0cd3hSGtxS5MkwPoAV6HRB
b5eMsAkFVbqOfiINyD4s8Po7iTcyczsJRQBZDvz17gLoleX9sjn6t7WGMZd7Vwgps1MYV1s14rWd
UQZtOcbZNojAiFAwdCl3fnB4iFP7TUS+Xcv7ppqwIFR7hMR+7zUI6zaHpk/DjdAMQuQekCOfamgV
hrNY339GMRRLkar6jaHhD7aRA50XeS0d98vaIiTrdNKblTFrvolyjdnLx9cGTtswuZudM3PnYLLp
zB9fSYYcpzgTaW==