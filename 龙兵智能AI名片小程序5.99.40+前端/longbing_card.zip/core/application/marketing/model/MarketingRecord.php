<?php //ICB0 56:0 71:a6a                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPoD+6l/jpSV+C+FBZn+lKv59Pm9V1DjoDSPr6YR5KVJ2QmiWVPGOBBRMGRL67KQJKDRY3I82
qpLqvBaJoboQ8aPYuFEgghRGBpArDDekATo/32mKk83Eb9q6blUUM28rNfkQRX36Kex4ANeaaHs2
1qPqb+8p2SrjWc6xmTmcuRlIO2Q3exp2u5kr1uMpZhbol5t90A5UAxlrjpxjr/LFyjDYt7SkePuo
Us5JsWX2j0X+N81oP2k59y27wyaRNMk3daRMfZGNQnF9Yxq8FRyZ5hNmi87vrREZ6166vxaFoRH4
9x132s8aYpWus+fWE4enS/VEJV7vgooOL27NSeN9G5Sgw9C8oknnarW6DML09FjDTbM/JACZ5Enq
N7Lf672Dtg8BvgZUmiscDUzsju/vowH4rOl30j42WuUjz2ooIvC3G6hS4GW+LRyFpNyiTQPtmeAx
V5Bt5WE0RNEdEj3McFfVfMbvh+NXMCN7AcY1YeXpoOBAW0h+SVSnYbFSHpU2Y8OKfq4HT4xeTxEY
UGqNUZvWr8DOXDjNkT9aq1/3SDUAht5h3PcEEREI9+ajrDDLt3tFQlQthQ9aAmvVsLy3thBi9bbc
7kn8QDSK5ABq+IrzH79nkBXlApWeb4z06IRZBzE659CR0NyTWxw79SBpjLJgYxsfBSUFc1c95MbI
ITCNPm9Ai7k4XkGfssXyBzE7SbOCwslN3qBfTE1S7paRCNUYjkBHOtESMMyxoVc13TjX3f+NRSu6
umYiwRKwRwyAoyRFJ0WioyNCBQ5qlbRaE8239eSNrIr+u63ykh6IpeBel/ZIOebYXyBWBO/MrUms
dfX46ewkvF96sK78U+A05J4hA3vt32rYbcnypdTlLMRCod1U01CTay3TpAUR0uwxbZWuEFcwuBTy
h33zGV4LODpFPKQjYc9pJgCxihA+svc5GPGN4aIsxN4G7A0Zvp7R5kpv7VPoxgE8kZ7UQ/DMkF/E
4y5U87qDZ3xQHDgtCD/W4DLyoH10lDJfX6nK1rXwqGdJwRIdIqdwH6Aj1fPI20IOPThsbF2DkN8J
Bw9FepVWETJpd76GBQYdv/lsM8ewafyOBbv+lEjIw1H7ChwpAWpArXKb+uRdZ35IsAfUs5CNbnXO
pwmB/G2yAp/XudekOtLvoeEQh2Qqw2ic7CVoQKNxNbHcV+YXPh/d9KJ8wCwf/VvrubzJTO8Gnsym
lyWdpnBgZSoP+XnCYGh1kNI0TqUzop++YcHZ/etWA/7YBdIeAeYlx1IX3dz/MPJ+AvVKtHZVTxVW
IEoNLvFCxZCp4mK5jI38Hu92DJ2H/O+dg9kspAkAXDH0TkQie9o0yPsiadha2NfQiR3AeMZ1BaQq
lhhfsRrkZ70S=
HR+cPv6NKmNaPQWgcYd69lGBiDt5qri1umgPHDC1qVDA53tyYkOW9+Gx2FMWEOGfBkiXez/MDKhv
+hZWzO5bh07Yip1FRate9nbbFuSZmg2+9mOT21PPceAnjEhNBQmEk0LB59NeADTb3XE0XgnEuHRf
okiVDzPdh54j8IjHmeBBZJVry8S3ypUxPVSApcqq1fQx+KVLO7cvIytsy1+osabhvxt8PS5DdUp2
V04uff0hdDxyTamvL2/g4wOEFgUw/XmfHJ4vEkb3Qs991ziiKeEyvFTBViza3czs41WeM2SoP9T6
BjFuaFI+Ygu4oq4FiGAGTdFytLAKfll2pTrSBGTc8nqJPmXpwvV+BFWLbJN7sq/ZwEhRS9t8PWPq
xrHJCj+63p3aDv+vXF8hQolLR4OLYvZlp4BB83PQQ6x3nQiGc4PUZFPj/MQhazdxNJsCofkATgxx
gIUmwWUNxN4NqT5oHV5T64YRD7CIKMdVNUvVmwQ1uXBwlmxesXOB+oryw2Pe3eHV6O70vnSY+avd
t8dAhrlbD3hpsJuYR7tMw5Nazx7cscmmGEbrqL/64NwZGTzx9+FcAo73j0pp/mfxBu0Q2garVzib
G9FHIPDD9NrKqqK7AWElp9zadXmJkiG9wNLdcS49XGSs9IaScG6PsW42glZuwzl/sz6SJ44Pxb1D
y+Q98LrQiqT45dCTGZ9SG9cNUCI8oxRr9l7zLddzzi6M4RMkB5Geh7Q7W8Qqje3pqXW/TZRZRRjT
0bzRtFN5teTv5ul6xJu6GIzCSJMN+Yb659kh4LFxQ4R4w02893QdYss6uNsdgU8bioUm7b2o9TFF
oqUggz0HH81KS1KrbhCZB8bT4hS8vfu93av3vWONzjBUYWc4KHN91xUwqcCYByu4ySw+KSlOndX9
vg4VhcFLH/W=