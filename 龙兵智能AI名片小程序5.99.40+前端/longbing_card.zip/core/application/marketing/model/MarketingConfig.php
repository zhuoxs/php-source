<?php //ICB0 56:0 71:a66                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPzNgLBPYCwsv45/1bS0LRGEZuLmwpcHEHT2+gPTKkJN9YSS/F+Rwg3qpIbnSp9Za7ce2fp0U
ZkVTsAx7+MWivXobrrG/tmKPE9xkFj/S7WLqVaZ9hTnOQb2ZvGHwOx13E40M+9d2+8Nyl/kZURTS
bt26a5rIkjCRbjhjTUADRO4EtBOpLSXNbz0IRvt9/1A/pQUlfncWYalkPx+2xzr8x94MP5ZvlNja
85dpD9Im5znwC8MovpTOQ9VoUsKvweVQfimVD5/w7h2+ocMmjOPoT4tqAHzOpPvHtPOKBT2ZBxH4
9x132s8aYpWus+fWE4hDUv23g25njckerDxNUYBBS/y6v6y0fDsIBub2xjxDjbrLCyhOAI59ckeh
wlEXBU9zd6XKYgOg3uOMhuFy04arj0EDsasA6CyKFVymTDLPgja5oQcAVtDd02odk3QQeVpwgdlQ
v0RybUcyNeQe5OYAFgdoD8i+aIE9MZXe4s7bC+OWvYJhHmZGhQuaEP+YehBM6fu3HLqzxIS6cxWR
B5l5X5xoXEl54RxOkaEJCtTdPPEcIQXocoVIPVa5pwzxYeB9PhIIg4ZTbUCB38+HRe32vQ/6nG0v
CADcmygQY3bzLomjPTtvGjc/H8JqWF8ptlOvGfwGrf+4s06JZWRBRuHQukhdmpSaqwY4I2Aa5LTP
azycpOd4sETC7MlHmQ3raTVUi3j6e3SZHnuTfgRg9laByVP1RtRzHu9AN9zg4F3AWiAZZLOaoPQ9
APZGt5ktT8BceNgxlkYfmwsYq/VSX3yR5zBbSr5JbaiW+dT9w8g+4AKk4uh2L7Ea0JUFVRBl38mb
B4OrSCL1qshf57YS+9LXEiZfRtW17+jggNG92DKhv1EWlONwNNuiZtNEmCLKRYcO4AK80iH1bEqx
GgZqCDfE5Guhst2LatS45sC0LZVAEB7q1m+PJDHS1LSpy8aiFrA6Zd4nQPT0MWx5dA+DoMWg7O95
0RL8Oe+Kj8xeJBN+vJgHHIyhMvu594Kol8dQOUwnWHvFlpRwKGZ2PHzUdf82wQoHy+l20aBO3QKj
YCRI0p5poIT8ahe8QPyWJotaKAxu41RODc/x0SG7m7S1o9tuXcy6zwB36x++lWjpi7zx2BDrBBti
OH8xYZgBNwtOvIkZvypHffRqxGxYuh1fuAcT9yWQWHCUxauDtNXxHBglztY8T9v+dVV35YpUR39T
6tv0KUDFIjj2yPsUhvQ9Xfowyg9usOJPdU6X1gKlDwik1UK1hMdwfRk8Qbp++1tEjT1Gtn/5XMNw
gR4TOcYr/6KsrUAfdZq+ntmNkhWOFKdIK93kThkajKmvBnag69TWN0JgUXLeCpSvol5NiWDhEVgU
ExSeWX4d=
HR+cPvAsYL3ecd9ddWWSSs0ktuVbhllTifplwyjiepzOcFsF8oBGDX69K69t5n2oBAtuVOWqeLpe
GrYCNfuWW6AHI9yN7r0gKWgyXFP/MGIJEm12vjQYne+JEUw0oN+uvcZ/Pf1PcGrgvPj9c+roO/pV
yXyRdveCFlzPsKV5EJz0MGPsYrp1dv4hl6Q3aD8KxLQg6aYY/xlxdajDiGEfmJAJlLklbdZL8hRb
42PCJULvPpqkME8qr0gfxwq7vs+yAP0GdaIKDeCZfUSdvJOf7IucAN06Be6ky4ipP5BeO83+QKOk
q/YGzBwAhWJBGG+n0f1iT21imMVvHV0t7FijXsuZUVzvDSqlTsg9/QgnEL7PcpYVUOXwYurWpy0m
EEft6V5NyUysNPW75MOA1QpjYy+pyYahWxxkdcnX7liQsowhxliXFJl/2mXNfgheLNpSDFP35wKX
ZTFZC79t0tbQ3eCuBxrc8wYCDzF05Pb3S6fQHod1nZdlyxN0veYJwfOlNxbA1XszhClCdZIIpU/Z
bNf7n4mXPK3YnNSeNNdYYnZ+tzRyAmam9ocbpNwqtVvLfX5mga0XlhxQznAIuK94YfuKH4efdjkr
I9+zwbmvSY/QWzoIkaNKpQp4vzjwOTMjWRpQG6Xc0QVjR9VWAnkNFHnRbn3tXWkX2fI+VunKYwyx
CqODKTStxDBACQGSQk8NJOxT/e/hFRjLqR5SRXNKaS3h163tvuoTaDFV3q/n/qFb0w1/Xsqh7A/k
5eRM7/IppihB4yyQMNeJN36nqO31vDKQaRwcUOtP5b9bejdTv4VKUHZgvpIl1oJSg9SjC7meMSWg
kv9SGv0R7w9dIQECsbYTbubEKupVwaVkIsx58p98QY99OOvgwZW4goIXAQFtFT+KasRTGjgs17q8
geJPCr0=