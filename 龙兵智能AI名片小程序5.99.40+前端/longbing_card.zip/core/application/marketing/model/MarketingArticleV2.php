<?php //ICB0 56:0 71:a8a                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPq9MJFzZDB+qyAhZsTpEel62uwdarTeClBFJi2ZLWgNPBUZQ2iXTdFH3C+PJwDpB38+Jw4Iq
hYB59ptSLxB+MOuj8yEpATuthqM4J5aZ6OH+H2GfTpHM/6U3eXHg4v8zH7Di0A5gSZdz9yqmelwF
TIG/tF/CGAjgmbMRETEg492ElDvGr5kfPmPJBHuSysjpKhSujHaOSt1ZID5wIfXsG67PrOD6NW8z
8L6m1nGlI26jZk39Sy9JiNXhr6zg5CI6EmxS9vTJI7iGW3KzDyHYsSwb5w4aCz4QG/uJq4anj4Gd
i4CBOYIBE3ZRwc0uIdvnLkgPLtsPsHGHazUYkircD1OXhLwHuYKT66RQEqk2eh3CgqDm15ZphmA1
un1GwdLwjeju/WBcgjgHehwpdPCE+XSRmTM6/MVAvah03/LWGAflkHnffph3bCeOFj2tC2/4D0Ad
/08W1+uGPYpHA8ybl98xsx0kcxN2e+4cZlEdJV1dKQcjoKQCsqSzNbl1gp1mRdRgLx7jorCqf2dX
X7pbpwdVMu3t9Z+jwBlAwCGGbs4gzAlyFX19JFAWnJy95TpBFj9UW/CCNpc3yHRBKL8vO6J8Df6j
BUo0YDtFa3wyuLeoctlD7l0wN7M7zMsivhfMZ96oqmGjgapDFhhRPZjDqmvWbl489l5gOvL0+o05
zUhjXmyFdLif4enBVwr1Cy4kSCpwZxb/BLwkXA7V/diOt619dco2nfl1bKe96PMBD7bbB1NjxCP2
JbiYwUOVgfJxAIttev/OCi5U+bYZoHNqd6xZ+uW/qYB6WD/nHzAaqAaLyZ7V3MhKdlOgQhancKz+
k78SyuzMfChMhGWg3p/3ngsVC8Y3GmvrGDD5oxI365rRekqvidaVlxMEmb4IV7qmdCdt1YPpgjxW
85lJXjTpZ7p7RquBICuBJTIY8Gr3fJfRKhA70p3khSHXyzYRZY6YQN7PlA0K8q8q5jahcgEBabfr
qK6W0XbgaQQe7n1Byk2Sbh0wA/fI0esj5mdbLRqZVlrj20ZpyT0CAV+8/Q9jdDRxpw/JAML2qkJg
QRz1Bsf6R6RalJFH8+jYJB9DDnijgxW5CAwO3xEUJ8AiMHI1ubx2HlFW+CuPjhgFv0pXPaN4McyI
4v9GTY0CBimKkJjv2qwnHs1Qh5IaN01xUvwHRpaVRtkBSa9bp6B9b1OpT9vDsUjPD7XW/iCC/Sfb
0tQC3Hcbnq+as8T8SXaKZpGfUfU+1mE6T56N8My0v3IwDjj+iyCZVVlQ+axxQ4pVra2Yb4uf1dTG
/n0d+iNkCoz55spSm/LIB+/2Xke4cE7f+7//xZYZc6NbvPZWiSfgsNe7MHuXjc/g7GrEWAfc+PeY
x45PlR9AbOnFSirx3m5zpd3lezNXQspLBjFi4BUoaH4l=
HR+cPtj5d+GjbsFBG/iAnyZXCh65e6+xeVmIAibR7cSGMpcI8UkPRv3Q1/WtgQoOR9r0X8F/5Uoq
AYxiFycYhFJvMmMTnwds3wBBqjDFTDxtwFc+PWZqVgZ3U4AZuU9Vxpx3+M8W+i3OcBF2WP1/gmFq
EHy7eztYsx1tLN7EBrisx5e56WMyP4Ps6YjuYjRnxoBGbdvF8Fa78qxEZf9f1Hl+/ksMRDKzV5ir
gN0VMlOhPQoxR5QrHu+u4hKlABA8f30SFJjDPPsqF/FZGHQ4eRr5fo/Tv7XIyU7xp2KvrTeMjaOk
q/YGzBwAhWJBGG+n0f1TVJwctYZ6aW+0YiOj1sOZNnHKvYkDNwyPZiUkXInHWxMibpQc9f+0N9or
KqssPIgOAYhkqctSC92ZC1ABlqKdwcbzEbmY1zep45YXh/add6cVziIe2cxPzMW3IS2WDp1wqGYk
eOlBc265mm20b4fDI2gKvKdaXkqrYT8jaGebBB9TlWupDwTOuPOAEwUp3/gP1Wjc0o8An+ZaBrac
lM+a73baZV/cqX+KzvOPGQEtLKfKMLCmnL5PAdTZ2ntFScvhpYt/2ogSXKnDEDBiRosPUmw5CvJz
3NHUT08jhd/11mhorixWvG1Azib7qHLaIvK8eT2hpJPfp3bu5YbDWfRj+Yk17W0NWIJiFU0sb3ZB
9V8D6CkFbUGDWaDAU/+BsRywyPYiHq638ztgzRXGgXvyqV6+1unxLi3n5n7mRVGQERUft2NHMUh8
Akyx70wX+W/HKMzvVFrvrrzI+KpSijHn93d9/2qTsTL22qLjpMYagjzWte9QdM9lOmoCEHRonaA7
Cqrwic6p2fhz/5Nv2WO2Vy4nmViWOqZh1gUDZKSlAcvvmXiXi8Xx/spPUIb0OsJ0eRe/oH44ucfC
OVGmaEHSXXRmsLW7sbnXp/CC8/Mc2TMcRm==