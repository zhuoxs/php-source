<?php //ICB0 56:0 71:a7a                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPqxq4IaBNUeEkK642Y6PpXtBtQHJt7a/Sy9IV0QvTWo4+Q6MqF4pYrCWUqwgrkUitlqVz7B9
Sw5tXJ8uA39HUwjV/ITjSL2sctGlOaeXsdnnvSiTkZ6AjntkD7WmZhwnCzVWwBS3q5JemoNRtTOV
BbfpQe4BAcJKJU/0MaZne0q6vW9Se/lztWMLg23P8kHE6wK0j9HmZzwkkFzN7BNLuyrFcxznc5+Z
PwGLFk2MzShyzwoR5Qnv9NimPDkIt3bB5JAJ5T4kgDb10rS8wLW1cf+hbmqnWPJ7pKVgXEkKlX6Z
j4Gdi4CBOYIBE3ZRwc0uIlyETzUywNEnVX7HrzVwXSaD/oXIYpEEcmiEYm7vL75abvJZVLJh8anw
QM+ZDRMpVukbFsiwfZWN3csS5BIpK47Wv2w4B5rLXTL/tJ2IM1p2m3vkVcW+7lL4hUEFPrLtcXcw
7OUxC4SCIyCUZ6y15Zlx3VAdGY642A5mGLs88kHcCQ5eMdn1cepmBo6/8f7PdmtwkJGqpzTBYP/B
5+mg7KadnaV4Rbe5y7dwge2VPgAJGXyj40c5HVYEyi0MoIoSGye5oHaWB518FMqE5L+QZ6CcmDOM
5CyN5+WHUeb1hv+VCisbpS1PIrdm/U0mILRsev1S1uLN9Scyuvk/WgFVI+Fs+dVtUEEsvrJJ0ZSr
QzvK7otOyDxKficqiKV0KxAaboy9CJA78sO+LbVUFfhP7tBUSkoqs6Reh68qQD/7Uw8vs9jsnMK/
GydMmNBzsWe6JZLT/JygjyV3pc0AsNVyYbaQD3Xa0l2cby+mmlhCRWNHBdP3qshimaZbDLLYfcr9
/pcXp+wts3Qfeivw7hbNMnPiuhvjk8DzePcMEGCO/U95bjYWHF6Q6qFd8slCkxuwTXNEBzft0T+Q
wwoUO+9jVe45sImAzQxNwDkqyGhScrohYWMwxe8fwMUAKVcspDql8gFHysJRqjR7BTO0ZVye9le+
fhswMWMZv2tNdIAuTnxH1qifqEj3V5BKtMc4nzbHapZzm5VSPL0GxZOpVV4llFFNf/Wt+yH1Eyj5
nMcGJbtNEYxajh67FQatxKpCqh0hDZQ6yn2Ak4ln4tiFsb6NPXymrMfeI47SfjzCgAAaO1esnFlb
rBObQuNuBgv4dAMDzE6k0A0O3fhrcJ615o9s97rLxtIQfDu+9MYiOsbwsXRunfCvFYtNDVtxBfle
urm6/7Iez6Au3KvXtAm8o+vUh/l9xTJrFdThAnXFz/63ozOqruEaumLaeAgtXftsnIdTycNJOW4M
YaTwK7otWfjLm/1CpZ+oIvXSXqrXgj8dj6EM1S/KlGaVh48rxsFKih2faVoA3fOCGZrOrgR9Yr7g
dXtO7k6XGHdr7VSx0XVhh42FheC==
HR+cP+2DXj/nRtiGvpCJ/7OzWpB7O3qn74wAPu3JBgTX01dq6nCiODOsaUbVkON4BkFN8UIWkirK
FkZ5bLLWeVNcABbZrfSh7sJlsDtiGXnIDLKFetwSnzoOEmgXQhE51tSgvLWUrL23ivZC8yaahFIc
GyulvQ2Jjvk8+pjI/8F98iMzO08J1Nf8i1yKMJOnPmKLOn9Xijnndjsfced0t0qk86HWtBqR8km/
LxH2BBcUQwNqzbtJXYzx2wiWarfpwhHe4o8ps8Ij0J4YYqJfu3B9PdYd6n4K6JuiN81R0pE0HYxJ
+93qlegk1Cj13x42a5jmIkukpLkyUcFvHYq7QYD4jMxL+vJvlwWaiD9fjjZGX90IW4/l0/lDYHYs
MIzqsB43GYzEu9V9K12nPOfAOZVHCu9Favi+q8jbfjArx9NMjy3c0TnWD/2b3SFjgnxVPuODUIid
gJMONsualE0wvq7xepqM1WJVqsugMacFVL9C9X7WubOq9gn7HBzGY0rd67qax5ngUs5vrzAX8xDf
P44YInpxvsoLQ5GWneAhpDrGK8EBX1Dt33SEL2Ye/v/iyv478tA5gdc4o5j9FVGMyyAEfECK/9TR
OsYD505UXiP+h8ofRf3mbpkbnH2Xzayo9gaVHLKqG/Wc4s9z2zuB5xBwKm0VdcYq2kqSc4OOaQPi
odYTvW53ZMr/4a7RU1kBlA1kMh2t68use+nWsFgiz6JtK9TaOHNFskSjd6KpIjJOxYdL1iPW7kcc
QkhmQH879YVCKlJsZTxt287FAcKJdmmc2d4trMDHQH10HPuBHpQ44X98/P79LQQAT8+9LRMgagwW
mk95RS/ow/gW7O5uSe1kTU05xepwD44q1XJ4yS+wGqA/mXeBTPpbH2bNTg/uU1jdUm9ecLSxGrdG
57H9Su6D3ALbqHJ1