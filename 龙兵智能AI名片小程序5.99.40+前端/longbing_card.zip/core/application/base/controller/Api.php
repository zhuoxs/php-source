<?php //ICB0 56:0 71:bc6                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPrb6IfZgeaxGcF3Vkog5JViNakkPjlgXAU4L+0vgVy5aaANitKch+Wv1z0FVrPs+o3CKmDSz
ck/INaJ/8jy3xQgAmMci/ZPg3wdPZgHTW8WHRdIzKviPY8i/kKvUP/4Gj+gakx+CYRxBwqUZ3goT
rKSUBIqvIK831hPkzzXgQUSqZWK4xRWZC0npBYATPxTjAkhiNp+cknZS5VNazbiYf0xUXQ8eMqTz
D5siDe8esAwkNXxSbPFfQ328Nglwbn1/TJgCDshZrFMB2gHe8TrXBHZHDOF55z+yPVDz9jfx/+Eq
H2UmGmjY98iuEDlgO3XAftcW9x1pAdb15TCJjowFoNVpOoSSuGNu3ZPzUqjArt2VVAIhdToixAHW
uAfdBBSfKg1VN+kDPQ1/t4DsDLqUIE25XPHDwivvTSmaGEj+SDb+En6w/P/vKL/C4NE2k7K2X9Pk
mXbL9vhpIltt9IkA8uAyIYLYlJtW7Zqb2LoAt/r9wplZpfc/SHCq7YYFaSHXiCAT2NmNStj8jzok
5pvYJ9JDP38FNtMl+AAF0SmXHrCB0mVOTNqUxInSuwqANW9trk9csfxC1pcfEy+3f/UcaiW5mEyp
YrjlKQcDb7G9Rh9vtqlSeDPRHIG2lr0EmJWCt6a89HRYHGg6ol6LAyBBxJORTqD2bp5V2tj6zf3x
1RpKkvMKP//ngE2apIzX8Olmw6OTRFQWD13HQ+ZxS3jxnfkEZdpGHXHvjPfFIj8+RKJpGFf4nikK
oHARCjdsRouIwwm7IccOCbCuv1TqIN8lhCTL+6yYgAhmBc2vd/UgA1GgN7FhuDfxB/94k/QH8Z/5
Q9VFOaicfQ1a5eyDR/69NB4RFRFXOyWzXekP6U2JB8LweP49FZNq23dwzvRgv6WqvYfb4NTkmM7L
4Ss6l+anhdHBE7NCbjnrDmwo4ZTpR7GwbbeLCJw8yXzY2PAIihulAxRVsCtXkwkjLjfr6S20auMf
mqiireyDEIys/j6ikbBgi3MGiLXqoSAkEJW4p3fRLJepgOSJvOR+TUYJtJ14qWg473yzYnA9I8ii
NhPWrFd4XrUw5g1Y6MY9vMez1R7N9vmSMO2JWu6FmG16H/W10VnziqFSrcbAnzc0sUA6mDOoQm3o
gQYH3Wrxm1oDn6EKOsDZBOY+Bn+QVmwUep+8PB4RZVXbH6ASqoH6OmAl9cShCJ/l+hwjgX5Xy1Aa
PfVOPkvwEA+WQL4sk0II/+rJnhbNfBMejOfiar0qnK3rsAAI1fs2pVqZPbhySbwgmf3+PxnRgIY1
61eUB2C4tOBH+tkE1IzHCOIE0++cLN7tSMd8I+k0AirDze/EnwkJ1t0P+s3X1ascpmi1t1zEb692
WUdolwTTO+avdtULfWG5XFkreHPdpp+O39VdnvwM0tvzr13RIivOGaiGQTsRlUcwLoZxQ9Pcj7Jn
t02nojOQrRZI7n3TigMhsml5RgR8lHiWxuZQpKVk+fNDMYP9Wx4tBN7SezA/ithOpjxPyqOdaKT0
zMsbxSdg0Jc4j4ZzIEJAIyMzMfAV6x6MX5r32N0lxg9D5+bLPtm79Dg3yIV4yDsNLnHCyDxgC1sF
RHob7u842/HWDy8RhYvm9mBE4Vo1HvEGV09vXUrdXA2A3Cge8Di3OmSHlEVSyRcxyV/Qq17cNZT2
QeZrWUUAFzNbaqKNbfH3511FTh9UIy0TFa7ZYsva0hA3fpi1wuK==
HR+cPzNWHRtTIhwoyrZGdZQw7XR1QQuk6MiHZCL1OnxRHGrl4267U5c7kHl205NX5E4hI4EaQEmw
tz3w7mN7uIGX9F7SgiTZm1NHD5o0BMd/UySHJOwb6SNNOzIJ8yQdaIi9yzACPuqRsBUVLM9Pk4Jw
t759XS6uq1kSHGn9rNTFOQRPHnPuRt5PQLtmKjDIuKGo+yFZF+GWxxlduhqT2bxKRYhHUIA+m/vR
YWAIDamLXHK1t40dNqYxB4TVwWu3mNqgcedcYLI9D7HSlWC0qNTfZwzOaGz9d3cvAQtns6k3ZqOk
q/YGzBwAhWJBGG+n0f2aSo1afGJSdscvr/SjXpSYHa3nBPK8QkJ/AatrFSMRDsONza6EtRfiJyXT
4rztUGBaKC6QuS4H5KI0vTHjDPcxXeBSMSlnvTronLMYt7a4P3FyXke2llkqgrr0bSZwJysnyw/r
C2g4E0g8q+0PxF+SEYyVjFR1YgW8TikNTzvN6JT9mCyF52Ek/1qib9xFAURAuDPMgRUfbl16IVY3
2wirGu0qRxgiFvsozYG8TbJzit05INKUJAgKabYHzuebtiS0E2SCiWx38mN+D8ESDhkfLzR2ByZl
x7CdHhdzw3D1FHkn+EPjQtnL1c2ga/bfxboE7Tnw0km+EhU7GklLK2HY2TvkEI681LqasATIlU6g
343ypmaj/rtzsgQxF+Yqc9i5nIdkoO+QtKVJV6aejRBqbmruYt3lg7GaACXiFReTCIicJCZbVnyf
5qjZll91DV5gQK+db64+32LtMr2K74aNZIlDi3Ss6jUfLrE40QboUvp1vIBrmnGLaiROM9GJEoea
EBCF00xlXnglp+z4MB2yV4yMbPWWJVkovJ4CqLDHOVu2O+6QHxj7CClFpP58XtwIf4B+rJrhIbkM
yUHJ4XcYPVnxkOkQ8aJhzqPg27cwBD4rXf4mjbqU1wWIokJky7sLk3H/bFP4XpvjUiMOlG3Eemj1
nas7c+5LZoQoIOmm8aMJYegl2IufpoQgdj+xzSWPwBv4Sn1LRxY/+Xp8waPawh6xUeSiBPIMQjXL
xCXDp9O5TACT+UMQj1ywdfUSulOkKrFywSw+Fnu6CKzqZjm+CIQK7NVnqjJ90F9971muh9rNxrA7
/5NtIdptVv2BLwcI7n4iPybIXaZLg6WjNWXplvgBA4fJ1eqVbhxbHbQ+u54pPQf5odbK3WuQIjb4
8ihPpK/deWXyrkv5wMn0yZE33dRcmYBbxK5MIrr/MComsTpwta6Gqgckey2wzzLfxBNLg13vEt5y
Gk5WxbthCSuEfdx/V+PAnDk2K2ove20O7fv6dhh1FgbXyiU/4+rEUsdKDs1Y6N3OueRSrB6RCjn3
cHBZVzOMnEpr4SGWJjshhwHQN1Ht7ul7rwNd8v7PiGV3DP3SQSpEV3WGytUVJqVWsSZwJXzFWpIv
LuzTwHsfbQVJtL61nsbaQzwIsngQTfV2GmbyoiBDyHRAWwUlPtKaVEAiL1zYqTi0/DfLslpVaKME
FYuY4ogGwWVeu6sRZBKs1tkmcgLeoKQ9TZKKKfTkvww+EJZebJR8/VUFhQL2L0OJ2ur6uBoExIA5
qBYp6cuzbZxDFg6PnevKTBtRx8cssbF1yd+tg5iOVTCfu58pkm/pEFzz