<?php //ICB0 56:0 71:eed                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPy5Zyq1rpyTtQzDcO+rorzMd5FSwjZFMuAxJt1DB6euYd2G08LmrWb6r7hNlrGrC9Ayejjce
M6vG75bNRWcIV5d8TLO7xv6yCm0DGw+t3+dp/uHZFWApcWh19MkP7pYllnmVOogpizzDQR7XKR4O
zxueWXGRMs9DYTDNrdeiSI8QtT4lBGFNmlrQD/Y13NPAytEJA6EkpkR5bTJPJOwPic0CQJgZDWKQ
gZuSot/8H3vZma39g1Tyd2Iz4buwpUCnHATyB4cb1liNqEXTLlfY19SuBCM0mUG2EUg+GrH/j4Gd
i4CBOYIBE3ZRwc0uIiLkxg74URW3Ua8O8jToXSbp7lo7K+oSLlWmOFbl9LeMl9XDTRHPTgMan6xN
n5v2r9DmGU180+AvrVZNK/puiNO8ARGuh5ZTp3x3H1OPDDght86YOXYXb31rgKY19zcSsFvXNM8h
vesq419iRvZXvYO/VtFVyBSlpnEaOccxqQohT+bV6I/P0VWB0W2r42qaOV6WyjdwCmxHruJQ8xrz
/7Eou/KdWs09I08Fpe90h8sP/1fhuC0tx/EKrDS5AQvFoeAFa0mAlvVn0XlsHUMZFqactXEGULKL
JK0ZV8r7npDYTqIlf589sp3/2zHic5JkhSYzcpiJhQUt7HZgPBhNTvythbecCF7ba6MI1MI/hSwk
rzlSgHunAdQVwdmu4XiUhZJap9ahT3Ygp/NSoTa4HlCb1BDgB5jt+5wSEZJHOBtjlzqwDglJyPxb
LiqqsdVUIPeGlOzbilxDYC9L9l846g4tJBpfKUVpsXl46lcM/X5ZFpG9ocdHIP64G7NT5rjgxwIU
+P/MB3kkJw+EajO2IBJiUEbGit/yDdsfaf+KcHuYzGyicbh2N5pt7UlRW/LTjlVglG3/FtGinfqq
IoN+y86LNaYH+IyL5mnhGuQ3B4rG5/pH1/NsK7+31un0A4Lo+wZ4qrwPybL6E0uNJGax3AzPZSya
iMUYCj8c9tOlMYmss5XFiNVxxfN/EqFY2T/XLk6vY2VwOTBJLwMyTVtNpUdhaNMTbgSTpzVgtUNG
h8YKvG8YV+iGwEG0UkW2uJZ20U1iscdWqMQA9gJ5Ci9gAlVDxgIEPZaIkx7zUfnBEuvoE1vbv9kO
AKNXo5nPmcp9SGhMVbUpqm0JVRTDDoYMVJVirfPJCM0bpKcTXJaqPRUdVD66m0T3cyv9WhOwZ3/M
5ud+rtRm4XKOR6nbiV6LE/ms2ZLIyC49dIIgoSNuxP2NnprPq3BhiLJITUyKvTRcjiwShyf3xi1Z
UumLyt1TlLueGYdqpAEj2Misso2mnsBxpdgr1uFxG/FUPbwGtblKPWaOljFlx/wVikIiqi+u1sNZ
mcivieVrkbFe1hunlZ8w6hnRVk3WTug4cEsAGnF9xmJdeo1qtUm4OYYLPo/+SkVYUbrm4F22eX8W
qsxwqUyJ7emiOuQxVdKhpTGkJUTLwZVj7CGXD5BR6XqdtTwT6SmYBHOm6w8xxY6sYb67cD3B6sr1
tP5U+cjYCGLe00H01Ia6LMfeiE/GPaWCDXt5+dR+8cTawl/tnRp36JWowP6bc3b61aORPhGmKt2+
/MgEBWHDLSTQHm7DjEjY6AEYzoR5i6p0su/XcPDBpQoHn3SGDz5HmdhM4VakdpKuj9hH59UVNI/Z
fFZqefFQzmNMTlo7Mc60bPy1teyJxNcy+EQyG9WrCxqGeR9A3tHHAdg4Vj0b5p7/T93IhwiSjzNj
w45pyQpOMe/04OtzseTiONsJilrSa3KC2fpeyE47PJg6KQ4652H+rPx9suXhGcC9AwvsqJaG9t+1
M1GC11GNH14XckmmqKYM0xq+9SGnbl1r2FoK2/RpocqEiM2j1ffVxH8OJEIfUeQgML6oJCVDG5sj
4IXvDaOH82yPPpimrsfrti/YR6+X2OLIGJR0E8rcQkIQdGtGikdSMq/GExtZPfbhIdh/zBR6aeV+
EmC3Pp3ZiQWTpM3/eGwiGn4R+08z+ZILtsOajcqjBRfVeIYgcKk81DYESBqCz2vS58bm6eYzwG/Y
bHY++rmKLSURtcbtcqf856GZSwcL6L0JsFs2p/9r61o/MlWMttTbG/1IAmVT21pYXgiv47naHatb
2iVc91jmo0RB1Dq9NUEo4DSSuU9wnaBBnNB5PsgRE0dbRjLD5jI/046DFSCbDlZs029CqNRyGY40
6+hJqQ+EOq911QNM1d2t8/AI4ykDySDaSUiUgfxlfLA8ISkrGPBcwfuJsNl8OASiDUZcRai1/PZr
ErHfAtXPEejIpIoUbGZfke72a/CsLVNMKSJlMp1aarq0LkmvgJP/32qp1Dk+pxA7Ql9KsKStzsNu
z9S7WKwULFq3duFceJ8p7dwypqJjRgLWRaJ/e0ll6o0dO65u42d2zMlTNUFmrdJpXM8/GKqZyNZ8
eyWWOepVGlReSCoFVAp8qRo7mOyzPdJZduZwu0aEXUw2iSJ/UN30HI1S4z8jAd314s37SOGx+FX+
Rn1If/KvD5C==
HR+cPtgyhkJ1c1FBzmOxnzFcCFBJhCRSSVxXBPBJ2vHODznracED7wD5GGBpFujO/mbIUGjhE01c
z3GufPNQH5vONydJ5EyzSAYpBhWvZn4Xt7cvpTl8d3Aw5dL75clJt+VTePC5Wmzmg2m84f75UA+8
d1J1jFLCkqA2okLFk0cA9E7S8/C6Zgw8kMgBHRGqvStKtFwH3UlBOsJmbM9BmFH3xRHpYDM4Ssok
B/ST75BxrFiEA3e+WjmC1QtoT8w0M/cXXW/m5oihfOnkedaAzjNp8qSXZgZ6ZW1NlN8EhXgJHYxJ
+93qlegk1Cj13x42aBPvdc5d8n1FVxlgT2s7PYCJR3u7E3xJ7OFkYO6qlW0bWohBEWMOKbDT7Nue
OoXCw5OrYTOpEHuvGJIBuj4qhQULlije1LDc51hwFYZ8pSXUTQsya1BwPWpjjauuG3wpa9qZqqmz
IQaG3gBl3vLeMeqVfkb1XCnLJEDtfW0I7fCX2v8YWg/YxO5B+zPqPm6arWo3NqwedSVtu7hUETlo
emsId3/RGiL2lYxXrtaKOefvAB3Ya01PYkXVS1k1ZwqgrhxNaEbIa/XDuZ4OEy8DfEztshj9cfBe
JOZOiRzL9gI+BUK528jf7dky38J/m7WFc9YYNM+rhtiDOJPlNlTzB6pnnVOl27dRhwfYOYA4KzVy
93lb4o9Cwk5bDNegH593GDroE7UJOaPHvohxB6ZNAC1dTgYIGoCjkPgL03/iC+sR3F/EPZiXx/49
6lPP1v7YIrpyT9OFXqp5qTgTt0UFjBfBMOBe0xAiauTOfHOHQYhHnt4o1JWheELIiKZvkhgFhKdF
JMlS6UMDplR9zqHnJn6TxfVPBxTOq8kFBW0CwDXI8Tjtf05z/9bXq5I01fVem5GDb8kGuRTOHse2
U+zHAbvAHbCJrp1TV4jenSQTfQBJ+MPkb0u9SuECJpsE8jfKLfnVUurUTb8iZN7Do7ZOAAYiwBdn
bTwWjptxlyRYhqZsyU/TXxb3pYl8d2Dvql/MwdL/El355i6O0OBoJSLsMbq1bp3e2RzJHwCjvD9H
5mpwsEbwWJhjSE77IX7je3ASeu9iz5bYYY16wHdKnT/IguJV7Mbn+KdAdcQlKTTtY2Za6njWxfYL
JWvacD9jgOs2TLnVzcczU3ygfwmBEKDCtx+AjaYxlEV6UzoGckXy8B4YQ15NTBYnoBo1uBN8WLWr
ARkuZhAmKCjlQlms3Mj4oPGA+jqUkWdIzhMo2kNyXHFz7/M09dp4suDNbV0SE4D/DV4bJhSSdZLg
ubTUjuIXHSA4KgewLhEfuwDK/XKsHJ0/4nNWKIkiYnEeZk33R+6U2nCPeLN/d5HH1s4f+ltlsWMH
X4aHJxtGMj/udAVmPYaCdzrN1CvWf7/Lu7mfpJhQq9zlqHoR3bvSi2JEZttZBARH3a4/yeJsoEZK
1iw9KoaIcVzeY79YbR54cyaRqAc5RbcT+QgTJWd+lJap4t88GBehv0u8OVfGMIkUJfJS1TCUnOUR
1WCWnEXR0QICSfg4ZUBLBNuKoG0GWpqlvHzQd//y1rNkJPoIYRSNQoq0gD+mnO87s1pMwqKK1iog
cxFEKAaW/XKHmK4U5yPVW49P7aJ5Nps7wqIn4R+cvfRFSjqsMhgbHWoV8zenBcp8t9dGS3dm3DtD
ZroJgu6LMA8Hv184xBgLw4bA2WFJYmRaHi8H7QX0YF7ArBspB+cSwU/jFetcXjZrh98zzkMG6dW1
zdctcCLVcEr9ALEho3e2xXpZVKS10skaB/7HvBQMvDVNdPfprH1150i5nKZaDgprw9eeCKg9sfHm
M5CK4P3d/r8Wc7QjwTbzXgCEnlJkzMSEhK6RTDwF7yoYT1oMA6iM1//hVngKk6f4kAGl4Ub3d6uV
EnDB0uc3AT/YzgOtR5wlOQaOBabYiwk0VmGqQA5c6WpVLEnoky5DXUSzsf/yPKyEL2XwQ7BUQsWd
fOyuYF3OHcUicoaYA+TocTj/Hs80j/phgri4sG2hyMFOG9c/rKwAbiDIlgGcTOOq0M3D8mxXJOR7
DbaBLACXalor9yXQn0oIXojrkdKvSftFc50d0EYO20KOAWUaTij1kvR/eXoKqVC=