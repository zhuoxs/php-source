<?php //ICB0 56:0 71:e2a                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPpRCtTkL5YOS2tj8+6AxU9JTuxIz7J/wkvSxwsbnYrnNmPhW64CiZLNDzwdiIp55/WXxCdyz
XP75n0XMtYx2QIaCCGkdwDrfNmmEru8eJSKSueTNQDJu0QYMbWL44kv9M0EwiuqFyGPKVQR4/eMW
TPihHhg4fvvkHFmSWclZNI6N4hUiGiWQSbqdZzWA0WPrMoHqie79eJJ96UPdRtwZWBSSvhQGf56o
SEuMbxnB/WF+/xBvYeZXwUWacaQ5LAfeExA7mH7SK+aks78Wm+5uOR98fHKazFT6Xe4d8vinkNjC
j4Gdi4CBOYIBE3ZRwc0uIaProtvcZrZGVCfXczToXSazLR2yPioZrfKkbUAGRME9pBKoA1WQy0j0
M7nrPClPNEdCiShZjsob6h7plW/zxQyvtfbsq8zl/Z2544AscsNM5DUXRlLAqe+4BYS7YyiAaAGG
/i9YMJ6Tjr+fnmAanjAdTwdva3Fmi7Jj4u0mQ9Mgv+cvYRb5TKbAmgNR9efyjNEaZd9lzZDM0Umx
ND/ADDUlouUAFK7TKpDJ0SmkH4vlZWzLMyIP2k8Gjot3zq+rtCHW4WJl4G1P1wVYBIEZH7LWEP64
BtQ4KUIbPTMn8I5Luo1yH9gbV+d6TnUIZIXuZ0eYhVO/80W15/MHRT8alCqQrOZa8u7LX7Ec63aI
jYTLGdp1h0iHKC63psV8sjLhMo8A98GA8EcBVbNj4zZUQQfxIayegVYJ4xi619HuNEphU8069gb9
Fi759dGSs6smyFABAzaW+bM/5y4c9nk3s7stQVmZTFwcVr7mU7MhRWqosNUj/RRU9Wwg1WnTIzHQ
t5vNWrH0foA/aR61GsvBi6tEk86cFLkYgcHDoZiIV+AowASZno04LASKxbUSw9dTiZhEfOHmh/fS
pQSID7GZi5DljnO869Dex82NjVV02H11zPo0jCk+sbHuI49V6OZE9Q19c62CB5gkX9r1Df36JDxW
SgUMx/kcToRwKBdBKYD7r75ChUxxoX+WksUiRpHKpP2cp+VYlFmU3grARKxejorSPtIrs83XQKw2
PPr9lKjlDmZQHfAQyQPPghKV5Sxezpvi4KbdAArxhScwyAkCj/zb7cIXZgHc5QaZPTNut2q/E0Eq
mlTdoVp5FRaP/RXt2RvPzGgS7P/j2aTRPWWvz4rBZQfqLJ3MzF4vUtFlIcQ5rrDAtuUxz8iHTlgQ
JWZ13gzlICG/MYPzReLDUIAxVjItvjKPHzbe2Sg1rVbWaXaT6ykKyOxpXux8Fr6IoXu3IVokmP2g
3gC1r4nCt+XLp867xAv+fZ3/LuOpdf56/4qrDVMqYT+i3o2B6zIgy68JwWYnIplr2nPR0vtc+XO9
vUpGbZ8ja8jL2P684/qJPj8kgnH2VeMhWgNIsHdMJWLqbEJDLXdCK/KCEvU+NSXJrkIEoVg0HRe1
Xdkd4ScESjoGdD35xJ8LhQ02MS5QlmxuFI4nK1sB44PysJ+GfXyLGldqCXR8QuPZE7+77lTpfNAM
XU7rB9FzNPYVcDPrd0Bze+YuvmOHsDnWK6DJpwqZbCz2gglST+ykHmOz8+bG4YDC3bruAZZawe/F
cPe6LnqmAE9hbs8TIkJEhufLc8YZ44GlDcXR0rI0VgxXuXcHrzYPXPz/NFFwdZ/6Vs2lLXSSOb8F
pGIBtwRM/3FYTbDNBbWvprytL9xEdoyo+vyGgBQLKiLi9iRTVgo9vNnMcsDVMpIMTK+cEeIPhYAP
zdalGx6EPialvv73m49TUoAEUTZ3fF6jLdjcs2TORaPnraPb5xmqnb7ESyLumD3RryobAx//KQc/
3VhV8F4KJWk+Nv3CMQiqI1eLM4VZy7j+QP/fDbWP7HTW1NCI1tdg3CJjwoxscg7LVLvqMf8cPVCq
ELzz6yoFoIeouFtbgS0AI3kCDh75Q70KEqSTb28i6pl6QdI8ldyulWuf06p8Vl6EDochWMsWoFuV
nepQOqnkpXiskpQ2UwHCLRWPlo+/vbXRGY5j8Yl1JtVv+XdZKFsnortJ/Km42GGhqXtBHv3mmAWf
hKimoTdYASUh/t6c8GS6tUPW150B/FTqRwv7cpzq1o7KnB3Kp6v7fG5PnqhCjwSuBMHbCkbkLJzu
jI5xTkIsMnU16ENZSU3AtlHEDpCspzXtFg6up/5iejWEN7MiFobB/MuP8nu26z1EyV1mcDyRFYrQ
velEUU/FEtFJ8+01FsJ23U46PMsdJdluBuwsKK7j3W64eyq85gZzdrAYh2NW8tQLj7oL5nHkofoI
67OcMee9xSQD1opn2yxS5GpxczbX/G9yal/vIaAqlU3lHG===
HR+cPxyMVipyuqBaag/hxru8hQlu9LBdY49r5+TJHbjseczgc9Yipqg4bJlnw9mPpRQGePn60Hog
qkT9JHyw4XRBNKxDiAQKM7nEA/0O5yP/JOnWZAV7LbV1Qhmh6Mdj7TJ/Q5dc3aUu354IKWgV37E8
VmqNs8vh+ZTelhoiA4+WMha4HgOBk3TZJlUq1p/gy13yH433TR9ySlbot/ERNdULDV0Znvsf8Eaf
pUM5y0h+aH+VhpGtuetFqzRbOxsrkn7OIxJ3wnquvsP3VIf4imDKRtprxPx1BYKQjiH5wAh2w4Ok
q/YGzBwAhWJBGG+n0f3bUJPMTrvpwh5K978jXsOZPV+JpnJCuV2oMT2ZywR9f08UVzL7xVRi/Dr7
kTRLBRUQpC1lecri+IFoYPrl4wuYpwD3fUhrv7zwIK42VUAI8rhtdqNz5mkq+JR8cnGog2ItP6h/
GL7a+Rw29UZA+nT6IRamTEy2xgrnzoFb18mBHkcsX/8XKKyFYtuEkipiLU/aqeOXk+brp1KEYKOG
opHYePLXGJAMr7j1rdD+9SL3Mt30WrD3Jvm/hyb+r1/H793SHtUw5cDlLTQB6UvpZgEcZUTTWT46
SEuqykM0IbtrwLkLPasHKWy6EfwaeRKQOj+IcYhbhK2lgBRGV0v3auZrVsEOs6ByE58Gk9VD8eXX
kqTh/xcA0nalZicHvWm+fhCrgO+8Q5ryXvm7yef6jecJD3zAyuDyFbAtHGm3H+1PC4VIMhg2RjaR
o2t2fKJjkAho1tCQNoioufhv+GfB40r3fo2BP/cS3cFGBB6MEO3jMfoQ0i6aOYn4rWrAqbIBa57o
ly4rueTamhq4dBeR6mgBrUiAoX5ZbK5lDlP6XJUVa0ZWRPAlAC1tGBF9tKc2ao8AU058W1/whkdC
2N05PGvHWLDsHQyEeMmnK22/AkzIB93gT9SRUitsa8JTjtsE5gmCBmXkoRoOqNfKDG5KlmrlR4TE
D/MZxHLo1cq5TDsGorzx2EXqAeOxs2IsamXPWzgqOKJTorfnsaKWkgQfc4xo/r1WRQEEoGDci80N
U0GgzFc6cTmlDmg8N9n73tlU1UJmGyT5Ca2tQeLRtS9zcEqkQECS6ZzHcbit//tVqGYzSCoFBShX
2TeMWcgI4xX9kUwxjWpFL3NVNeknRHYGATwC4+IqjHJDAnj26i8isBNW4JtZpPVAB5nYVG4DXDzY
dxfj0SW61I5i0OacFOE/rylQYUihYUjpwxjJuRYsU3ZdYqCbNL4Cwzs8l05VoDsXKF5MUKNWrv29
b3w71E2bbmzgXgdgfp9gIILyf01gPO/oj+M47raX2cMigbJ1dcllVFu8MFaC7rhRoTlpLJ3fHASq
0ciggQH42N6H7MxrO2d5gF9CbfzAGu15lU+43llrvVMTf09+GUDNbViEnuE9Lw4CAKTdUIvsE7qY
tUup2/3yVcexNA4lfQWsJX6oDc+hKBCSoVJ5MNx+/moYyWEupnQHTjCE8ssgxJzhTN6hrOtkUEqT
FnW88MkCyOaPQmDNXhYBWpQ9nhLauWD0C7NA0AlqV4IUHhs2JgXFwvWldJw/yNPR3YG4FbYvwoRG
cIv3vyUOZrQzo1FvqmHqMsO0rL4SgUl/YgQrjJapK+kLO9kFI5zZw+jFQ3eM5XXS0LShHeya2MPM
4KxoCHk2Fqh3bH/ZHPgzYx093V+hvLlcXfKwKHgzq4IWpqMC24Bfp+Tal5lzv0RxQYlNG0O1NYOH
BdI6bwhiwYL+2EaoaBYevbq/2gysVwgJrevECoAmBbDEZd0jk+ws5lGDrDoB4mDZUUYXJ29DSwzm
AUi7R9nc72KHHVa5VkSdFsZJtfbno61qStxWVRIA41JxeWC/PG2YVOyJH3zEsAhFWQNpD/KgiFna
x3HUr9Nb95481itWVDiU5i908yJ2XybBnP2DepRBF/JtGGpVKYlscoJwc4+eS4ecifrn3db3S4VS
+eB3gLTRAmi=