<?php //ICB0 56:0 71:f76                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPpfqwGEFsT4qFSHy80DhM9y40uYLpbg6xflJXzbaX+Sn2HyZmIu42hwNaZqLT1mY48XBiKPY
DVAhSbCZlt4OnDmF9truLzKYPOfEklRFZuFGUbbkZteg1YfDwOrly5q326EnXU/3DKaqHGVXtrj9
AG2RTHQSuYVuV5LhjcyXZFk3NwJmj4VuMUMabAcniuMymfpIa3bR9fkdSn1SOW8W9oTTFst7zDKT
nW7tgV1YRDCWghYCyHrLNqgulyVjpaYRvoU3maOIHqdFGZ1ztletU1Y+A7vtutUb3GChaSE9j4Gd
i4CBOYIBE3ZRwc0uIh1k7RIHxxvnEzcxojTw8iih/r6gkqZ/eZwEV9Yddw7jOtD68DtupslzZlkH
r6NdK2R2lVENmtj4WdhvdLrWfFBgkUU0t+7UKSpHyifk3GZ0JYeWSqVA139DjWBqMih2RuZlhvQf
PuN5Wl4+AZ6wlpZD79/hzMk3MRA8xkb/irlt4b9dW/GZhw8rgdLZn8Ai/fpm+7jGJWQMxLwFXRmb
kOs7n3A8P0/X1zoDldOGu5zvN4tbwKl4BPokAYdaLv8w9SiwDJwtK9ZZC5358c1xu8pRXMmW7/4f
uiYdku0JJiDstnIDtH7L3TzhEjwqaGYO5iTj8zTQiLdR7nG0PmmhUeKtBvDsdmaZZ0o72z4N7Rar
YceL8VThlDo6yGtp99Hc8t+tneNzy5EsYfnHP7dhlc57N9M4wUkpYFaPG6uiM1zF6RVraGFYTgeL
VJlL8LRUCWbSfLilIIYIK8OU4ejKIT07dmh5+CCSGduDt9TNibLfIAgW/15PRH9gFPYmtdzgwTJS
lPqhZeSAOFbWHPYt0XAHrnA4A01lzIeRqBD4ggt0H55wSK6VT4zSJeV42LHskkRB+s2N7tO2xVL0
L05BSOaTqGXCyqCdgxiCTEs4j7D11NfGuBjeyyGlhlYbvRid2cNi/YHMs+/W22UCp4anG+UpkHUr
sCb9VgfgJI6QO4zZwDlpuI6maSoj5SjbHkVRyg/I4Aut2siFJGTbgyoGGYJzZUq47p2S35PiKWuU
Q9u/mJxj/Xy3GaQsKoCs1GLXVeJsnNo4+7+S0nFm4S7aFIpsxqiRuTe0mT0dhbTNon0dq8wBB1Bm
V6WfIu5ce8bZJcoVdH/Xta+K7uF4WBqZoTsVkDuKUh9kebGTVBHH1tKPc17JIE7D50k8FxyRuKRo
U5sE+YYg7T135CJaOUoWmdnudABZ61mRlB0d73IHl0NxByrf55NyOTzsOsQm/mSWQNG12VpeKJI9
x9dsn8fofgT9Kxhtdt8nEXdcuOwhmZPh3yvixrSsI8CiIb0Z1dTklmJC/AyNavlzRNSwkvCnDhh5
f0ewBEAhAphAC39Sxff9ykzv/tmE/bvGxxO0009yLvj1bQus1AzgUGe4yIXgwFX7RChRjNFhMYOB
OHP1a+tSiCRNVOJFOaUVFh3ARX+IEkznJ5pc2oIV6Pe6lunVZyDcJTeBccGpRW5qGTJRbScT+MMR
QSnsQGdpSISCFg6qauROIZsCssoSgttP7u4rKysE7UUmdng9AY5Uo10F8XiBmHL9N7Z8ovMHHLQq
wDDrEakxSbpA7OElGVIkqJQG4PjdXApGChKQhgc/tXYOTFixiKnffMVam182B3bLh3r14p3mu4RJ
kmPQMiBCkSZ1envBqRElBO1jN4EdZA1k8dbaWy9cy+NOs4DNmCTU/yNEGbDIJ0h/6jfUbB2Hhrou
KPPuzMLYUbq4kmoaLiuZDOCXIBxaaHs7GBzKWfK8pQZQ6yiRH3KNI0Oc0CqCYdXfgez9s7k7XI4r
hSj2vhh9RzxjlduwmmLPixLsRUtsEUUhJsbAvEUUej8q83uz1/XG3oGtrQBtV8rAzP65uVmE3ie+
wB0UVVZe9HLuMEoFDhEvsb9hSRRGa6R5x+qGbYx3e+GnzByEfItPojhNDCpwEiSqWsfyenmbRXXH
coCD9fWk3nd1WSYqSUDDKREZY4yJcgGIfWoBmxdJBZdOU35SAKHKdHIPZAfLEANE77NloarRrPrN
RInAaRUK/pc7aQJDMr8MmLDIHXEpKmM0B9LwafHIjy9u7AA+6hWMXbaiw+nVDRQSt8NcnF/ViKJM
uNthlHjWo/l28RcL/EsX4XpCPDzhnY9S8THfS+nCb2STc5zzTDYxfO6yDfJzXQunYyj/XPucDKh4
8a+xt6vJugaeCDHfoz0f6/+DMEpwl4aCNLTc1dyjGoxUHFDImID0sAAhBK/UVIPpxKQTAHWrKFVT
y7zFngKKsmI3uYbg93EGQzINjDfuxyTlTCIj8OMAid3tz3FN7qIgqofyuQxnMK3qK3NWVJsNhSfD
pzavlmmYvGFW4SIz393/RRXzT+J7nIoV0e8weNBRHPb5E2gYQv8ItDwWY3JwvN0SdfSefkfiSaTI
y5CSW7V/iphF9oDgwSYIEDUR6wFjU/hz4L6M+EcT3QmTHldzyLxPRVwL3Ws5sdjsr7tvo7afHhu6
dI+lCrgyQS4vhCX3j/uWiODaPFvmqoVHTIcWAjT5Hoiov/tVjeRfU30JkGGALz4qFdiDVqRHHbek
s2NdNYzjJ4rm4ZiCDg4pVgNC7WyKkqJ88EtpMJsGV4LIj+ZnlGlLiCllH5GCTVMa75rSYW===
HR+cPr6ePIeGZruEXXFm2L+aGR4vOt3SZ0vo8iWLzXwks52YQcjhT7kbuBsLiNfesvDWlRqPk8NZ
xjTuo0Uu4tOqBW4hXveYSgNViJlwRdurTUVXXHpNmdmf2xSnQQnJELL6CFM5Dq9dQ0oNJxLIFRSz
+b4DeWcP0ItkwkAevW+htMW6uGaAdzR+h980/OROPwH8IqLCyTvuDabGLxsDsgN47pWKxDxuU6BL
FKR0rnxWLEezqvIhwYnZPuT6Eg1/bLqoqHNU5qotWMs53Bn/ZLv79hCVsgCzTJYoFuHaG1A9jKOk
q/YGzBwAhWJBGG+n0f3USfvBU+SYgP57ikyj1q0Y6z13zx/Ti57WbzGbaVvP2tmdr3hrq4Y8AoKq
fXNniMpInt5ndhsMsTkGuq3Hpt/MSLGwXN/be9B3U3QWNqcY/wIgWYeeO54Z0IVlKXG+eHNWV6DS
6ofcPhZncyjH/Eyzj9uAvRa5kC/k/xNVggz5QswOsnLYGXuwOD5DJVPvlKavPCq+cveQ8jAbJkR8
eIAwppc/Djtmcoh1NT83zP7DxEAiAx8MtPFSzcJ9cbiRNM2YVtLpzqmUYA+4+b7bEYECwnWgmpTC
gZ/i5e9KhkrXr/joctWYBdWf4H3bURdCv3u9dA6clVAmd5dsp308B3KKm4JgXPjh9Yyhl8OpV9AO
XcBK0UjZdPLb9+2joeFrvrc4ifdgFwGUvAB3N+523eAoyrL988Km/VukIgodA7VHuAqECZ1kWehs
3ntiZSQQi/FjQj0FvDsnIIWlTxTPLYHIKeN4Q2Nqp8IhZszEGUL1TZZB5tXyh15EQQH+lf4Uq/k9
iGDFH094BOVXNgq8bTUfvPyxjVFu2PDWL4YB2DnoEV0okLXAqscF306SS/FwmoPnW9A3Esid4XZy
rDlfawHajEmKEtbVoz+iSpF6GU7G1t+rC/oZQrVKgHoSaRGIYmzXEHqo4R4YFvcGaB95W33PD3SY
9IBMTg11JyHmjd8+zs+GJtPE2mEumGZ1p+yrGdzgiu7IC7BafuxxMM5jhmj1xqZzZSGlCaRX6BbM
f6aFp7KEKdtTL3dMPkefZG2GlKxO1jtFJbGQtW7fWChwj5tPRL/C5e2/hQWKhqncy58I/8oetMbT
hGzYY2kmoocwau7sxhI7aLyCm37NAF7fNNasHzDr/lICbmr/mO5vA94llHrw+VstHQqs9ftbwOBs
wlbPPVRJR8iMPB3rn1kNRgg99HC02YChe0UeNsWOMPQMtpggj57N0l7irVJ5ac0OQLiQj/6cu7VE
mE2Cp0XbtMBCju2BbDALsGsW1oVgeuAxO15tmPVf+Rc2irvrCi5lsCVSCPwdwKFPwGkI1WBCQwCA
36VJtUcZ8z7pGE11WFMR1/Y5OP5gpR4+1uek8/V/4FR5bBtX4uXdQLVic1dkI+1dMOiHhUZdCimW
tN8SpMj8ehmf90wCgnaE2BUl87Kc8ByaRaNP5DMoFQw+6nYhvz3F7T2t1cBwB31yMZb/gLGj0uM4
+5e4wWjZUoMJNr1SiKe6kkIjhk+4rI43gvMhIBM3kGN9RfQzDblVRTZOIc36gY7losMwzy5M5MD+
ld21ICFoM3ypdGdnyPw3yo71XqPhNOz3Knmc4gdi5RCMR2YOtWEmo96JH9CSHKidNtKbGUxamnmR
kCaouNptkrRQWlnzvxU6mLgXXuekW0Q79aztlUNYpp1g9rwdyeUR5GQmEFEbwM4l/xnCWL2phG9Y
rWVZ+ngXFtzkCyyMx00hZ6LJ/w+UsOm1Ac8knCP/RBZD7d8KIk5BkuH+z/wxyYguzD2Kf6EqQOtp
kdryJvw4lpcHAzyPJrUG7clvv14/jaztYcWhdUJmE5+/eKjo/egwepfKDd8afoTjINW8LI2OqGLs
enBBZo0q93yh8B6jbEyce7xTlZ07UHIPkdxnNWHbtXf2Xt6vGXSzq8v+i77au5AZOKuzrrHYYIVN
QvsD8PeSH8AcoqNGAdd2nqqR8U8KVlNIXPMhAwrc1N4hXHINp1CZUeE2mtjFvP7slS+U6yYveBy/
zbBcAb6e2Nw9G1hn/AAqEwRkRdo9nS0FoU1g2/OluY6GvGJR4gujJ7KjIUILSJwB6rH1o8LRKqla
iOETLnJg4aEYYxlgMhBElti0ERKLAWCjpW3qc+d2MKdTvpcKwI44ObzA2/WWEgRu1XxbdQpjlvRN
DEzAEXHbhERRT8k9CnFKuw7rpB7XNmRzJRMoNNrIJxKj2SJCQXeos+rn7wIS1GKUm/6pgV0CEbUc
BMAAMyI4suCB70dpu+E2ygOQKlX8XGXs7EIf+TLMmYElK+k1noPqeR9UELA40E9uvSI8WBwrildc
q0==