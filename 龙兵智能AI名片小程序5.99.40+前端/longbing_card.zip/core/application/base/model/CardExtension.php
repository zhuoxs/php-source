<?php //ICB0 56:0 71:a51                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPz4voGUM0J8e18nS90mLyhs9zpdw4BqbQU1gBLmIf2tV7QeCi6plq54c7bqp2Sd4IPs58ok8
/qzxecOQ7kYYPvwfOXZN/Mlk7bib4Ugb4iYA6UOhV2PPWbjeEGud0F4J3DkzOy6e9hy6GW1xZeMK
+ctez2JlxHYfNzl7iTMPnzr6s0l5aQTedVeqpKyNqVBh8fT9IeOQKbqHscFi7ij1CHp384AwASCG
WUG9yTxpVZcbpz4LQ8leks3ZKPQrrAvqpaTnoJGH/ghsBExNxmtu85FXrcequvcTTDd6Cdgb5RH4
9x132s8aYpWus+fWE4gvS+7KhEw3Xrft+wFNSeN9J//nU80iA+8BIXZqJ+GOiS8WL8ODAlOzejfK
YBHHP50J4mvB55F3fG5pWJir+NobSGMgZYMP583GjNwJO73obQ9FOBrERoizZYEQypSpkI/OtK1m
ykkoedSi9QNzbGtAu2oQY2hVgdY2EO3n79XOP29Urm6H1oVgkA6iIuRyBfokoQb59LMQoQXOepaY
YyNAX/OkgK+xgF+4y+K8kAlgFOcQ/3B9guDby0IOXwCS0Dg/xk16JKVkVChaNEhY6ICSvlTbWd9d
IqEMw0kNfq8x03YrEQY+LKZ6d6/V6ZM8PWzOCNUaBS2EqW/kJLY5dXVfvW1i7701HbSJuo1KEnA6
GFyC//UbTCDngMO4xym9T4uIvjZDcVbnmeMcCwl2VBUQNIb+ekyYfTmi4VDBCFrCZP7TAj6AmA2i
M3cdcN+0xPfnoudPa/V7IGcCANSmm8DdG5xSQCA2+ik8k1VW1Wysc25rNHY7yv2fPrC8tsnpq7jP
2EHI2o6mASbIwqw4AOX84RKqZzXmtyWTQxmXi4Y2dJ2/EUbp6+QlQBMGnEHa7XV66iXPdcHDwMTD
uo6Yv4jFObNnOOOpPUFNn2045Pt2Z31kSQWW6C40imq4uGI+9MXbC7qrQphH5605D200qh+g8zGD
ab0WE/CxjrrNdgTMyHrDvX5suSzVu7Pf/E0hH+qKEbyQNjCWvnPqX6Yt+XEw+t87H3vS50UMQFE7
ABEV4c4pfIo4269QT+pvPVg9K9951fmnaGFKZON5/OX2qHiepzvvS/iINakdaykIIpWv2v4TQihs
WSfx7JCfPhEfjHG36/VhCJYMJ8j9Fc9zKFehITTiypzQcu184xg1WlTnTEhxPc+e/dPO4F4YoDU8
XN9W24gz1+8Vn1pHAdhQagNCmUuxyRUwGMthWFTv9kby5dfvki62CTw0g/P3m2b0OFQeqmA2LWLU
RmB4nQd7/M6er0eDr0hDWQbsPOTwQz5dcyvLhmY+dFNO7tyoluMz6bESl2HmyKG==
HR+cP/2TlQd8VmQE/YCeYXoKFtxQ1bOegue25j9/Nm/r/uNALriSI0pytbRk8cgGSgCIn8cuMVjG
qHF/vZs10dddGZeGBS/9DLUv78SJBiS590oy9q1a5wgwavmHSyALsFo6nTAaPsmO5eRWDQZ7eSSV
b08w2tXoW+I2lnOZphQA8fcE+lY/MEi68MbTMTDIIbM8i4qxZ1YvYXHFu8vJm5uznsygU9qB1reF
FRvMym2rAHzcM2BXIKjvFr4htcW0EmPlj0TVzFhbuvYoRhcaH5Z9yEwc0niKrr1aUVViGFsN04Ok
q/YGzBwAhWJBGG+n0f0nS4h/iSmvMupPb0yjXq4YEfp068Ltvp7u/cou+R/gu2icXZk+lnQlWfWd
36+7BT1QN74L1dafE0OY5vSvw8pk2uy7VQZnyxSICVqgiDR8TavNAB/IzxXMFlYqfbEgT/XgTiQ5
Y36Gh1i871gpwBsYBChAECRixD1po1kAm1zeLA7sLlIItxQbsLkPtXQluBS9Mpb9h8r5aSgBeH/I
MmOILst7VTKwPEqd37DUzRsQLczYMnHI6oEEiH7RKD4aCBI5jHgG/hf1FrWLJI6egMmOjwnmivnX
77eAU6IYvI0WyCzRyhKangecZC3vW3s5W7cOKAqFHRxZjf0qoJCOFIYYhMSW0NOBIQ9Trk6uk7z5
mS2HszCaeaBbC3ytwGpbRN+hkLUn39lCTkVq7ltEhV6d7wJBh46DiqfR9zLvogC67HDkhwWrJ24e
xVpjjs+Rlkeet+lZvsbPCXgGmZdUIq4auteIW4mmhh3XyKM4AOkzYcQkxkkMumRARBKlybnjL7I1
5u13M0ESwWbBm7WZVSezRWEmsuBBGR/mbTs8yWZhzIy4mJEMti3GdUCzNy++nmT4RSWhKn5fSQ+J
rXNf