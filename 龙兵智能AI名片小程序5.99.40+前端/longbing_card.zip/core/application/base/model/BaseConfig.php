<?php //ICB0 56:0 71:f8b                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPn9kE9Amiu2b9jwjiO7l/yyuAGG/CeDwq9NJL3bZdmvnNLZhpF60YkdAM4X1GEpiCrQrp9VE
P1SY9aY29e9TwyUtUDrZhS6uh3VBbSV33VM9zOk4bip4VIip1Aov9Bu8rU7uD5hoD/G4rY0NvLQH
2W8UzVF6jntZrLSpjBDVkR3PGA/+jQeChO84EBk2t3UOvPx2XF451t0iYRwYCVxA4iMXJaY6xtH0
Qw4taJerMr6yPJsgv7XJ/lOzHGofx/PLAq8vdczj/Air9bgDATRb1vZbMelatBaS73rRdL/Aj4Gd
i4CBOYIBE3ZRwc0uIgvuWNWKfesTBRe64TUYkir7lZUphBJtSnkFX3gg9PjY1ctg6UJ2p7RBQtV3
pwGSZvEwIzf6q/L6iTfpaRI6Ny/vcGGtQlvpP7ZWfmuJU5eHfPbjCXuSEKtwa8EFpQa88AVg1ms/
PkhFvGpPj6f9y8s2UiCQ6kBa8WuAKJd6llDh5AreTaUiHLQlXBwzyXseqiSW8xCiGBrVh885xpjm
7pekBbWbGXP1ISfP1nxPfzpGXgYTrMFPI8kG307Yn/VlpqU2xiclpSXj7fXA9iGg0gQ7itWHtABr
Uhd6e9zO0rmcbuijtI2OTaWkD+dYxDAVkp+Iy1nCNmdEgR6Xw2PEjObwNkBpaLXwHPJJIjAh0QKC
bDnDolgPuZw+trLz5GuMA/IqA4SJLyh8slIaj4Twj3wlYeRkxTcY1dSxt9F4FRaMprZnw+QcD1ji
DIqAhdSfmsugl8St/Xczlyd++kGrmafA4sOc59UrPl9DqGuxhmT2LZtK3kzNkq7Nlyf+nUOAhGUV
pslO/f+FqQNWEiBunsC9torNyot98WrNyb3Qa0DdazzL5mrCPDAVrSDRoeKFoPmasiRE/xYcZwcU
OucO8QRTdQvE3rzFM2liKZNsCxnWAnsPZvhlPfvi5Z+TvEKQj2VWfFbv1xwOWsdHTX3Pjd4O/8rG
HLiNubl5EccEJRSofoEkw6kPhMpAbi6xgxKqONt7cgoNetIyHyAMPqvIrAbEs8Dy6mKOcomhg7Vz
hVFp1N9tIlttZD21kbn5L6vikbqjQ5N7VyuGpcnSh6aUOSiG2TO65xr1nyyrAJhE0gn3Nw8rtfcp
2/kzzK2ZwJvaCeu+Fwo/3Rz6TvUBqjkR1BPncicOKvO468kstO3HY1C0g+OjK9uBUEzIb0+MaM2w
//SGv1MAiGqAgrmrY9FXgSHKzunKBNE2fnv8Y2xnSxg478Hvl0Y2VXERhfByFH2WYgzPC0J93LE+
a3YiJYa0pwOS5JCjuMF4l5c/rIT1wlHGKbJqxZAg3QHHzCyLxAFGCZinrC9kK6/AA0jUhJ25Jcww
oJxWQXcnsZ6mgpPqcvHB5l+9zk6ijSQkU9WSvmJjG/iSGzkZ1PdWX+1Pz1ijguxayQhk/23Zacsx
sl9lCc0JDXI7jFC8nItwVYPv0W2LOqRxtDts3YcLVB1ivLyKOi7qLW/XjyIsopVbwACu3LQyzjbF
P1nBTX7hHhE2b/QaSwa+XzBst51hw+XcLW1orBtP//RHQVcl8976n9ovIQ7iJQI3fWP9ET1aFzna
jpg2sjDUkgI8laSD1X/njDwZdg+h5jRL+Otye17HDAH0JqTyYJKvEilhstICwE9s0zOG70NjiKh/
g5VM4i9I9SRvSyEc95aCrgqjekIpbEFutxqBNmW8/el7Tv91TNnyUe95EH9O/uKv6Y8UaWoLCFJ8
VoISzhFYdipzgDrFdYVOldWBSNnFAAk4B1NwBTauVnF+WEV80IYLxEeVfh98UnS2WLxDL34j2/rH
hH1Cy/Z5Z47nyMFNJXRPgENJAAXGWD4Et66NyjRwVcnjQG8UHkCwJlBtvJjTGJGIohWWFm/RZFGU
YFCeLqiS+tmFCmVkCOe40yA9luT0gGtCi/o2OPZ1y20/X0wDQc8e4MdBeUie/hprxPGPfizq2ZFK
Q739mUXUUxs60dTeagCSiwBNefCZjIC5ALQzQ2Al8AsDS6G0flXL21nU1w8DwpzqyyRcWU8hkRsh
VhbXkrZt4+k7cwsExaPpmsuDG9e8oP0Rns3yTpbOkuwV1OBZNprlmLpi47wvXXWhcfC8C8Rl7IkN
2vp0lEWEMloPo/HLYjvpOYEt6QTFNu5TAjYY5pWeDX3sd1/Oy7cq6ok//TyI2lrly2xKnwfCwg/H
DfSG5/3VL5NStooa66ljZntLNG0q5aE13wUx4VAeKevrg4/t8arFOQqtCGESQD54erWrXSb7Ridx
/knS6Vy1ObhQzC0MRl04ZGsp1QSQQXxq6htm9zG+LHI6efGPm4j0JnUFjyFCTkoD/0mETwbwGwrO
kjrF25777Tc3h772+Fcw/PIYWxYyd1Ey3gy/XRu1KCJRf9DCcr07SSgJdxQZfkhCTG2M4W8k2fA7
A3NefMeVngl9yokQYrhLVS6KYatZuYWlzMbocOZvG7c4qlRCTvGuH68KPgiYzsz7hzr52xQM3uY9
9NV8rZAq6hpj7R36lcS9UiscAr1MGM0A/+koFPONgxqUV+feaJXzqwqdEMe478PxitJUhokUJvuO
H465AZNMTBmbgqfbvVde4jIGRoqhXxuKil+tj97n+RCJj85D3ajFXmydEpuN4fAalWmg2s0C60N0
GgvrxDOarBCxSLwZ=
HR+cPqPEmGpcgJaZbFLKBmWNMtcX7TPNplRsMx/JAoJV73c7V6k/AW/V6S08m/TUmQnqogl/RNL/
MBmR1FZBVCFj+ALuGsfzFWUYjwrrnnZZVNrhvu35jsBUCIp8v/9uNd20dk/K76dso9sX9laERBYD
UqLrejnV4XsnyAupjtvLNw/tI2DsaBW84Qy8Cp4swQL97MVAEO6jtiJzT6EudbFYw994mCwSOvmK
i7b7bQCeE/2kLDP2daC4CTcopNfbbmFkRsiuXYqc448stzA2+5MOzy0qiz78BJZdq/JEyoplHYxJ
+93qlegk1Cj13x42a7TxLSWoVmzs+u4bGos7GI8hmSbmuewinkXcqBa4hpM3je7LQ2FGLRe8J6ZL
shxeku8AAbP/8axAXc43LTN4Ulz1hFfvP7Gk4M4+KKZ5kOwCCLPdO+iOFqtjCiZ2Op0KRF+XOCSd
h36EyFwndHa3NtUpeGK89vuo6zKDJHcyBcDOb4sE903akeFFpIAQVEewLHHdbsrzauv2ZBkeO+oo
Pq+o//FKaxEqwbCGEq07UpsEYzZjTufCu1MdLoRAZ5ZA3R/hyO2z6U6iKN7Ie9tZOCWateoB4buz
crr9/WucNpbJYCbjSAEujjraXTLifq8HhcRD/2VmVSK/9wtOTAnMG8n6DZ4/VmFHN/SXWlryK0XR
9Y9mWH7/+DQaQ6eJe2iYgKLK/SntdEmbpvxSTAb5BHUxTzF8n15pZhDF9PVKIcqf6u/44O2C8ZWo
Z28X6368FK2TUukBBdG8LU0nrdB3BHt+iyiLUlERUWGtatOvsELOXbJqyRnZ5ihoi9Gg733Exc1E
ve6vlJNo2CbSkPXX6xP8Yf18DGVsJWAieohFVzNTF+KROeTL0HTB2O4EGXJ92kg/i9EWb3DYW6g0
pK+BvORxMdouCMfwIDb6DGQpfWerULe1CAux8HrrcZMKWE4xsNS+XbR7RuquN2O/4WSfdeW5Xem0
ripWfgzFtIg48dDLWBRCNNOQjX/jo1bOiAvqe8Ydb1Cl0V+69eP6vu8Q4JRX/ScIdimRAikzsKRV
n1/6DKXnljqtexpWT9xNwmUZ6paeBYWDPhRAmYVFWxOEhKhIrv4HBFAhRwNFMZNxq+XhzBWxWqLs
nT5yLXsbDRWHVT2/Lfva0xOu4bfiZ0XgcCZQrIXXTucQwx7u/9vB3GwoPD9xf4sd0Gxzge50jZTS
Gkik5QVj7E/I6VHgwhRVOFGx2Nu4afHqUJhyhE7pGGXsDllvr0vVNRkTkV/TX9ezifVxnngX6vHE
WBZua4VhrcNWu4fYlKGRoiHt0kav9OeX3mz0Ah41XLLABPm4XHe3ZohzAj9PME8jTipeo1G7IJXs
Geyp3fHeLtU68nvYasI8kAn412Lh1vkevUa3roVSnsPSRwqF5CtDxxIaM/VRISoyAKnmOV7OXkTS
5FL6MgwKIFDCArLcSzua/0wrASYqQfhXRU1aW94azGNBxuUe5OXt06dCaveooUBKSgfyZfiIQStz
wvpF74D9uE+8+aQFuIHPlBp63mDQ9VaxLvmoznU5jnduhRYFealppLiT4hZS1TVvW0zdlMzWUmiA
nVV4QsRV8xLmPIjUj3N6ilvw1MiBLttMu7NIIQFce/Q0WpSzQKIMrIvZA3gDuGuBqDwk3Kwop4eX
lzBNIlqOlUdh5o6SLmbxohCm1eXC9WoPL3MJzHy1w8ZFS1x1blyeu7Z/XiJGA/4ie4DrYb/YFdg5
QtZZGBxXCYr7veN6LY2Fd89BnAovYitifcEs6XoIQnngIAwzMY3+gnDV77Q7ZyM5LQn1ch5FnWbQ
JdEuxTn+/0XjhMCWPOXGMcegGFAn/iA7Ndkqa6J/SGM4YRKV4RKx/5Lbc1N8GAJMgadbijAO7chX
eYwqQ1bKky5GAi1Pznp23GJqxPxWDOn7CasoUEyMEqj4nD/vgL9+szFJTlpB49Vh9GLhTE12Q0Ua
JxpFOKyHgvolzLUxfUKJaGFhvkh3uEa1YjhSAuRmdlTnUDKzODTxmAJbqmYgaXy0z5tKffn1LmrG
3OG01aXFBSt2sNFX7jKI+8Ob6+hknyxJo33rSGTotB0JBec9ayMws3hRBElI4toVfROQEVVdAbCO
ikYz+/xAzGLBGSCoRgC1RazBkOLQKcxXLRX6LasFA0Tv9CeDgqJqxgIbASjiaLkZDjWVT6MpcNr6
vQidAC/8ASjUgG1yxfBWXq5pxGkLcs3DGkKYuDttNAeTP/mf9bLzX+PJUhskaDfni2prfHiVsbvc
IWTRrMlyywZ5u4uZb6gvh6gWzSE0nPXp23ffGcC1bDOJ+EVhf62UtD20Y2No/UokBomt5kk8fZYX
ul9Tvm==