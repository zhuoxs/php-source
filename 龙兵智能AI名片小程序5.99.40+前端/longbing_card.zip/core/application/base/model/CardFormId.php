<?php //ICB0 56:0 71:a5d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPz8Jk7Hf+01x7wOjLwnpiIaKiaxjLYht0+WK900beA8W5co2BnwQWhwiQ7+omkUple54Bdy7
CBcaoZ/kccPAJJciSnG1c1Wps6AdocqBuB5+VjUaEqeqCt7jlk1NP0NS0soQpacDP+K023eSTSQs
v56xjiY2+wXhS9cI0cXLtOfSqH0PhYTJuR2+UtpL2QCpiUdX9XDiRCOrRF5MWoqd/ZdVd5CXPJJ/
oA/IrnV9P0PK7f+Aps+yc4ChhEONrB+1lEGsh9kR7HuVV/gyfsw7/EcUwwL4PgcaYNjUSAyx6xH4
9x132s8aYpWus+fWE4gOSgDT2jDHEeGtmJZNUYBBGFymQfnspyOzZY0ExH/dATw6qgyovCievvL4
mGMCZoNoPatM6Qv6UtoHRG2fAYhIhIWeAQOxxJBXjJ/N+VWgCSgSet3rkOCadKdPG80bGcSwYMR4
8g4DUMgSqPqvmmkmJKs5tb6xkHweauREbgc8MCau1mSMzot2DpaKfSehAPYzLyfRry3zQ/XwWil+
jVARuJtpn+pI2Nc59irQZu5lig379lkQmw4w20DgYsEuBlprfbMqCCn/MPT+MAjTpiDy9H8oSp+8
rvOb2jRA07IdPc01zdMp6kPHmUQ1aM8eTIl9w1a/1e9zUPlxlb9WtzIEikfl3TwO8pYGc1TvEwx+
Xm8c/n4+07c/tQsmD/irjFBdhZ9+vAZ8pOM2dGbWBtPFN8TMhF8Z/gChZgmwA0W/7ZLekRa93Scc
ZZOM4n1gx5TwLFoswqAi4DAS9jravlIDu0v+iDmW0JFwWP9ppfu+U8K4wpLiDH4f0iZG1qKRqPmN
9bqzr9CaSzzLzsXOX/qXTAUnyNhKlcbMuopbj7MJ2uKrZkVaZIKKmuwt1iPwJLevqCrUMch+c+0g
Pa4Ich5C5alAmQ/du+d4Dvwr3mAEd907NTrk0cZG6GFhttf4YEjW/3a5GD4VvtLTH0If3BLq+KZU
hoK5g8uWT6sPGI0+X3YAg1+WMhgkNuP4QyW5QAaZ6K8e2hj0Glh9jz3XHjOWATrdW2778R7VdQkO
7FggZvbBJHp+Fg/OPSrIX883SCbTxsnizPAWHpRqvc3+XIUDH6JZUDf72otR+kDsPrMKkx/Kr+2r
W4ts3t1nx5nBRb124i5yxTctAbnpLxgjRZqPfpeUXlZCF/0DZi67bHy3ya5UDMdPAT6vM2Ya7S1A
/8+4kG2NPtTPzPxgui5rHNFC7AZ+noGG5RIxzUZVP7DtdCTk9kwz18Nyq/o2d7TuzsvXxUJl7cYR
Wd67DribGGj9w0qaJQbO0SsPP0FAkCb6HhVogvCxiTHN/CQHQbYvTdhBsS+mO8SfkT+Zv7+QnW===
HR+cP+SvU2kl6q4DtOVj29QEFnbaBqIida9oqUMeCGkSeUbKylwHRgB2NuixzpZ3XR1dul+8iKRN
CFiqywJR86816eFpwAItvfsEDO70fZaxunYWr+EpYNI4qFL8APJF4hOqSle6Dzs0/2vTnLLg79eB
uptxuNe9U5GQNvikoR4esz0pdO1RiLz/f9w0QyjC378jUymPA+GcOjKJuZDbQeA70mUy9rtuKbtT
4ejqPfFMT7mgRL/yHXDpItuom9huCJBb5q8fZYfxw0hap3ICswVXxnehKKKHgNjRQB3N1jmLP4Ok
q/YGzBwAhWJBGG+n0f2OTUHPExXlQt4zufOjXpuY0AZaqJZShEid6aDGnS4IpED9rVZ8mTDzjSEh
7cmlHH1BKg7aVKQdQRh/eiMuhF83FyjmvqdnnBbQNTIASzu0M/ZvBptfWMuADinARy8veI5DpkMB
6+scbw1aH4mMvDWIWW7kprUcnOPsvhMMNM/j7Ig2N4bqggeAncsz7Sv/cx7RGuA0YXq+Z/iwijXc
q3UelXcxgW6xXFJFOw7PHjEjBzaAk3FULF4fl520C5nMwsaDfAM7EHHSTVJHJJr/QrZXryEGo4SE
O0msqVwCtlGEJueNKyjsAmAvOm8R3/6p1iWNHMTRt+x+Tth9VtFub7ykUfYldXeu0HrmMh74OTPR
/2/vCV1Ijk1O1HkdtkrFz6XyuIIUskxNVFJlSFn4yK3exzvcY6SUqjW/4MQ9GCxyBPau8sSxtM6D
1A50BaCXquO38466l7P1ojTc+BrJ02INmPs4Yg082LxpLWw1ydVHT2MIqZ38N/WYYr+jg/Nrx9WH
Yf2Y8nNky0yf69ZrVjzIHQFkxYrfunzhtrNtoVmPZZVBmaWwHCaAf2ubyd259jWPhiAsMxeRgKym
M7CixEOluEYIQVVkmN9K1X1weNNbrfa=