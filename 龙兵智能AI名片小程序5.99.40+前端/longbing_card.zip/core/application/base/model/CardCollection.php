<?php //ICB0 56:0 71:a55                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPyvgloXfimCF7zyg2ryXrdSlpYG0LNy84VHBd0mZHgrkXGvQHIgcvj4X2ngdJAHynFIZi97o
62nHcjhDFWa//SclYxhU1+ItbpsQMm/w5AKHQbVIuQ4GdbMK4dYkI7rxhY8txzOUyXd7iYk08acy
Bmwk+8h26B0VSXQPk0JcbEmphsrEAHUDO2NAEPYknO2JswVaSFzijSWJRRzwpFr70nlA5y8Ydz2F
dacJx4NNaBL1mzATI4at2u1H/sGcX6Uq0sBjp/IU57VGU3K6KwwrKEJL/ttz19rZ2YKCOEYHfIIq
H2UmGmjY98iuEDlgO3XA0t7QxSnF3k+NdpC7rteYomfSr97wSpWJB1OKeKzMlNudwIt4BtsQo+wB
qpfnly64hH1/8FL6G6/pPss8Yu7GMjH4CT3wzT9lgign3OHDau9buD6JbrF05PNeU0qRU7xdZcZx
nK9uQa2S4dJxUhoA0J5WC8wKt3Mto2Q+2ZGaSjPFWMb0iPKaIl79PTZZ/KZmyxcZR3LS3WBE4TxF
fA4hCobZy2Lkct9LFxHDMWZmGGJdonPfIgPNy2juBsVaX1ShK0q1wFXn//Rh2Be5AmOPZy0+aJKZ
GNHIYTe1Hmb9jU4eygH4neThWd7OlFNLTabg19+53QdptXHEzJvCL8Y4Lk9jv3cRLAsG+k1F+FGm
efhkVCSXt7PJUJy3zdqqVxhRAwwQDP1S9PpaNNZCm2sOUKZGyKvtbteINcXBo6HdsAiwTaN4X/jn
AA5GGQTRwMY3VFlUADDWwN6PZtM/OTIReUWqK2A7CLhIiz4Bn1l6q1G/TgOhRKAZ+tCoctHT79DS
Vb4YmH8bC59Ko0cfJtjsG+zi/Yqcc0uhGB65erewcXOc37xtu44hEJ/D1s9xZ1QfacjouMCBoxGH
2vE8WKHjWYURViPsNw7etdR/7tGrpwuq2hKSmfFAwNhJEoGh0oBjGaE8ysp8X14gxZq15tmb36KY
72+2vbHMJgqNNuP40S6XMOdG73twBjy3+PV0gsQHjSwHNzhrg6LrJAr6DiIUl/QxStf60cMvR8V5
v2Dk6YwZRmwZjE++3y+rvWVLGY2MxJG9H/ijJ+fQycecNp6/BviWTuO84wqAU3jDDDt7xk4laT0T
t6NDsQxlavPklHhzc99Dvm1kzd8MYsUaC5+9SelON4kmie1u3Apicp7C9Dj2reaXwRD6WM5gp4SC
iPlqSy8LsqCZzsQkQf1NumCfW4TZytt2v5t5Lkgyu9024G+Xpbcj5d6fb7/zfVPLL5KKQwPe8NVg
LF5IYLXf+fTBnN9LihaJpdW0hAoX53as94495Tsgh5vVuF1xNbmt2B19SsCvXhHMR+LD=
HR+cPza2EW7Krfusohol8f/b01lTytUdkjLIHyM4GHYV+GzPM2EnfozBhagrGGfX9eK8YZATWBTy
fSspz1ukX7GHpqqM7Vsk17x5E79G7yYqLvDh0cfKm71hX4YfqJSEwV5IFbaH8ZD/xS6HwN548iAu
4ssZ7zl+z2FV53GcjgVsuixNPIYn1u0W76N4Pty2C41ssiertBjLdcK8v9MS2zqbXawLyM/VtCrn
t0y0OjSZlHLyLMwE4dCXch8AomUpBDIYViNQ3aWfQVnB0at7PPPZJSs3hVvXPUluBCXYN1j1t4Ok
q/YGzBwAhWJBGG+n0f0SScEpTjuYlt2UYM8j1sKZ1kJu4dzTEIj07r1HHNXc9Q5V3aIwDB4ccLGt
tQ0DxDHpMwub//OdgkZcx53ph1TWUh3NITkz9kxr0BprDhHVDX9/Aq+ZIyQvhA/VoaAjOpswHzRk
4SMJij42c5ZtCipV79SmILMtddzruqV92bLMMbtMd14+uJKpwbgHdBsznZA3LrpD7iIKte933vYG
g2FxEUvYh0xK8UkCNQqVfe4nCTs+V1QLic9Lic4hntCHSaZtM7RiaU8tDC4cxMrq7QHD3u8xkqlm
5qsxgvyBJAVnSZxWrdf4/QxoLVgrI5JsVRXw3TLjgOQ6dquQnTbrK5saNIdvelfZat+gwXXeWrF+
jJtLl9PVdtMeShEwSOo5Hg3DQQOSBY5OcqJ922U8QofuJ/NLFZBMJLzJiamarKVJTPkfCL5iTpDN
6sV9LancgEv79dNvNrrdq01ugGnT2es2+BbOvgVeIPRj0IDxlOtNjliPDeYsU4qenhy5TOsWcjsI
Q6iiasDrPdnnCqDxnqA0L2OplEvNRKTWuMxP1eHkmC8YdFppG/omcr6oLyPTS6EndCx4wRR7qsHb
