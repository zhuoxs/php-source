<?php //ICB0 56:0 71:a31                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPsR1yxTKASYuIdLcbEACoc0lmuJPMMZRzyvDd3MNykhsegVDuvqqlaziHHlpjpuiXGtlUlQh
AqHE1SwC84ry6WAp8JddoRbWwGbbyGFmgD37xCJjDWEPP52D9ncVS0+NKMZ63PWRl+sEXQcXEvdl
/o4Rxe7NIs3k3DiiYTPEl0xZZq6UGn+UTHMgPACnQn9BwwIwfPe3u5fSVf5AorbYEbDsi402PQZd
w6wMZzEjYtcuLZr5JUMCjb+RFa0Ebc9risBRIAaAFksRfIcnVx2qZSoP3qtaw2I4+ggigwDnDBH4
9x132s8aYpWus+fWE4f0UCJ1Q9zsIfxYk0BNOeJ9Hlyu378I2QtxKqyWVpJac7EKyYvJkajB/5Is
YWwS/55F1GNKfLH5T/Et2uVmZ8wIt0x4iksnkiMx27dO0vqtqyhIBeBqHTH04jo8UjSIsxRYFPfG
cIfffcSjNMX1nnHg2LO5vHg1yZymOha5BtcafuGCwTpIeZfgOaKSEdzYT4cqrdjIl1jjr1teKjY2
b4QM/CSbbH6xicBuJEWtLFUCGFInoqkPMvkqoFUxiT7CRuu6uzv2sWDxkoF4JCGLICz1g9Gf9Pqq
0kAB58M6+sH4nI5puQu9UmNxyO7UJcCSTz+sPYt5VEnYW13eCyOEx5kYBWZiTToI35jmxXuebXk6
5svbSDsVTcM9Y/37Toae9h3XLccBTFaAqCJcvTYQRhD82rMnMKqVP2e6CFPGWUk5reXAr7jTdWVP
ryqLKgqxLKMIWwlRlHkjEgCFviLELBdjSt5abrw68fZG+wCoJhy7Y9T9V8n9Wb2JWusP8ckvz8Tb
4h25vpUEdiFN87zxTNK8/ew3cOpOzxxcJJf8hHUxsecF9VwtVFF70E0ARGZ7pqTKJg6ZZqmU3OY9
dSikw50feM+347eJpuv1vSunXTgSBs/CUAkaIA6shpWpYHmdHGHEQcajgIMYOfOdnfUf5ixmSOqR
3WwizIZzV/q2xCrZominhlzJoOt+T0J6AGb6M58vuynePJdHkWhHTETbgy+Z7akRC9jf0n994Oju
z6fonS9ulvoTmV4ZDKn2xMFVGBFNK6tN3yNANNCTwZ/bvvK538mnhgUkC9GLYqGXA8O4jDPTKpbR
WJ1KguueHlVs0HaNop/f0xTSLoNJ16lk66NTTORbhdUom5/fEY7Kmy/0JdX+elfwKICikk3sz/4P
ZBoj+x5NUR96ECHuMjWredLti+WMdcndmin/rIJX3gQerWyYM0630+R6Y7rT906mMEaabWq+UkXa
noQmZaVWALLbwste2rpxb8ohhccwI0===
HR+cPm0wT8fY7ask48JXgG+0ptDjVaVtxNG1KelJF+vU2RsTe2l19H0+xVHf9VQZdKuPJ9dxkgJE
OyAjlniHsI4OOlvZKzBX9+55RGA2JmqrZA5aESQwKh29ifV9HkoiieQfXf79n7I5s6/8pMhFcaZj
wIraO6O8b0L/9vUL0apWHb6mbKmUoYGFSFo+ZVOZL8tDH9h44Vn5qsCgdjcoQgvtOHtbdMubL0H0
bcPwIYgUdT0Ea6zSMF6z1WzfzRpAeLxwQRs1uTtQCOZid1gTGUIs+u2h64upiSHfqH7cpUnYHYxJ
+93qlegk1Cj13x42a5ruhBPiJs38wV4EQoq7PICc2MecrpNefMiXBeR2Krao7W7+EweP88s3JT/0
kvQBEjsZHzKLMYmLi5kYbACL3c7L3C48WPzQli/c44ACZicQzFhycy+jWdq6oOXMcLVaMS85127w
dUqIRHenulfYIVAMhwWsEe3kjvDaQ9iQvm1NwuIpbmQRXuMphC0tJWlgrY1g9rLaupZzEuF3WsPc
JnoZzUyvssnmJpCDJxd0ptXGQEM6VBntY3bnhtdZ9KIqSaDZV5qRPDQj4ewXG+sJ/rY0X3vBPxtn
9qpFxcGkL22aXLByiIquGnX+carRoq0zqkM/BpWHgjIsoFyYNWTYFnjd5tjpKruwSw7XcxxZ0FcV
E2hBJCy6B7YU8GLKlWG9Wu4tdCPqTrE5YSFJfLmWCHepLmANoW5Q8zgalT1iGi8GI/qNyXf5zsDn
wANRtKp2m6E4IuT/pTTqs/8zvgZ9HdQ4GJWT4ZtXTu1OCR5s9uvRr3jt+gP63HrBQ05FPf7ChavR
w25hApvuVfaYZSJ8nke0A+oo1+tB2cv6sAIpElej9iSLtEGQ09TAdz+QGRYnQePBc2e0RHAYmiaV
5G==