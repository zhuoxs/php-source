<?php //ICB0 56:0 71:a25                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPzx8VWRq5aCgwdph9VdHM3xRq8aBWikHOFAaauglsjlOdwd7HJw7cw1w6cqTfGbOXNG4Ti4P
uh2Zau33YdqCmDd+qdcLsJKjL68gB1ytjG0R1SnEXfWVDfvS2MNEsjR3fTQbdTr8wpBoCcSosfDy
r9XqOvk7cZgvo73rnzWvOtpq8FC0ok7/6QZfBIiQ5ApdM6y5KxSNCa6iaJvJKYRhNYBsESUZKzWP
ie+K/eASU0dLH+Y6wb8J4EuWLoyiXiJt4Ndh1XWqyIhLQ1+XfvWgXb6qhXog62s53KTvioeqQwwq
H2UmGmjY98iuEDlgO3XAV7IFI2YHDmpzWJNZrwAwpGZ/4/LstHGleO50ar3M23xFArjee2MaPY2v
wxxfRkGwlJkfnejXodjsz2DH+CPTHvjB64igi/vWAn3VoEX4GOxbpklnW3ZjztXJQo8m2Z/WvOHi
EDJZGI1Os2it1DmAEDRpsoGYUEcos8/k8Ql4mZ4dYTTe/oJ1VpvoSyQ20vjEPXiRgJVUS8vOpIPy
H7gi0UJR5e45Nrw0kgapC+MHusiH0rmbe9P9jwYUpLioteE8fCoWrj/jquNtsD0tuIIgmatO4l++
geTaI2BBwt7t7CgWDQ0HML1GZGawyiGSvIIWb3GrZHoLEAxO3tRkuRAyVyFbPTUgDLGUFOWQlfW7
OdikPrVasFi9k8U6qOGjE5p+9e1u4Da9yzjA5zxHe5pHH9eByur4kxd35fPE1cSo70zneaRoh66M
LRTDz8nRVzRiEzv7ZC5sPGzZqFJZf6lhNjAZFMgckv86GIs7rskdx9031EFXDiwylMIeIJS1DEyJ
GqbjjXy/2okovmJYPiLJ0U7boOOAhe/10suY2VqFGS9sA+0KcCdCNVVrwYWBLFjDD6vQsZTmLtK8
Onn9oRhOpeHcxHMSGB4x71ngmuDrdO+e9ApQAsBTcY8V1RP/zlGi9MIC4Frr/nXcWJl1yHir8/Zw
PjAz7+NGkw+5ahrLKpG5SZhiHkFQsqBa+MaA31KV3rUSabySoD92V8PvAB3XNzBge40X5yzAMVsQ
TcU3UIPQ13zTlCEOrQj9xiakOt7obOKvFoQmBquSjVRySJlk1X5sVbtfHudF97cJFs+4qlET24EA
S7PTGekIOAnZMP0Hsb6LrrXwwpFPub+OxEar72qFPhos4xd3dgVB1s65uxLiXRiig4zGLrLZH60v
N0y9kssN1Phty6cjL2vj8I/VhMCkM6CVRvZ31lwwmW/MIApAPi8iPCIHVr4/BgTJVxe7OtjYtg93
MX8iGdE/Ph5JfkzXHeK==
HR+cPs8npbvT0pEHSuzRVNpgkAybAvlcTDBIATnP4DACKMWgcUjl08gAy7aYYanT1LuRub/5dSb8
q35svGLyNXSW1tg38K8S2yCANpzg3KxbT21za73EmyCOQZ8tdYSTN/hqOj/JqEwUH6wUsWiqTDSU
ihwIKKNJ5LC2p3TpAS0V/I2igoW8N8nP6V++DAPZT18U01QkIS30DZGpVcmYEUzMbRas/wNYNDxe
bWO9vRBrEsQTutPLI6Jp/giG/0OeVyL+Bn+vx/jc05mCJtV6qyAn0FoqGIyYtTjejZOq7JDSvpL6
BjFuaFI+Ygu4oq4FiGAG9c/E8KvvkgWSPPu5BGS/8d3lsAMClUi7VV7DJBHb+Oq0/f5NdvMjdHYL
KTp68nn18hot1ZSQJzXc7JvAJDXyhfL+HJVVkc82fOOshbv5zoZbQPB1QY6C5zqGHx9cS3srmGWn
GSgdLMBiBDNWJ/r30iQG1738ELr5AD5i3DfpxJgxWuQG/SeWoLk5BTzhDvUPkzg+eUpstkMj4h5w
FOjxskkgHPB8LkPMNf7aBSazv+9KAbOvr21XfqT4ZvFBFRG+SDwIxVeg9mWa4/P5S5ottoiu9rXU
Xb+wlYw2iDWK6E3hx8HUgSzwHeABHwLWArSFcsGCh+shzMcptcL9m/t/6MQGXLGFr4ZrM40O+Qkr
h620uDSoSA3X7ImjAMXqMexuGecGHtTEy+OjebT/lKRcknmmY7vD/vPuTl7opSNeXVvhu1EPcPf1
adsHWG3ZkTa+DbPCfwRiEyad84DwXfYSO8l2UYjmcYzChFxYrqNFSdV1g2v+oM2/mAtRv8bDnhJP
jI9ldi/i4+6hZCYcYrfIi3CV6n/nSrq7ugq4QGQYK2n2850CsULTgqtDoUpDCEgxvNH0disBkYxQ
0HO=