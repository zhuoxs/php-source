<?php //ICB0 56:0 71:a4d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPqiCrdZkrIf/dBb3M/eS3aeDBq+Q34jnN9JJ9usS1yNF1AANr71XzaZZjCL7uaVp66T+Mz5y
21AIIisP+NTFp4usUpEv/eQFL/QNHQWH87nWMh9yoGZpiX0heu1lkh2aWxqCH11y8GndtnH3wMiu
Cn4jKLukYKmK02iVnmQw8p0p2c/7ROYBRw1vrKNXyo9DI7yKmPLNaAIuf8sQluh9wPBjt3shOoUo
C/tNrIc3lOJ+py1uEkyuAkU91s3+F/+DI2cmiB3JkeeGL532PONzYoWp1K/Slw/TYhSaB4Bij4Gd
i4CBOYIBE3ZRwc0uIkzmeSYdShA/ivan5zVwXSaRHaRyYjYCg2fYmvtfLaHDvgFqbU7SV7R2TpA6
6qiehb4L5Wbwbqa6lpNApEwHJ2jpHKqpp0EeYGw0FhGnyHZKXYdUxvmAIK+RyW6uu3dvBztlAv8b
jMBGImbnh2jP/ZKrZIYs5kgzj/BOOFpJknysT0U7Rw+wk8eSwQFuRKEEdQXWUaiXd4VxHHO++brS
LrSd77S1lJv5JKjlA6E+3iVCc8p5G4bjr1B1g+8AwM6sj4tRg/3sJ7dh5n+YzoXLLih/3B/404Pg
SdxepOdMEJUIptZCvcID7QeUtKhKdLV2Wjam4Kxab3i2ApNrKoqI+x5xLmXGWTKFLZlHkRLtEqXA
m7FEWJ3/omMzLxDxRH+Xr2A/1H8hVmSwQLzwgNTkj9r8NjdwHa7orqofQHib+oVEn4i03g+/PZ1h
u5iBiGEmogS8/hQQKAaz1WBzNKBQI9GeIy7aJfzNdLe9+aP7p+J1XdrV2i9RUyfo3WQRgi5Z+WJH
YG7MdgUJaRtcL7QEVri3hfDFyMon4VC4S6zs7Mdi3FeqWzg6+HB+XV18SO/ELl6/2TddfH3TG1u4
/xkEu08RLULPVzTn1TRCBDSwqTLYnRS9/2VxEenTVKgEiVcTT8Yfg7RzN/65wpcELtTX/wclAw0/
ANxtC9N80bzGsxPkFL0e+uICayXfHz0iLgOFgoZ1LDQKV+bB1CwUW+DAE+y1hIZw0dSupZyPj7Ln
sMz4TwcjokDyuxeiwbc6X8ZCCX5iIFdMQQ23loxUr2mZlUpZzZTu0FRbZho2s1iPjTCHz/Us4y7P
dEce9+vkPBbwUvV+MdnE5Ly/t9FXtziKlNYMniGlAfYWeNLEjqnKFeFpoHtfyB4TOTYBY/RCIrTb
Duwu2aEUwPi++ZyATyKBWUtveqHg8QG3WM4sgsmEznzYT8bMEtrOyJv3LYnz7IIkOGF/QcWubfzC
I6VLlAfiJKvqkVdJRdaFfLHc0yw3RQcmZfNzDxYtCGsNEtj75D3mfx8OUR+q=
HR+cPnAnsuXjWo2l0mzEg/ACCrs5WhlNHjut1PNJ0zygik7ALgOk8KPR2VRTIknQg6jLW/sRkygd
RIm0pG7EyHzgsAAljH7nHVtSBg618VZSs1VlkvNUOEalujuc1V2he3a6inPN6+NZY5eUS0/JGeX1
n3jyUuwBmIlr8xYARYk1DC12zDgyrRHpvSEJoDae+jdtlC4mguMeaNmpwNxsjdcHSlI2XgePwQlm
I+5IQjtGr257qm6kByjcWLX7TE1hqj4pA/pqLaLeUchr7VZkqPw0j6KsIf1ebbG87B/fPVisHYxJ
+93qlegk1Cj13x42aFH+wa8CQTfXN4NP2Yq7Go9H/uJo6LLnuQBuvnnRbau2ybechjD4aBZgGn0i
U1dAveuJqHHcw37jd8G8k0OcVE4JhzN2wNXRRXm0MPi1ZPsc4bVsQ+0j2OkVqI2a+iFcJj5T8ckF
CBlBa51OmJ74iVc84CZgO6GpwCAjPmxIN4huH0cJM875oFXDFHistvnpuXZK6GjiJqDukaX7fiJ1
Ynf1QFjAbthY+RCrBNcdReUjeOti3djFl5Xs0mDh/vM7e7tyc+CLYOjw+0vuKUYnYv/R8cILYFPk
/mTfNr04UqHwYWwyoUzeYhynaVUrxUNk959in8djYrD9mzJ6yK//gCTKCeVEaZwbFo3TRiZkVF1k
jtMbIw0kV/F9K+ZLLWC0nsDWaz1TM21PakdoAIRrm9A/FY/tZWM2t7jQcQlfQTzwVByiwKG9BvMp
ugx0ut1yEULUf1eR9XFjXsHyNtF9Vqz2Y5E79cokp4/0EnqV51STOLccp9ST0SxI2TQjMl91bxZX
j3EI0sJUCmJ8NhlrhttEFM6FKoBxg2fuf52w7YxeUDGcUKVBXpVSIE6cjFQMQedtcvfzgX/cjyVP
PFi=