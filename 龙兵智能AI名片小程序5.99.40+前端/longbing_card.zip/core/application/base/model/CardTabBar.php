<?php //ICB0 56:0 71:a3d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPvSw27iS0F5yiewTMEiUUy0MZJx4ILQ37i9TBuLwfyxyW7Bn5+kEqij5H2mNDSpHKOYkyvto
70+u+dZWX/qMgXgBfhu2Ce0KxP+LQCqDiE7UYIlpD8f1PUGKo23TQO1SsWN23Z/rmqb789hJWfhn
WLT0lA9a6spzctMlo7KS/bIKaGykXoY5WVQvWqt/riZH8dd9ekkk9hLwu2zzPvq7bLzv6/wEVurE
6PXhaQO8gzhih3CLRS2AOxwDxdIHLN+g357sw8u5ouebOFEPcTBQ30sXM1uEZWSj0INhLFxgbBH4
9x132s8aYpWus+fWE4gqTY4vXD5nnMwma83NUYBBDVzSjsK6gfRbsZ/BHkTv4QLyvPb6X6SFAsLC
odfr+JZW/NWqh/qWom7CelynYhAao0GwGYXt8/E7lkOXVirVbzDpXwoBBaibrL86Zrrz28ydmNiW
LRYonau3cQge0+lO+QkBxXNx4UzyDSxlEmBdgfKoTWeewUN4Byh0mcqEvhG740rzikZc5b5WgggQ
XjVJM08KGct1mfHinJI1B110u1cxlhWdEGDHkRq2yeCKpsvl046n3yVh9LPVoRajQYm3AOsUz6Jf
chzZ/+QfTgNqZEDnqC0JBymi7zwm2MazkuA1BKMw1G44d5xlUHcNmdIE+l/uN2KbrwBkVclPUVKH
ljiG/xl8ljF9m6ezGuCjhOCC25DtFaCj3LsW7xi1zDvozM4xIn5TiUNmJl80lENVNqe4j+HwuWUE
BrQ+HKZytTUbKq4a1TmrCINXAO6e8XrTrlleRkRiT9XdTE1H4HtirgwSBKvAvSKoG7PUIWvk50VG
SYbrMhrOK6JQ4DECXZkXuC2uBcvxzMQ4BPAlGsEYFT5c5zdyIL54qkEVyEKTw5JiGly4TvwKVEiV
BNXmLaSpRJ81Q2pPqVZZz9aDjaPnRuvPpGQ1DWn8qiwtbjcraMuRsiHpn7axFbYyxTLh8aFP62Kf
7zGmA6lv5+I2C5tVh5kVJILeIg26zXDFvx03oQJPYHm/42VGtGsSDOOOt9Ivz+a76tN4zsnbqwGP
rixP0HCUil5fdbw8yYvTMQqNsW8ck657qBhercQxpgdVzT9AkZcOdCm/BZtTbfTiUumJ6RBdoAfV
FfbOgVWxCGtdyf8rDfADXh2IHfxwR9k2UQCKSCSpGqYVZ3LexlrocVqNi7DxWkwqDwsvRbiH8dra
+ECR0cEYGtqWqyMGAURNSLPcEdKMGlTWhU7czhHrAkz2phEDok0scJzfdAQrVLvN/Gxr9ee2Ol0W
0Yipn3DGm9Acgosed4J5wNFSfR8BmR+XkdgbEtFmZG===
HR+cPsD7edP5bHPvU/atLP5tsFTH7Um0B83nsuJJWUbioAVToIcHBoHEH7QYGZemlSSn9QFZVVv8
GT78b+EkRm351VomRor5EFz2r1+Hh9wt6Nsx+AdZ0edh6T2NaffXezxcOnYIPGeaUG4SpnSZp4s8
lQTk9m9Es15uVhQY8uRWpFMM4mjMo9ElWeC9u2pr1EOJyCtzs0rDiiut7aInB5NReGKPVQCR9CWS
qj3ZiK5IwmY90e/jdxCvw9vCNq8jkXqg7tg1sUIHG2EyNIEykpUf7hH/bLOWg57Fdv4VvNQbHYxJ
+93qlegk1Cj13x42aEjqUl0dEKTQj6wpUIq7Go9Pm69BXyzuBFj7y3IFl1j6hPWQSWfONpewqtXR
mortCXFlws8AXv4DC9ghYpwmi4FLNspLz3K/aPCIh+K9a8zIG782PxlVUbRaLTBccOk/RrLZf0iI
pdbLsKCJr7y3fkd1CLtNHGl8FNy7qFTB4etFHeWXysUlTjGspNqJhnygIR9e2dlhyRqNu8sCdtd8
0Vv25e0Bsy774vGRy6C7T7H5d6PCpZrC28RgyE04T5YqMkYtIzstum2Y3J9dmY2V7noqafbA9Juu
8q7BeUpxzzaMB4eFHbWf7uEYciGS/aSDZrSC2mTl0be7V1JLc47EEMS9YFTNuP8O1sP+d3flGFT/
MQJjn9/YUvV9QDKLGqm3D3bjXTu8eeqlpXBNJIiA4hDCmYwFLsfm5VYJe4ZocD4GVN3xZMNKxuTj
rJjNNyZSXQuzvMyJXaSJk0Nyk+7FJVmJkn7yV9gWhm/CP2utsvQDBSaiFg1fXsG71/c+7K0LTYXN
JDZf+dWeWOUJgcYgSACXLAUHeDDTWCmiKgL758vQmSqzNAveSnyWk71sKLQzjCJ2kE4=