<?php //ICB0 56:0 71:a62                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPrZfZAteDdM2dbmPZggwInS32qRv54DLjEOH4jWvtfCb9FpAQo/gnlJ1M7JH7xYbgNGUZC/v
NVbjK2TcNcVp4s6XY/e06WLwUZzd5FVyBb9+FVf3I/ismVLxz6xf/RRNLHz22zD2GqAQ1zXz5YMF
eMnalO+vJhGU0BAoC6UgSkWiLRnUFg5d6MThMlbKNPDlqzakrf3tqAyBCfxlXSnlo+xiGplcQvPN
P6DNgpaLzr3FwO6gODf0OwfjlIOtzZ1wM58HQS7qcXdmWs8ByNpc3xl2rRneMMP/d9LEOySqIbOD
j4Gdi4CBOYIBE3ZRwc0uIWHsrm6GMi8Wru6zhTUYkiqgHb/muG0s9cxjL8jXsnudh/7Sl/dx2Cam
FbHqAH8T39f70KNfFVithTkk1ymI8Su2gLlmeXBYTnlhK+odWRSbO0EWIIi6v86A/W6u+U//74CT
0m+W9u5PBuEJ7Fk2svFL2LWTAAuBawt19xXA5OsivevLR7V73fOzZNhfe5hL+4MAHpxxq7C8JXuh
nyDiHYdbYHqCh3jZc66SrPIo8UEdhRk2TWXGpsQa/fmwC2VfUdpjzT3XSMHKUl56Y4Ve2ezYAA01
fZvVOfdYnhJaOjgjPAhawbRRo9nc3bcfV2BDChT0eKjcEBSHzlWVpsoBHtF5tmn5pp4Mh8nm1sTC
hw4ZEt79+rjwxjBDylJhLIM6kBcQZan+5v6ZqKF96XFg+u9LYyIWXxmv+F56uYDPoZrVgkzRNW6a
3VuuudqxYIyR1wzvVoJhRlbzp9eeUWHEw9VZdrFVEnp+SWCxN7gYWCnRqZlKiEwJcmOpVwnlCkEj
BYcSaRcPjW9ROBeVt62gCAIRXaS86TalOBJin7Y7EGnxCWPccHVrYswpc5/f7CYxuuGw30bVI6Jf
GCq675Jt5wIpGw+l+vAyCcMfBO5qBBLwAQSuTFFEkBXZRsUXgAKOfIQycIhik7V2quN23TtrAxwl
u79xE13U+ILn5imZ3JHF7g/uXBC0VrXAbZyaWsAmSMfuTTrc3p+FOkZa7LPK02774NVdJp3wBIxd
ylC79f5QXIzyHLN/gs2BC6yGrLoTBGtaO0VaKQwZv8Eo/8r+fYHcdz71/gsoSSq1Pc7RKeyM0K3t
4wOtbMwrBpyY2HQIT+mp39tGU5O+UEnU9gRcfQoz+Fzg6CkkgQueao5c+tU2zMd/uj4Ex44B+mWW
Z/e4fma8v3NvtRH+NrfCFMs0Mvh0qOioDf9YIDZhs3Plu8USfn0NEVcTj5Ypt1rHavZaSpjVHl7O
CFRelWSt8ebry9eZs8X4hvIW7BJM6yamN2d1RZFiuWFkJWL/ILkCXbYZ1vxsINwq0/3v/qRVXBwS
UefM=
HR+cPyjqscMan3vAsifFHiFNs6ZfEvjjT980jRJJYh8WP5W3mOZDeF/nA1mi075rPMVQ7yorHbxc
2QguHCHoYYUmSZiahEDFqkRekGt42UUMd0VbJIF7cihfMTr4YZFR652uRQZG9WDDGDpbbvAuhB7U
AJC1kKYdVixIfMlzprN/x3ZxRUd8vW9NorlOUzAInRu1PewC55zEmkYK8RFKy3amoYHxKLbHmU2v
9Vk+x8g+Gc/PUtJpgVq1KQCUIMAKkwiu6Gv64nk3VvEgrAa0Dw3eWzd7C4FOJ6Ta+xfE7+5wHYxJ
+93qlegk1Cj13x42aFTysB2VE6PwVxv5nYs7FY9j/uz3LaIWeYTd3uuNohoIpVPQCML46/vXQmmj
6USBV6fLPCkbyxkKcrjryKWYn10Qk+prSRDrqYTK4pxmPwlbaP0sH+/X9QBLn/EuB/HunQLmd9Yu
11iKo4ZVeO4QIfFfzlwPxS5NmeISxDraxKUCqbCDxf4zvPZ41onX2UEMeo0l5kRiWgKDqhGWvMaA
sqsBsFeE17uYO6cGUJLGmVSEuvoanhvA1Tt6qkdXsAjxwfOFy1+VCDDeM0Q7lhRZZXRBtYNEh/0g
900LT4Pd7d+4cptYe9yhr1mSidFUMfV2FN4/E01zHPb7bEgH6Af8Yr7Nl8r3auf9zoonKDQYnc/R
+okb9z2MniKtcz0Cst+jSa3HmRjJcD6KCSrHWPQoY2QfT6PpV5HRNkch2HTCTJU5QjyE8D1PPTGA
V9BcvyDdy0oG08+gf6A43DhYMhgZU1P8B8+i5pN6Jdnk0NQOkAsVTwc+k82B+aSl+HhBVzD2x+y9
3GDxIjHQW4P59KEJkX3ntOt1LNB3Eddz93rDNW7gz8+7eLVrxtqSaruVl+SJlY+j0sMafg40htZN
Q10=