<?php //ICB0 56:0 71:a45                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPvFIN1TUEwLOJ6V9DDkUCA4QVlgDK2feqFEQwiSPSI0ivIxD3+U2MJfBeVV89t/7BqsSehos
Ft2Z5p+7eihIRkuRpuuODrSFEMStCYRPhTILvLwFnOPMESZWpoCBLQ5Gorbphg/mHkfUAQtk858s
aBa+0fKvmCfd2i1XOV1rluevzxw0Y08n16ZazPzrXCcv5rBp9imwhgV9hH7D9kmr0dHTkKFl9p2O
DJTvjUFVC0mNYIb2XeCuLTkWh/0XEnYfmcUpRyB471Yu3+hh4Po1IrPhUUSQZWRoo4D2i06m7RH4
9x132s8aYpWus+fWE4gWSQH7AhOS9gW1d3lN+eN9O25PM07eiwCQR9sLe6H6Xx19xwmvdlI8iY5R
DVofLGp4QH20+sJT9BJ9NuaeLySOLHBLpmeoAxghOXS787I45bXG9mUkq2dl4aNSSe2qQc0xjcVG
0gWrVxTj0e5wGPrvenXWI94oNfeoWTzXOtcdKkJD3/V2tX9Bv3us7pr2r86+fPbrpAO1u6WRMT6G
03OIzxBNikBzb1bzmrhj0t13KUUYmf7zqSZIZvebbmVRRZtSQTLT9bPHOEQmd41RPqaIPDsrCG25
LCqB5TnFZhZolqzsiH+UtcwcK5oFBV2J3sTzLZh0zUuAjc7qcql8/1yWtdq9mJZmkDtuasY03mOC
xbf5GKPgqnz0UgjeZMS24zkIrt4+z0o62PumLutbYqQOPWj/PC62PBOsoF/ps3t+6CSxi9BFyDvL
dK9f8lpGAH5WoxUy4veIEFDBr8qPM1PSfeFjXqy24o/c+rCxlnRie0ct6Cu1pvoh6PNKudaptS75
ltBtM62hufJnjg60smCvojWDMCcNoBftUTG2v5fMofq8nCr3ck9zlKnGJknMDTifVuxAqsJQ1aIp
5AkdQ67fZJ6e6ydbuMOOS1gi1yhWY0TAggpIKnGxw1/w1nuELyElzvW6rhPRvnsAs7GhWnPMcoYS
Lt/FcmPEtv9NJ/BGi+sl2NVvuw6bjlvUPKN/9kALE9jzMO9nd0ZTviIbdYx5bGUcTvgdA/zUcMfF
vCrXQoYEzvci08+vq6zGOWFnrWK82TPtYw1/AIglk4lVLExg1hF8go5qxWuC8NfHyej6aLVaRJS5
fLw0927/48vaYnLJ0DOKSMdZnG82XHjyX2PV/AozTBTKmw2fqOALM6Ol1BPvuAXK12KYNmvuYdHZ
IgKEK5+BARVdkokgz4ieMga9kzza+2nfzkbgDQE1ggzQBoiavMv8qMfLMgE5clrLz2df2t8JcVTy
rfZ4Y0jf4hw5uOku/zBt04SWZwW9/Kst8wI6ls2SVVMWhcyFzG===
HR+cPoatzJkA1Cx/d3Y9O1Y2XFC3wrTxGFDxXwFJcQvhBqHOxeBmJvCDw7X/We+DsbI90cknDtQX
qjGAUuH0K5sYftDuEeFBQRMyzyocctK95Y1If/UOBRDeiZU2uBNj2U5fejYof/ivBGH/ExiIt+bU
8/3eOUDM3isx9elErM9CRbE/JLMjGh8fM3CrHtB59Lv1g8UnN9A0OZ0+bLeXOEf7K04cXIb07jlW
JgkjLQDjcCHbkdpA33VTV9/L8tnUoK8+hUwdrpLFgkKG7PMH8+F/OE0BIF+9kh7G1aVoAIYEHYxJ
+93qlegk1Cj13x42aCrrHHuoReT0cfd9Bos7GI8zzg+IHGiLf7Nwa7DISBcsfDT/9ojfN6BG4q0U
DV9PD48fLgA/7C7Rgcbs6a5e4pFuQR1tf/kVeiSPmkDcI31BZGy7WgpcWWXfYYq9zteY+d7n7oUl
dJzX1BlG82umn0XMHfh+vJ6CFtctsO0oebN0ZwJE7LvS6Qfr3uykMcGJVkBBQTwueDsoeYkphikN
gqdCIGhzAP8Gz5M0FaOZYEqNO2bkbtIybX7JVAGpuavDxrjdU5EYu3D3lLJIbtbIRW9rQ8O2zElf
AOP8kwqxMyj5zc5zJIxwDGiAbAgBQNhrs5gCL9MeONlpTCxmujtUrYob7iaw3hMeOvsf0mZvInmK
0fhwY12Y/Jhamp8wOjPoN9E/I73YkAdMb7AyOhoVfEPMRwo8hoVaRoQp/NxBQFNuKIyJAZQsMHXq
jZxRSnC3ce8bQhq5yxOANGwWFwum5WCjXv+EC8kDzo/P+zS879FwnAE4md6/KKZzy4GmHmIwQDaU
LUIrRpzDThh72ebSTNTldk8bwxTgNeUhMoLU2ooADLzfRwGMdz7SEz8X1fLgRmjMbAX90q5zgHZC
c9e=