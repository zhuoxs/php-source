<?php //ICB0 56:0 71:a39                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cP+OCAzgiwgyTmhY++P8ky+PTI2FyDK1Q2BBJ1b3+/MbCuLxFj/mcsPcB4JStphWg/SU8PBGk
119m8lBrrxSPnPQCQ6ITXewIBTLJbPt3LX7XhbyHoNFvkXfMcuUOBscM+uBIIbS0rdu8kmyN+SXA
a0oiUrxyzJVywOEVNgn4fcltJMLcfK4R4hZkyMaSi/By/ZrPrUS6x16oYICWQKhj3kjd/DgMZN+j
X43aqHora8V+0A5i4p9rY2KmkV1j9c1rqDycBxCgwNFZoO0SPdSHXUaopYZfGXxCpH7cXYPTj4Gd
i4CBOYIBE3ZRwc0uIY9vCnntltLf9P/gDjToXSbjzKQMhw89gdOCjmTi5Q6ZoBd6iAnn5mWYPbzY
QPS7wRfKwo2t73Yu3Ho7JfwYYn58m1pbZnc6Lh41E9WMZ4oLnn+mYy2QXSZNggO8WLuVnTpryHeU
nWajyhV0bz4RmZwCDMcwDhzeCRgWCI30RxjugLNld/PHYg7UsJ0+yYKFbLUOgCFPjqdA6xVwN4De
yyFHvrIzVy7j3evzuUSHi2pu/PEwYdidWYXSjv9PBU/rKQSqizsLSeiisASfgV66nfsFzlriVBpf
8dOt+Ut7v8w/PioSR205sJHHA1UtnW0srLw1GUvwGcHh33xKNkeJiSCJ/nSent6wZVzK0oyF2vJv
20MVkARm1anWjrgHscjFoqJwS7MCHnfKLoFAhEFbGAY7nhk86cPZxwhd3i2/fuVOKM5TLMU5DFVW
gaB+1kSIl4Zkep02YYA5x063w6jd663U7g1AnxXBvM7z7oO2Il2UR1mTBbumMIjuZDDt9WZMLPhu
ib6CSl0eEtOL+aDqqYoM+qOn+gfkQbQ7gUwR/jurxFWHbvjMTz3PQb9BKbslEJk2BNvst2Aj/YdM
zPW0OrINeoDRT71iY2F1L+3VAH2ab8ojD6Z46VRNCNlV5elM5NZom25NbnQCfGZw2LVRVbW4QFau
l9h6NArq7ZT2pIccECywgPIY7goNK1vQfKe6SfE6yVfaEC8Z0RRV5vYKOganhpg020CAtD6tdjkp
t+moTq09H5MPvZB707g6s0Xp954OiAUbXg2E0Bn6Yk7ZAdUUYbhp/gKELeaEQG0q9CkGPIAvn5+P
p4UNdcd+AW2ByYhZErtOr6NClvsTtxLfqYZMGEqiYMazgRgxu9mMWYh/bTzTYYe+grwkpJsVUPG9
9Uby1Zv44WSOBfSejPQVoCLrzKtGJpwW82gnKZ0hwv1k2rW8NFHd9bpiWaaR8c61AZ9DMaY7ezzO
egtl+eBKRXQf0WP6wok/lh301ijpS0YR0BFbQaJj=
HR+cPrPbLNnIjwrpGDl0NmtRXaJhIKPMaOOfZh7Jq4hL1yBoxV8LRFYbml2/d2yOnD1uh6kSIHqc
S2vRjnU9BOKubyga72D9uiMEhxJ7fip4bTuquCtNaWeKXpF1Wh6etOgv2mi8CiBzNxtRliBHHwGO
CXdff5aUPwI0MlNVLLNXtMpVLbdlt2atR0vP+QwHmB+vVdHVtv+G59DHic4iR4A1abbnc39HMnVB
r/8JqmDcMge5ql0BFwXu3C0tHLNk3Opk1l1PHvQ7ythx9zZY/kxtENPzIHJd1JE4Ss0HTLogHYxJ
+93qlegk1Cj13x42a5PvMaC8+z+P9xuJPIq7PICxA2gvYPAwhs36SdPq9AXo2rhRTjopCgQNBW7S
0NCVK86KfyXpKnifz2gRCMdMFZB6T8lR/MpspC9Y1NubqacDXbXo/shOZo3CIINT7oF/HM7uB46+
n2dikBAgf5wH1gOkJUcIOmm8wxU68YriN8u3JijyQK+YN3tYJczLD314/d7FgQBHVYHettIYZCub
YOvx5lxkHW+PYXcFE/Hw6DtdrkzBvELU3wMIpkfP97lLMIoVr07w0MdQ9AlfIbmfXpZIShycguOG
yhOJ9PyelFoY7PJvX29HPSPhKqLX04HlPwdIiDv9rF80uKG2Wf3kyYK7TjIxFzPnOUsImrREmFMy
MHPu/dkQ9JWqnBBF1YbBWk3IOBQK3d6vYsrs4tuOYU5WBQ2dSzAAGwRgd87HdZ000PU/seDx0CXm
gVbkwzSLYDD/AXd6isXsnwKVB4dNmR7SDtUcSjtC8/0X+kIH/miUFvjGCz2SNE2v++tFC1wJmjft
O4/VxlV2J637ANjtx1+hLh4JydWKOZvYxb6+9XrFYEs8HcBDOeR0TbOSZAVtxBl/YzDKAG==