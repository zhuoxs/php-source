<?php //ICB0 56:0 71:a41                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cP+tpB+gTMvJDCqQwoLkPsFm8kpbOLVNDSOpJxrW0svqLw0qCPUxXCqW8qiDMMqcPOdIET28l
yDB49HFCbhtwxUKf1FCx7IFHoGamA/MHXjLLg3eAQd9t/WMxgiPMCpVMR9vRKW+g6n01aB1w9dOU
4rALQbuRu2JTaHvc6xcbc0qQZ/dRaqs4rg3AWXHW4llJBGMBliYJ2ZlCUfLxCt6LbjXRsn9flGn9
1LoBT8JWTAVk4ZHCH7QSpzZhma5O3E7gdXr33BG00Rhw/XTW4s7pkUVpzd+y21tN1rcXNcBTj4Gd
i4CBOYIBE3ZRwc0uIlXnhqctW8nOR71yEzTYXCap/x67fwqD4Q24oBQfmQjPII9WH/WJ7Q/7IU6T
REd6iEgiApxKJqVs1esdhs7tre6Aamv3eXjlK6hJan+IhqKOhRm9A5iT4SkLelkmP3CXNA30kOHo
5qvGCZkN6Z0W/yvDkd0cvEhuDEZeLWWZH39tDZVb8BCbMZhUzCFJ+60EIBdIS2fK4JC+EBLGg6Ix
iCgoJQe7BN1c/q8nUT5dldWNsqqb1T6cqHrW4xw9zPhJGXZXDqJ37ZqbVJKNaQQq9PQkfMGPEXWN
j0M0bys/rONp7I+hkAnWnDxh4miV2ctc5D+AZ+loFJRHebKDuC7Ej5ydG6J1HxLdb+QkDYDSWM2Y
nKB/h3yGNCvQ1sopZa2PnXPB0lfA67ksMIkKNEiFLcZf8DVXZOAd1lLzHajhXbxHyWdpYiRJyKnF
PmJK0IC4DOiYkOZqL63JDbofNRv/lX05rRrJKhFkTL7Ukgybw7lRB/unX2sB5Ci4Aa0A+3DfjYZR
ZTqbfx1eTXLcEDufNxXbCxZXDhtXJD/lyh+weBaa4uHg1hSFHEb9KZQpDhtUGS3AEfPE8uHqITWE
/5L/BqZekU9jOidfwuRWpwWpTDKu1/Y+CvQ1Z1T/u0mOpX9E+gJ6yQANtbVUo0x/ZWXMQLw09j0R
iDDpNHt0r6PVazXod5o7+F/e3QgeJIjVYAypmfEI6+C9LZhzY2yk+vTy+Z8I93FBcXY3l06btN0v
vEOnfr2O/msQHzh6hJ2Xei4KPZHAYlPQEUIzgTAd64F7XgYyFKYIcjqT/U+GqEOVC1t2OctdtBFn
3B2wcj1zA+mjJ/D5i3vMsEZPcITyoeW7c+q/UK1pg1jo8wGqCya5cKU2BjEUUrM/ooyY01kLVDyX
93g5yIwiiDe5JvZ44vT6pZv++wgRTMvthkh4jLX0dv4fd8l23fG4wWi0TQDz+cIpLxFEM8XP0ybB
DCw6I9MKmmhqgF9gR+1y86TtIzUmdxRFKOQ1vN1ojBejSQqY=
HR+cPsLKfeT7f1geTUepfDaLIWjrGXYD5VRtqBtJxzbthovICSZmnA/OmbAv7V+9k8IyRmjVWPxu
HEhv3impKi21seGG/jA4fFPWtXldmUjFV4He38QhEg5INwCcemjP1UMDQ3Shp9ClInLWNjML9wK9
BdCk1qPR5HIrQkv3oU8qoD4fcZ09PXyJAmimHp7XCu/DpamKWdoAzcptTZrF60cYr9NAgMeWKAdT
hegq4wB71Xw15NqGRxCubzRBn8YANPv+5e/CMjBNmFqpZJzjQHgiKVP7wGn426JYzojpfi8YHYxJ
+93qlegk1Cj13x42a2Tp7OE4z4rDNB7iyIs7Go8N/uKE6WqiwaVLEjJX2CImaLpMUA6xw+RZcPoO
kZTbB8ghxEUXlj6abPfO2YJVHrC/oA1AgrceTxDdd0dC8JggdsmxIifwZCBfgPHNYzit+qyhHQDu
XNeibHU428GZ6g0bw+MsN0/r1s2lGSGuPIiEu287kCWflDQWXN84Pd0ubkky4nWO6Mzqd7cEmW6E
jZEV6KZ7uCmL+nEdcXk7iMm0sqrP9idhfXCqYECjHMz47zkiiAkXdbYCv6zCPhS0VfjIVEuS+4op
5VpiEhuZNxip3NP35OEup413DZ1NB6SOGGFlTjvXwVefckKOUHIXLoe35om8kXYU+pOFqs7s/l+X
Q2XkDNtaiDzQPSi1U0Z/OVZLFlYvOjPfuboLi1q6VKUwoI97KGydKGqJjfUMMOq28wEZnuhtWXEz
hUqmPLkLiQEV+prK7fCsQj8s8vpx0a/0kKiw2fbNFhr52lG1kIVhfRN1c/1a7oC0FpDNqp7G/E+8
vaqop9hX/HVdbWsC/dHs5TgNpiOgqLcMlCtl7COO/IEFyg3E0+7ZSPfns3t0ary64hIgfOYqYyud
X0==