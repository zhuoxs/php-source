<?php //ICB0 56:0 71:a2d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPuwZ7BmpY+MpeHU9dtZu1OGbqU2WzEWsgRJJZzRkx4Bl+5Htsd1fydKCWYumQQeQaYnGR7yw
Z4+e+zslEsHXEUzAsqdVoTTOxgkvgx7TADbEAW5xBGWJ+WxeaRBE+TzCUEc7fLOv5A8XuAo2GnSn
REuFgch3LlPjxzNEIoJ7rmJq45T/j0SzZ8BeCQx6QB5v/TeQB9iq9fSJEP6lIB/pkRHasCvAxS6V
MR2t1AWbi08FC3TE184cMY6fKGPNij59a/CTMSpv5U0luAuEaDBRWQd1LopfKFXlzNwhdhWuj4Gd
i4CBOYIBE3ZRwc0uIczver83tFfLqAXLizUYkiqPiZd+1SvmOgUQj1Yh0e13LlNHf7pmEU6yXYMH
Dksw4LqJxni6l2ZpuFkyuh90FKyzutNPaPITLy1SH3V6Jm1eEKpQSpVnQM0QR2d/6O8D3S8qZDAE
LAG+VzhFLLDVGyBL93VikyKRdCkXTS9bqZ5jkcTp/ZOSDGhS5QUetgK+UetHXWePBEVupWWGjwC+
G3v1T72xyzYH40i+7bs9p7HSAMU0/dqhPZipLpKJ2KOTCR0f1KgPkYHC/UEjDo8vlnZrNBHFFO/a
oH1HWei60fy+VUNPvjsBrjgho1+aNU5sb/MUL8zt2IN9xu0GLALlrDsg3Jb4vygrH5zUxgV7voB+
7cDlTr3/ZQVSP6wcj5DFDVpVwNwm/OhLCK9EfU/UiYNMDnRQS4QV4OLY4icUBECUlkBrWkXCV5RF
nSItjDdNwH265FUXxJLQqSpiaUNdAGrxMThRjc58tfZjaAvcE7o2uv1/HIirmmoyRSU3bsh3UhdH
zeNpR3S9y/Cb5/gpbAeMv9CgxvR2jJTw8LebeLSbXzC6uf4N3yXSqemP2drPhXC3uzBEIKfjJrV8
KSPj3eIBj865gs6z4MFOQs5kTA+F1vWocF+mW1pVymfnGJIrAerWX7OFEmd/bkZs4PhSg92OH8L9
NMbuY5RB8K+1MyP2SQej9RPzHrgvRkSRVz8rSPtTUiQJ9j7DluWDUZfG2GwvV9rJ9DPniFAOE+UT
fmRISVQVQDy2HdzB5LZ36CAP1SDtVUizeZLkJ+Uk82pzcWJlBi7o0b62UdtUR+XcIotkNhAAd527
1unJdjIVy2+vE6pLuwnnt5Fs+WtEcxVGQWcugm68YReIFd+7ze78jtdpGdmarUHuIWvartxWa9fY
TCdEHLzjnJ6byB+MSQZJg1txYi8B/r0cUdkU1hIPNYV4nXKh+XLoZXbUSAutpBAcDuXJ9Q8vOrVG
6ZOvfP1zV0DlwSPsWQlHvhzARpJR=
HR+cPnY6D6fkQerD73YXIGd6IAW8HKN2cjVD+ehJP+ZOV0LFCfdVLpMdFVNqEG4khWvDuVBnigEb
p/Zqun9v1SdJ18YJV+YD0wBr4//1SXf2lUb5zizRJn8r3dXG071+E8Jvo9aCtCxgfCrA32SoB2PQ
OaMBsCCcJ3em1IhqxvFsn3C27nvPxG7BIOVvKBdUEBE3dkdaTGIzbHENhBRqbLho0EwPHbByRL8D
Hq6rlYOX86K+bZyzAs0HjKwyhPn0tTgpmJa6eQgcr6cj2laO7DBSp2ovvraz+IdhfeeD+8R7HYxJ
+93qlegk1Cj13x42aB9rNo0OqmU0CWvgT2s7Fo89Fzx3bgx0uCpOlTlu6laxTUU2sh4iWhlkcFlH
h6kvHU5MJm7ie1JFRL+f1c/T+Dri1Lz75BOG4RMIQQr6wR2HJOcIV4MptJ+m1FL7VJzYiYfGDsuR
b7Xdx0ezFkkNlYwPvAO/0Y5P3n53PoVQ7aX8FvNQDXGDcNFNR+J6ZPMcSTLlm5RK0tT47wwS92be
FUl9/RpGbu/Il+CeW4dtVpkp2t8dxFRRRhyMdB9D4PiCKUGmknFlTz6eTywMbShmLJInPydy0TF5
wawFbo6C8bNM6G61/eWkrVaZJAvDEyltnZWJckEIHZkFgcRwPXdSNsxtUlPMkTA9SMuGJZ4/cFxg
/wUjkRMXPpj22cSkaeOLRnXM9AoZ4bFU0Euip9cWzt194wdue4UTW3rNdQIzeirufwrGQ4183iV+
48S9SqyOQwgRIX18uKOey/zDMrBtt+d7RYctKB5hpKbXhv4qTZeRZX1Uzcmc3Pgz9aClAaR+NAID
Y6adL3Xa6VMzUtuGFXzyuCajQRTpmD8MdrelaxS+2qpW7qFTDcHW3nh2dcW94pcgY76WpmW/NN4Z
UVlWVyT1+iMYCzPcnG==