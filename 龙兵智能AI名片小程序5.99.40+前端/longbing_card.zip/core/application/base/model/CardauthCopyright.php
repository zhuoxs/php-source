<?php //ICB0 56:0 71:a66                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPxNntUv3NYR1SKH8pSFyQ4a9X2bSqDfJcApJsqI6zd/VYvXbVbEJO5NTW6UBN7JCxE8473+2
fPOb8seGfUEPf7R6fyr6YyD1nrdymLVEYt+j2aFOP7Nabhbjd95ILl7KQ6hHoLe+Y+dgsQJebpPC
AiZOdFrImJ5Lkm1cc9e/FIP3627RGeFkQEQcPpBvIZ5XbQFNpaIZ1BJ3JaF7EojiVAuV9V6QgSz+
/OqUhJjTdHS9ljJQS5zEYFg7CH2guNSHY0VY/Rl7VVAnyGs0ywnANCrKk9LykJQwEgSn+Pocj4Gd
i4CBOYIBE3ZRwc0uIlDxQENknYf9sXtWtzVwXSal/vqNbQ7FJFaTPvsJ4YR00pZGDBW4Yne26zBw
Kz4AkqVdDrmAeUmO8GtTK1aD++5vBHHPiODxlYG9As8fFdSCoOYPnrRsnAh1t2ggtpejyCJMJqdP
xrYYtEFeQa8OFGzthdoz9H8PHEYk2Bn+FVDzl7nbDgAQkh/tO3CbRTcgqmZ1m1rqvuofEaLWJcoC
rch+xG3qksaNq3KaUykpyUZ2O6I8gYc96K4KFvkXiRnwfwfj5OxLdZM1NSFwrwQXIx8Dt0CLLTQP
XALEWFygKu+lAx14pSTnN3N99nvew3Oj/E2KH2tKubSb9JheOQj0VxAixfKq9F1CT/1XDvFMdHWl
d5KQDPHTdcJVgEffqa33pz7WdNeYBjRKQBx0UbYLZqRKxj8d4MXEGeTIcss4nlXVSjh1FmUqDKsK
24hCJsJhpK0RXn8B9uLCJ0oJb95Tl+Jw8yc+acwvcHXCgN3p53jg2dTOKw+bQN5DU1aQPemQ3V94
ycqW2n0rDynEFP2DtsrqiRc6KunVabSTv1BRvW911tBuNe8NPIzw9hWVIHV6ynhOoaCQNZrdR1Zr
4F26h9/0czoNop2WvCWSEkeY3XPm2WxwofZRItswiU9WNeh11kC18QHp5RJ9johHW8obffYpEL4N
VgOxWn5/4T9oZUV73ahq03w6AbeFMiBkuR4OlionHStlE6EOT/Q6R3RZB6kVmX3gIgk3SDikoat4
BqIy+VM3Xt+WSSV8s29c1YZpWyFXktbmgfr3MPutU78U4JtPWmXbVLoHBHFkRaZFH9G1Oyn8gQXh
caaEL4Kg4FgwtGk5w+PjZI73uwLqoejuOFNfGCIs+GxVtWDbaKxy2NtpnlLwUsVVOvK7Qrk4TMyM
i+nr7S3pPI/c9B35/BdU4+rV2b2EtZJV8XTBylmMQn0pEOpzQWmr5Lt20w8Jw+k9LCD7AzJyDTGE
+GEKwx0AsW41r4qnI1lpl8WTl8FXY5Bdl2cUD7MA41tBCEKwV1k/+tWk8CHk68P/ku7Rkh10AiYi
X7V/Nxi==
HR+cPv6CfzmuR1mJhZ8o/qH90DFFT6mXB0KK9TCzn9ywebWzaMMmlQR1gKR3d9sAUrVLpV7Bcqdo
vcmcztSjFruTb2xczNMo6xuUNh5gUileVeOnhiwpUtwg0gQLM3EkFXZru1lZsFhhXnYn3WagMdyt
vSkD3iC4vqTw2OqHLwPPFr9fhqedwt6zp4QgYE0+pRweSSTkTiV7NTxyL55tQs7tFmrKrAMsqPyH
wT51enqNWMLdxuIyLHBfQ3rhNSqZp1bctHvjwARaMu4ExidDGUYxdCN1Z2tpHyilBX0cIrroVaOk
q/YGzBwAhWJBGG+n0f2nTxzj3GjellWvifWj1pyYIp/qgKFlbKvOnpGZa2QBSdhuldKDljSYNHZB
pH9yqoOF6wTPZssohKxuwH5i7PCK2CPsz4ICb9fZDo29O0uC5BABoHM/+xxPVy9wl1mIPKqDJqcc
IbmE3mbY7DKhN7F5qaZsm0gHfCoJDbh7dG+ME0JDy3ym750tqt+s1Agi/DLGPoDtgwzFh9V5P8Uo
5BguH8TuxwJsWqNAklSAE7tYeUV3ejhq7gD3dv6Bf0rVWCS1HkLjyHESbV4uUPS566XKEE+MN006
C9ebxTg+aEnFA7hzpNK9Z/B9Aboqyo7X0diS3v+ZV4BvCUNWtrE29r9FJZf0uLtfPcESS7msi1SC
kgHKYIzz4pv+z4HFL8LBYdIl3T/JW+dWA7wTN7kSQdebpk7fIFZN8mJZd/HISkXt+2xWnvQ/sEYa
V8bMxlJO+bP0MqruOQ/Z8qYPo4f1rMrydpEseA+bznVL/wegdJKkDYc6CNPaiyUtnMRopF8vEjzb
jx0Z97XqXM7oOs9lsEh2t8QzaTkEiQ1Mz8BxtEJMSiDdS9hDOWc0NJidQb4Vyjh5e7qp2mXxceb1
t86fNERUs6no27THkiZBksNW65m=