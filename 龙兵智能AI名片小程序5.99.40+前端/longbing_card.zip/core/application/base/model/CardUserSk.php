<?php //ICB0 56:0 71:a49                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPw3zCxv4MeYnUaYcdUzmL20FR0it8uqLjhxJED9LTCBr57FP8eKTD3D0OY57/2LDtKK/cg6g
wX1TtzfsZ+71NAFySRmOEB8kxcyplW5yCondy6iF2be+Mul6EWPUdXwE7fYca5tw2zNFSLKXRX2w
z0At+8rWubeZjYTUxtdfSFb8lFjiLV7YDu/6oGYNmMfaNDanDOrSSUwvwKEH7Z0SKmJ2X2HCZ9W3
S1tvDfkgeQL2FngSePiHa51kwCFOpHsXGjQEocMfmI3UOb6qzQkQLjgAZIm6hsIQZvDJEGv5j4Gd
i4CBOYIBE3ZRwc0uIfzmTcb6FTncWrjswzTYXCaX/ugQHJNVDCpY8S1dUKO0fZNubPOZPIVJheBL
57pLx1pMlFB+3YnlGYrHbsuMuRE2DdXU6uIfBMi6btkCvMR1YZFquxuDxxe+oOY2+AEZqvsnA9pS
otOR5EBz/tASW92r5oQsJJzUePLtanEoOCBuZOgAcmjwHp5n9qNq4gR+tr0YeOQHaJ77RYs8cjk9
y3LzHl5ltwNp0dobLayOI01SItJaqEM84XuzcEjyRGLHwRq38FuKdbNaU4MjeljbdYegwd3UILCY
dUSq1r93uy02WLnDRVlHtR5PL+5gQ5CzdT4Ye1bk0aThHKRus+gm/dKfOTxxPQSaGBRTieew7ihm
ctjs/T3dpBCkFT8XnxmT6UALdKYqisM3UMLxRcF3YsJx3TiCQemtfwYsB2VwsOKhhOuBSnnTpJHO
VMTyQJcxeaOuPd34xqL779ohWZEgFN+mOJFB1pG7KXNtIhrM4J293lEMo94QnVhsnHLBvIC5c1ZD
vd+xrNONTfjtT2jXDTMHwj3yufFqTs3z4wultSNjmpQ9HbRNEfW9T2l0l9MwXL3Kjlas/2Oqb6TD
8BHIoXv5DaY76bWJThhNpvDwNva7DFbGZH6hGkcLFfypZKTREt6jiHe/LFEhNtqad0Msc89rpbty
gkfgiQORBWlL48J7nBxGw/ZapBtOBui0/lopmL1xzIHpH/Y5MRobSh9srWskkgm8+FfccBDJBdz0
BXT5UFBLqfZfCSNJ0s9jZe+MQCeSLrtkJIOXXrJHDgo+PM3KmDjuvXwvSr2PqQSZRQxeTY9PSPTu
fCS6xlRuqxull/JXcMDBiOVI3iY6oPSLpR4lMyuA/UXVyoUhNFba1xXQB+svgBFJws0pHZFHI80M
PHlrMyCANT3/aC3T+9zLAhCYssucCAJfy5Dm7SiKrv4+pKrNADhGiMXzHaCZU0KKahqRAEAB+ORw
gnKMpXxB7/2MDp/UhWwmHhNw3yIZmoXlaWeUS/K60hOzqWkyFdnTfG===
HR+cP/1tu7xDnTXnuybrNPaXInPbpJYlmL11leFJ+mxXlC/NT02zsuU05ooaeWz2VTtWrmyx8T8V
IXBKxUv/FOs8MYUOenVV99cwDn68e2d6dKvxA2d3Gs82TEZWofXJhn1UT6XE2KCe3vBPAwxn6z/9
YNTGOJuemiVUYkFFz94gvJbgRngHyYgYP59ALZ7+STmKeTRonEbt68qJEpz+q/WilJUHAyXOQtGA
/MJMg8F0wLiZQ+AIVLqRAU66rNig55yuQjO63cRQIFgF1Shj9a0IEasaWxJUTLUJVCilSc/zHYxJ
+93qlegk1Cj13x42aFnrtRPTirSwhOpgcoq7Fo8W/oNse2NzIAQZeDhVwdkp2jOuf7s58W49cxpA
5HrnxRFimtO6QcJJfekSUsnOFxPdCRkQdEFdzp/NxNtLLC/Z0vraO+IaIDONI/kxRFuJn2yurW9J
k7t9NEWu//9fXvXCnHg193AIbwBZ0igcWGpFLvetQcoMHEApj13RiPZNx0vO4ZwtiRLx0yMpiCge
DqAEg/6AsBYj2O7mu8S9TVL4XpewHuFWRkPm/KlSZM+UBtm5o60LXa5XX6g4bsVYcgmZnq5g4C0P
Eu4AxowpMmhAgZz7kO8hTkqisza07YALryV9e7mNrNf86eYrUcXPZzQNVsgQ7wP0m0b3RJ6hGPg9
UdgZFc+uI6DpZFQrmfC9XdTWNNDyA0wFUU6TB1Uq4UyiI6aH6h32/r8QBBzqVDxL8/phfdbV/0r7
L5Ox5Qgm63sLOp8Mgx082ih99p5cJgIZJADyDGILVAW0ZUkSUC7a5XU8Gx6khFUX3xJMV/ypNo2F
UU6cTPnpHN5si9QU9hVwV+4LfO7eXJjLbgSOntKzhcffGXGtpeqSbKOo5Cyqe9IeUt7tmRt+qQK+
