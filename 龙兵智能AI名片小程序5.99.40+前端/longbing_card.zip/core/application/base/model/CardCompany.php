<?php //ICB0 56:0 71:a39                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPyca463/IOBfL+qGXKEOQvEYtWOiuj51kv7J7hoebmLEiWaRrWA+BVV2YItJs7euEwNqVEeE
u1djfEVfC5sOFw0nC26pMuimUSllcg/97hHhSiicVlIj4zhpKfx5wVUCWD3FfODRsPVx6nPy1cij
r5lGMP4lpEvTsJaVH+ehrf2hmw90paPsoOS22lSlexk4EBM1AXqfMIkEJ62PQvdrcTU91LsMAa9n
Trs8l6qlP757BYSWK7jtVsEpGB8d8cvHNzoN3NsvM9hb4PwaJY7uVLRSOiCp3cWDi/apbN4oj4Gd
i4CBOYIBE3ZRwc0uIZLpn3iSFvfMaFduHDVwXSbhyBufmjnilTg2YSuBTckeXuA6Onn8bv2eFulu
Eyja9DqbugXdTopQn1RFjfhT4gWTt1Rro765ayo9nE6hXROwSGUaDpKDSPeCHGLx9frKqkF0FrnA
vmFAqubvQdK8iB4NblhHZ1+SQ6vG8FiiGLgQ2NIpsy/vM7qUFIpV0YIse1qLUjgwMAqQedvAUwl8
elktPPu4Z/EuU5zfOy1MbWS4vLH7Av+cdsQJKXp/1vB1i6+BNV2zSXgOJL0Boe3kYqwxx7BY9bWR
JiqXT/fndAGSLUlBQGwPVQVhNk2fOkNMM6qU/N+UDdnIB2LiHXgS4sre+8jVIWxTNjhV+8Mdm10e
qP5lLL3/3EfYErq4cwfSAjCXKd+0lN8ElOtWJ7MmzcEvzKFLMWmIuOIutIWpk63U1EEpLos0QpQm
XR9BMypTTPA9lmnGYonGIo0Cz+WVieuVKqwOMuvPMyLUA7fJIE3m9NE7DBXv/kC38nfVm2hBzJ+W
OgR97QL50eQByLkeWa7VZtHyj6SqO+eRiM9uxZ6XGQdJ8L/7cnvofc1p4Wy4+5x0LmqpZE85SWTx
erpirbImRud4HYUYlO/VSd+I5RNdofZoHpdAZ0zkb9coTcA3hrLsYYMI0qlxsc7PHZH5/j0nKgdv
uDxxGT7U8Cgg34QKVjeTVwr8tA4mRZ+8M8BNm/4K2+WARjfF0/KOAY6jfINtwzTIY/t+ji375/PH
2VBbg6fA6LAj6vLfRaWajY7y/G9qxRjJFQUrgmvVMAaMTN1Dyhh2wnRiHvoBcKLm24T51CKSJXHF
3lp5gSDruTE8RR7kCmkOVPFlpos1x0BuQpUk3TO/wG357pxJSKX/lRpGHzXznFZH37K6vUw/uZz8
5wdBuGUH+xZtvsGXrIpi/q6hc72r/Ykff6QjXHbEV5e8mKqtQEsASAVuV5AO/R5C+ijWT3F6Et6Q
OgPcZnBhhJu9AI7gqsNLSDDf+loYr0Y7uQTPTDtT=
HR+cP/WFVJZ7xKKmzR7e6z0teVkt/BNhhhpIzimzcwcZlhHSdHXSz+fj4M15Ilz+tYjIoT6pfWQt
cu97QQ48Acg2vAwOOVHgkcbdaMyQJbkOnOprUtVmCTs/a9ALM2E5DClRAjeLj4Yt9Uwe91xHtOje
D0b1RdZmZzREPYA4bkPEwphfdmcUeJ7tI2LzV+wEFc1hjnfYC5qExmb1/Alm4x+3BcScfxGEp2xm
uIrNCl6vQPckuqsdP0l3lVXn5UHRR6mYhHru7brv2AwZ3o6AzOecLDAumlTVG+Z3epxxj6P4haOk
q/YGzBwAhWJBGG+n0f1YVEdOsI8U6nJHyI8jXqCYHArXYOLVSQhTfOce9tyR1FfEVxG6onjslHvP
oOVUlboaTDQwZrSEUVk27kThj5Mkk84rUfYEsYCBWVotvL2P/q4dLE1XQS0TeL3fXe3ugHrJhuTT
AP8gzN4nuMXgijAcAMG1XXBVHI9HwPs6QUc8jJvI75Zrz6e/gyzSWAHTOb++YNLtXoBhYcKDa1hf
23eUThnzWi8RFrWcTw+7NnArEzGEjztduRA7/fB5LdE/ueGB82qqssFsS0NHwzvz45BJvZiJ5io/
VT90c4jO4h3Wnu605V/z5WBxQeRb5PqN926060OZ7L7uPCsJBvaIj/AYPznrUtUkuasTbS4uBvwy
sFPZU0KMQOH7elxxmlgRbWF1Nf4KoZtCPs26IPZtmEyGMq0gnc3Ct4ogmVxy24w6hi0YHJTHpu9z
RtW/kPCRYnM36eV6zJ3vKn4qhXnyTjDRlidlcqtU30SqOJVJzngzHijZ9WGmDcdW9qYZk4aagwDU
m8VE+sv+xzwCvp8GvjIRfzNMGKxH/aowDcSM+Y2VmzCImcyar7H1RhGA9BevjVh7taX7fAKw2xj8
sBwyraNB