<?php //ICB0 56:0 71:a51                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPyrYC0LhouWg6TUb9iDOU62YIOywIEz+fkKt8VohrPP+dl/C+Uz7YHcIl2EYPAKgLuRIcDvV
OaGJgOG0Tfgv6f+ZeWC/nNUAHx4ReM7nVHg29wURiJr94MnRSalDrqTO2x5f1/JswmRYrv/t/zB5
lfEZkLQi4FGtVat3yLWz68Cvz3vwNB7kaIdG3hl7g7lC+hKdyVeh84nSfBNfqejep9SRyEOxiDBh
w5tfJvpvVI3l/OMpaXFz+XcdfUSZ+1aQP89OSrPgFwCzUQMd4cXozxWoG2yAjrIa8dcjZYixABH4
9x132s8aYpWus+fWE4fOUPr+Sy1wJyNW6CRN+eN92V+M2ICwYJ2BjZP9bVkqTFSEza9kklC+HRza
iM7ym8QmE0/BUXSK3sCNLkELQyIchR3xOfJ75GwHJZdmiFIw/JQAIO7d//BY/l++2H2U4mhEMT9y
vNgDr4iHoqrkr1bCOhshq0IFm5mp41CW/hAm70zz5Bj4pz9uKOhiVstU3JJzKDHvSO0sIv613FOO
sqvGHH56gtlIcCDHLiHp3FbKuiYK9XL6OYvxv5EjaAUD8Iegy1og5i7U1jfB62Ge+6uiBYfO1qwP
ZEkPh7E8bxaACnySRjap0vpqK0XO+4vS/WRxXUbn9Hx6VWVWL7ln+8BDC6yzoLwOZR8P1p+Szva1
r6i8/x8cH4ATuFwuJKAiDgTb1TmiX3yNcoSW223Pkdi5EJNHIasccZzzjZa9OM01n++jv5A0OcNu
mN8uo2rxES3BL5OjECGp1QgSOhdDOkzUbpuRQcyWi6KXOXEWKPeS3s6hQnRaFMP9woQX+mD0b2o5
XR9mPJCojuQRskdlGiQivjVA8DbRGgRawPB9v1x0jhjn2FmUvbEAH/tSdsobGmvJFqcPx6qEjSi2
HgQMC/NH2CMjYJlyLKmo0eboanoq52evPBid1bQtfZiFPxsQGSW6OzNseMzFFIkrxf0w3MOTT08K
T7PNpB6AR3wxFN63C0m7r5zX9qja0iS2U3AeeGusgYliw2kwUzf+eDFQAGH0Y+FQE4G0NTvncyLX
/RmW5aB/8EY7oPu5mhun/BsBPGCw/4AJvi8N6sc/JIDunPy/ctNXtwLFZ31wBIPDkMrifgPYq6Vb
QwOLum4aaMRGNrtGTJDN8ZZLTbtJWDCZbfhzs1eHfm89a6kXMuUBZNYiS91rISvWw3i47zpmLWMo
anJfwYgBbOZWkNuaFww/GdppcN0KBEuNEr7Z7uIzTrMt8Flh4+2aHGWQZd2mgtragK8LaLUY77tw
nihP6jtrXO2yUUAkLf3WIlbPdURf8i8GGT7n4ucNE4l4+Zlv89ybjrExbcaXfm===
HR+cPqQOlmmcU0GZL2OgBoe+DqAzW/NYQNNMNgJJo27CYP7ZC7wBHIXyIdYDyEW/32xCTd6cDobf
6cZIbQn49U2Xh5+16YQJK5qWWXMDy2DHdDSP34mct+npW4Dn76/xtgM7ZjYDohKKhzuTbiLTCCWs
O4yojnZW7DR/+xqu/BVk3O9d4DcvPEH9hi9Kbv3nfZds+pJPqoO0z2fuKNYKSwSaIwMmSzIjQLqG
rZXkv9LAVIS4hizE1CvixLoyOYQvcfNk7bRICLStB9AkeVMXg6ZMHDip/vW06woKk2bsMxFYHYxJ
+93qlegk1Cj13x42aCrqFO586/1IxODNWIs7FY8C//b/cE0T5gGhxeZPqDKeWSSIyn0WIgwU1Zd+
1UThjoYoge1qioNGBw439veKNoHKMO7ARqowo/qLo2W25Extce2RQvo8ckC1lz3CCfDsRizStq4T
vXiJJjquFd5gRdpTFNKNOBFBN0UQGO/b3iYwXotzIicLB5UVCZymy8pwPg/yUBLbePYZTNhB+Jr6
UKe95Wp5DnW/u+wmbpG4xJtzNT69DJbTxi7HxvN7Y/dtV9wsJkQCh64QNlnyJvcrn7i9WjBFZl9l
b+mHBd2bubLOrNio49Rmx8bmz4XaS4yDMZVZ+Hc44DGL2MuW+WUAupQtC+ENh8IhagmSiO1r9Ykc
vs2Yeo+Kshg+O8u8LtHKx4Q9nSdLg+eS7PNioLYwBvZihfsvduHgqrASKSLq7FAGgRevoWlC6qA8
DQT1h1cDamLRVIzPsj8Q67o65eAyo3WX97Lve0YKDDPH58hM3/GcYoNGThJEDBt5gimed31hciss
l5Cz7p82ZatDnANNz3umdgJfiGScqc0mCHq7f0LYYYXGKCZyLHpF6tLWMiSFNIx2V5lFkd/G1su=