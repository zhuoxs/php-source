<?php //ICB0 56:0 71:a35                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPsSebqPOzcjfJfm2PHlEQnlkGwEQ6J1CSR/JAfAeJ7PC3VcFA2WwrQic/X2iV4Iy7UIxJQhv
NMK0qRTtsjpewUdr5YWQuKVeINuCryiQgQjpXiNiXJYXbP640pJPpdmLcpM4Kni/FQnl8TY5cgsY
5zmsxRWZINDTVrlOIz8Fw16jl5+uJHKnVnXfTrfZUJgqGh4WdJQR3YfYIGWSHDO9e3IEGq2TPA0I
RCgNgG22WfyHoloOxZqqDQPfp85ByU3xwEs93RA5Z9EFZH2261tQ4zpA8pjfhJVKLgLLhuxUj4Gd
i4CBOYIBE3ZRwc0uIfTlbZ4rPWNZAucJKjTYXCbJQz75yooDknDD7AoVtZvtek/67IMlRglPnwgN
FkJqAbDcoxcj6T4AOV/eIkYeyFiE6lu02PTJqsA47LI/8BRd5XqXqPFZWpQd+eHSWqTC1Op/HkQY
OgtEP3KvjuZbRsqfItl0G3KnUNW9BHXOarHKauyZXeE6db8m+hnFRjrclP48S7ABUSBaX/X6CKU2
p85p0acp3oTF6UtVRnTycPchP0lr3l8EU21YnaFKQjgacRC3oYXCZo0EPJZwUnVVJZIjArLGOv1U
nlR80ysVjEW4/Fi4j3iNnH5iJAcB3KSvR2HXbUbpArHVsMRlxJHW+r2UITEQrmXoYdLdnILmFtQV
dxVYVq1A48QBDoUPZ0p/bKG596sKvHUkMdUsI0LEQIxecLou8E/BaRMg5bmLsk0ETxhBFLsO6tnO
YUiz2VvUhQi3pwobn3Q1U/ev7wMC75+0XdMqvmAkIZtNMYUUAg3gPJc3LN6e7LK9HhUdeROtgddL
3Bf/HowIdPhRE1Zb8Mk6pNuFERMNKXneFS78oJUDPJiF6K2UWCQFwrHcMj/kQ8BrZO9PJhLX1hjG
Rt4ekHvHXDpbHzwsYXdHKjL+r1HIf1gddzNXpgTYJ4/uzm6NFRKCAOTfxKa0GQU4sG6SDr45Oywa
6WhJjHNIrt8KCjtsBL13QZOm5L3+muaa/k0ZcsDQAM56SB5Q0jIzXcO3QnBAe6A7KFLgf0GoIkk7
NmXS1I8EjbOUPhIumqE3mHOi2F+LNWucVeDsr6p9RpsMY9XiiTsY4O920E0nG77VgYJCy3HokoJL
yS3sr/wEgGoQqgVd4iFXh3+q7aS5kDF8gOxPtaXk7dscMICSAzGxDuERKH39yhFwGtWePs7b2isy
WJe5J8MMgx3FlvE78rvyahOUJXk98WLaC/61e9JDyf7eRYWDlmNxBLwI345hLec2oFJQg1EJfh8g
tfK93CWOLPZyRZzd0GnXIIWLCGnnqQeVNMWX=
HR+cPslEuwv88jY1Vd1sZVrUZ/1V+ehzqZ/LCCmE9SfsvO8KhY6hO8btx5RdMDyzCwZAJLZjuOe3
KODkjCGCuiWRyxW1/xTaEeEXParxEaUb0m8VIm4nXORMJTHdmbbmagq14/PSrkvRsekFLoWLgMOn
GgAZ0BB9iiZzSHVM1P64RVeNCkhx87Ef2FjPZ5gdy4utqMbsKt5NXnH2wyT/SrSx+7fWyDv4dah4
SMVVv/A3wGNgeeo2izUjEkrlsy0aNjYwESBQt1i7gK4+WatzuMvucvQJScpdwmH0MvXBBBYA/CEn
HYxJ+93qlegk1Cj13x42a7jzTRUwXZzmB4KeD2q7Fo9X/pD+CCTmhMY0legXJjAXMSdlCjJpjq1H
fYSXkmdZfzgcHwpoxFcbqONZVUpM3IP+zn4L5hLuYRle4f8OCmB1wswkfMui1Z/j8HfpMxJqhEeq
yN8u+a8ME5wVqJQMKM/e1y/jEl74NENK77QEHxaLRDOvQlmSdDhDUonm5nLsN1gNLJK7O8fFOvkS
IJuLZS1FiBkj5N9D4t+rOedod9w2SU4bGqJa8ukJGwhWAX4fxhybfUR6QisiErlDr0fbA/huMuqX
05q7C47I5DjTxIh07v2GdTaK+hv2h5A/LeBF24Uur0ztDFv7HyJk2fPG+ApjzmaNAaTB12WPTR4v
+aGcwXen+ztpbREVGUI1PbrOk51aeEdquB8/OFGSF+n1Jp96tIJipCx6RAAqlEVWWsxRbuZJD9gx
6ca656tjLTidX0hLCzokVzGv2h/N+UGpAQuV6wNbB65fFSrD+z20uXpGSByEPxDGhjUzcyIJcRHP
2+aD2j7FyUSO8hjUySw67HTCgQ5n7JFip3MWHTMhDQJRol5OYsxBBM35cWl7a/yxVK6vUzJdOm==