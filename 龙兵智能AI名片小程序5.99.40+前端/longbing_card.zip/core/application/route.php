<?php //ICB0 56:0 71:ac7                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPuI/aT+BXseGEGe4/FQHh1u4T99GGlKv4UjUSfmsNl0ccMf3XCSiKbt8JyjXQXNbJNM22Xhz
+Ofmh5KNDrl/4rhWrUUELm/ZjnYg6ZKnysXtzNzwOwxEVq26xIrzqkITlJSJmoARNRCC+dU0iS4L
HPM6cgm96cYTpF0hRgRV2YVkQbbxrheGE/07bIBJBNK/qko85vPaRZGk/dyrmzg834g9Jv3q0Ar8
W+YnboSZngL88k8FPoX6OouNN4c+5vIVCVeGKPE9YxUD4JQQiZQWWw+bv8JT9OxzNwI40mBLhXsq
H2UmGmjY98iuEDlgO3XAXt3oafCvavb+rxwWH+aGqq8ZiINSofUOep9q1Dx08MuLBh7lbUwScquT
iDjl45Nc78co7PA2+ozkLChnne+wmXjIAEw6WiRF4cSth7aNBoqJUgzN/iBbn+9e9Hxs5znUEpUn
yNYT4A1YkAWpNYliZmhMZkAsPeTxHLzkN3PrAUlk9Zgz0NMze7M+itlkoMCDaWnCnNRMGCv1qyJ7
PwB4+4SEns1GFGMFQIG1YuJTUcGT3otoPXqi4Z9uKixMxXJmyA2ihnSgNSqMVQdvizM4pQVlHRa3
rLRZ41rsB3Jszcrh64qThtfPnheTIuN+8UdzR8R9Dr98sYwFOv4ose2CvvC0wo+GCZYGrJq9QUqh
mbbRy1qccjuM1TwwbGWiE/+dgsSMg62lzjQfgI3kBCY/xYXY96BRpfzLBauIqyWFSD0QdPPoLoQT
MrUWLABSrt7D/hVXqiA2vORS9FPGkKdR0p8E82CNh6KhLbyeHl4cMcLUfIyEKc//LfaWWA3gB9H1
g4jsU+QwMA9/BMwvsbhyqeHb6pVHD6T6XBa3uFI1aCguH2kmFx6a8cVUKV+oi5SNH3ukxRhVO9Lq
aWrAWA/7B/ZMP6NHPzyNWW+w7MGss8Tw3fDmTZPB1GmtKcjt4w6yGTM3d1ZojUPraN1tcy8U7TE2
jBJgPnWAfz2EfJsAv5w9S2bxpIUqmoZxkyzmJKVoqhfuk6JmXmhsHCK9DDma/vpxyk90AGjtdi4J
3e2H89QKGb98rl302o64VK2hWUsqIKOM47AnGrPMcH6/MeP4b8huCzeE7W7XKc2Wegvip5T3UOnB
/cw3k4TkvMhy+npuSoGDpy050UcK36uYNeyPDfCsG6TCVwp2LEZc+la9Rz/bcSnC7JGlpw43EORH
aA60nMJyC2VOSYb9uBLonhw0zl/x7OGXdhNi/JRbzoCk4HGQISebKPt+iMmdIffD704me1EZAysj
pUGwXD+BU3TxjiVJlbGkrCk/bZ6CV0wngpZiGym/uB/pnCidSN8DVwC/Iw0dzv24kgPHh7Xs3uFV
jVs+9VHYKtmCtJYmZ99A3c4tFTQuqMzhwEZolIvmb7ZHW/9TJcWgLeGon6otBwiCWA+W0PEJNr35
b4j2kXWjU0Vw2jmLtfr6UAsRe9zd=
HR+cPtXENEl2egJCyF39o7x6zDeYGj9YKL6HCR3J8ZkFUIvizFPwHfeMg4lDgL76emRD0Br1X76n
SjlaR7HX+2PxzazXpg/XB1Tmk2B7A5zEh5CKXzSsDVT0KQLuMaRYkrqD86A5JVj/wbLylrh5pqUs
2vGNOl3dTzolSwuPbS6IonXaZZFAl5SIbVzp9klUj261CxlE6761vYCAN+nw1duiJY5hgeAY6DvL
mn9ANqQwpCQ7YqGi9sTcNmF+/nkotIHWPQLX9Y/1HcuthAuPQ3JjM8VUtGd+edMDUtNY8QHWHYxJ
+93qlegk1Cj13x42aEDsMDL3XFEO8uZAfYq7tpWm+y1qIVTEQvjd6l0lWH5EOnyXEL7HbIKXOAeQ
JAGR4xcxHZ/2Ywtd72/SdAcGknuPd6mw2MA2XMI2trDduTddqJIfgYEbSs6xc8Q1ROhoX2gfhszD
z/553vNNKOQOh9vWJOduLCcCsJLfjt9o5XKZHmHXp45xc98uszGeE11FnkQ06TaEskhb+MEmnQyh
VsWftvUR82aYYCnk3gnS0OA+V9wyC3gEYkKlyltgWuj9/zEcaH/FOFHHBvbLy7GBdmDwkma1dN7r
H2K9+UG2yqHtuFAbCWHiqy/JjY2WGuaR4k/F1vjTIfx4XiWMoyBK3+cl8TNVUvZKupBBl9YfaF9h
0qLo7Hi35fERcvrg8XdGV7JG5WOs/fAuN0JksTVtzRtkzs+5IHzpMHUlZYateh6xtfQxnG==