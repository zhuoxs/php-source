<?php //ICB0 56:0 71:8b8                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPpscXv29S7odFnqIipsF8f0j7ETj3gwcCeJJizKVCsACxQRCQsViKBT+Zz45M6GIMy0J/KFv
GejSIdfk0r6RPDT2XArZ9Pbp8AU87ahsv6aIP6LNdPf+m1cgDplYsqOWYKlp7AFq3tkWVMq/ONX5
CkiN+EtfzMf0sqTTUl/d5AsvtSd1jvardWo25X0vKVqJKMdtJC6YfF5oZWx9nk9uLS/25pUe5ZVX
xLRncB4wPiW3HqfqssUdOb/UcCAeRMWbRXr9UD9ZJ+tFzh3QblDjjXDInUM908yT+2ksc/P0Dcdw
znvOlUL5WaX4o8xCO1vtcdT8+tnHkJKZlugfMAfw/myA8J88tfXcBxEDOEImbiUWl42cfmuWNKzJ
KJKPC4WD8ZT0qNDJGQCHcnkC2RA9xPFu+cd8jCSCXO+Nxw0sNxss+7HCiAZSXSj+u/LmqNO8/z08
jdzzodV2XpqMFr+cXufMe0FpG7PSeaJxAmXgY/6n3MI84usLzaOJxjzHoXLCDSGzBAVu0wEJ0jPJ
CG7Vs14LWxroa2YnkFvr06qogR8QY/P+TV/taOFONXPUVb71EUyj11PWZPU2bme+x1rddTi2s/lk
OMnNaGBmyEx2ShwUcHuwffG8gNPySvyelx7No+Y565UFYg59oq+JaRVP6T2ohqjG64iozxJflYVc
06maHoCrFty2uiX/PS9XMSkYL+5+SubuzZzFvWKgwz5473bQKqChZB8QYwiinAf69Lo3r1ypSwiS
AL2s/x8dkf+mt6mn6AzudRHkmQhYHcodoPfetP5trX5U9wHL3RtxQ841cKs28M+y0u2aV+knAeIb
G6FZrr6kT9ihiGJs0Q4aYFkOE+s21UyqrwJGRRvcUNMM2vNivKh2kEnMVJCpfmSrr0DMHsrE7Dg8
VSF7iq9IvOZfX2UQOtG8qwn/uog61Mcx/zJTvya==
HR+cPzxbkpbSDm0+Sbik6WDaDdnuwiCPEBQ4Ayq+F/RZuLTVsFcurlwG3+eQsSsc0QP+PQJvGEIf
K+Ip2bD3SgxjSimN3jmqhf1rV0r5Xe9x1eWxzXm6UbXeY2/G0B2JEb2fumGStKdttzp9o5NcJroU
BxqQBtuFRFEO0llG3Lzb5d3mfuQIyZXlRibx4mEZcljl7v5e06MFdtFmAB4ji2+xeOaXcP48eLfL
0W78BZRR8YcVPBHp+t111jJTVdrZcLedU8JTUs7345AEHyrveEXzRpEEBu59I8JHjJhlUC4L/WjG
95v3+PdICaqmHrsfn5DGx75oEQ8IzSUdFNCZJaCSs2NTj2cxROqDfhrXvO/uzd8z2c0DYwQGFbvo
7InLd1leD8FJgNnTV6+hn3agQLGfB9lOA+gtwx+RnBdmf2Slpl61CsTZ/L2hztR/u72Yy+KQMDdR
3oKOU3YCo6vjOwRw6TG92mzXYKadCXqc2uIAe1NBXWCF4BTAHOyzkvGg1Oj+gxouiGYXLqG1qyp8
1Krl8z3l5b+wDkJCEQu7rPNM9UyUE53i03TgSWgylfmVUb5V77qVA1+2YeRUcj+lgpCdUI1RbgOV
btSCwoy8sdky7wPdFmBGQdqVVZvFR1Jhna25la8FyJILidpmz/pZRZCc7AyGWfev4L+JETuDwBKq
uyCkqNINkpUy0K0QcirZiGABYJhoi/62RfbUDhnkAA4rv8iiZG4wZFnJeZ8vuGywq8xIOVkJrjdA
EpUE7kjBSlaIfew3C1IdaIl6h4IRnIa=