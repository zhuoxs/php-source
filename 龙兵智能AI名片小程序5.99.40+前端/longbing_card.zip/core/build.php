<?php //ICB0 56:0 71:c8d                                                      ?><?php //004ee
// Chengdu Longbing Technology Co., Ltd.
// http://www.gaoapp.com
// TEL:18828021173 / 15680635005
// Please buy the authorization of the genuine version. The little brother of the program ape has to earn money to support his family.
// Upgrade genuine data is not lost, there is a discount to upgrade! Thank you !
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo(need php extention Cube. url :  https://www.kancloud.cn/jingshuixian66/longbing_card/859348);exit(199);
?>
HR+cPu2XlylvYmJixnSgwEec8YP2ACRNOo4cQU+CQFGfEFmFBbu9aP+FtyQFSvF7wWLlS7L1Hgc7
6DOgzOkY88o5wPeBmf5kevwkk8WZ0xl6mNC8UIX2QItRdXzBMQQUvHqSWvhm0AgeBIzXV/KZTdx/
r/97Fw3WW/DBCeIv93TzrMoL02k18AT/jZPqdzimXa5DcOKEBhqxxxblKE9RcP91J5RgKpYaVuxh
7ZEmx/vYv3K8Myuey5VARGqkthda+z3WZQ0oWgU2DfOdB/2/kROqLRYX/P/Bz5e05kl5T0uie7Ss
QVht7bYzvKM2I4J8ZinWCNZjX+ghqs5RcucwYZ6Yx0EMqeWHr9HbHxaZnU2Z/dVLx4LL8rWus3yo
RwrR5ijv8kxLz1CZj4lL1T4Tc0TaY8RhgH+iBL9YOmJ4TstH2g2imkilFW5357B8Ph/djI9OA/Um
qLJgDWig9MEw+Qpf6XvuVjVErB9g2F9L1YO8D80z4Er5Xs6QelS4AspF/L2JSnICNNheLvAnfAAt
8Q71itabw2ZCpYugW+XWQBhfDjOD8JECtFDXf+ZXk0gOvAATsOWk6YXhgg4TZ9USGXzIe3NDXvDH
Nqby+uQoxJqeI7VQqFbvDJOaTKvL8xMWgmIlrqYviJOWCiEbCexdYZqiRdWM4iZbhJ085OxZYJJm
TGsUhpxB1RRIxHQglSyK3AXGIxx5vPk6Si9CPJU0KJ/mgbKD1o+uKhVr6V1LkFOMwk1FZybGghcV
16q84qsWPxAprKAGPNXT48raTI8P8NCSDmxFOoTPC+ukloBXVb2I59zWg+K29Sy593h33KQC1vEk
0EFsTbkmUmMgpQGb9fIraQEHFsKWmdIGbvAccix8XDAAaZYfgAGiJxRDAMyYx30LTOOJSlEuSEz3
sIJbKWMFzxS+FxwfkNFvCjWBmuNUTqXVjIyJxKsu0pkqMyljX9B/6TkO2DurV7igORCBf0ekIINl
dx32Svr54m971VWkUzvs9Z3UItOWnx0xIPqbk45p6WNqoNQdMu1A/mQSGuotj8ZIeikVSSmGzMz5
HMcMWgsOAtQSPomOms2cddrpD+ul6XhyluGJ6cO1b8gWnL0H8tZDkVVpiodJZ8Vfi/8MuFBMRe5O
HxhQXtMwv+2V1Ldg5GXb5ch5JsjHP10gIiNTkJN1lnpl3C6dDXORzjmaeVK0k3y53lOqdEOiap6i
XAhLgOOCn6/JcP6AbfBA68vBo4DSR1yfzKl+3v8Biwx0+9QhMyjGrVDEYf2W/sX+l9ktrO0qqf0m
P6lYxTus2Olod2Lilvf0QAM/rWJZmrFPlW4ALIuIH6TqAm5nnA3is39ytTd6rB/CimeB1GwT8+8d
v9wp7APKzwmbRHF/an7GpmenORnUKqwmxnvANqiPN1pchH2wzlNDvn0t8VDg7b/D886819418cts
J07UOeX9LGIYXxkl8dXu0tgYtiMnEQRaRb2k3b+uSmPBVb0h0Cia9UToxD6Gblk2cWsf9k3dLG9x
tqSIy2g3yv7HJ/W/Vr55BemOg1SGXrtqCZXp/GoovPrfCLqiylit/eQvp70OBcm7LR+MBQmSIK9x
N4fV40k6fG8bO27u9WL397acL3Ch8Y2k20W1DwKgjPP6m0wvLZZLsSIQbsNdh2sw4xH5cTztKGsH
+xRQcpTNeFnRPOhEpDhmamodNxCQcUAADvqEOTGWQYkzeFNIiaRt28gE3JVK1EjMLzVxLxqrZqXc
P58kaAQs0SHVu/UAxKgJyGRMKB6TeokKSC4VQ7ONSNbUj52KpaR48Az0ppu8Bni0kZGq4o8ZvIdT
M9JKVjrck9RJcXkL9sqcvamOmhHrmYkaRYt2hi2NP51h2o3jXGPUz9r40xKFY+V95a2dUAMZJmgu
BpeGDAG9rK6+UJBBam===
HR+cPwTg/S3gpiNtcDHeu+cxLFPGrPN1pCykXSV2Q1hY2HP/sz++tpwZihRU0Z21Bn7yQ55EBhL4
mvrAszgBDPoxdHta6cYzEmEK+Ze9qYIXgSNt32bdxlHAadaFdhQpb/MtsCVyj88PNOanJPrPwSF1
OiqFcvaS8X28vVMS6gm28nsOT1EgIgoZkbwnrLnwaskyb8OWKSEf5ez6oBqDmskL+yuLXZcfp/E/
L6n8GJ22Q7grmm0GudGAincP4R41h7uLpRVDe3fotbfrD/3U8IwE4BEx0LNjh9hwrM7PcDY0450a
NaFvcT8oJJ17NQd4Kr2wUrbdZhVYhBACiul+n1hO7BgZO0E74NX29LtxOAZNiyhHBirNORVKHz3l
g2amWJ7XllSiN+9sU6Dog7Fs799vrz2McnRFI3Dtr2urjs7o6QoyQ+mtA2tVOEmz0S26JYbO0Mai
KhF2JrpN21y3yIVH+ExjShtIr51T9CekLffR+beBCLcwHp8TsIlBP83KtTUm1yFsoQ1zY8gY3KbN
FGWkppC2XCWF4VfgEo7aZVqlAz/j4iCJY9gZyEMvacY+4lXn3J7gWnCjzQ7/L/ASnW94UVP4rOR2
GcA+SPyh/51j3QIWw/RSt5SMtG/N1LHbjtaUsenmR4j+4oAUrj6zwMy4I1QYHw+UHJ9ymBmvVINH
ADwDQUCBisYVW9iws1G969AipD1Tl4hungT4UvieMZEyyyG3PXRJ6IxHsss+I64uIPEmnPVCo4DQ
aXUhMkDtQK98uzj5V6ed/sSQYrYzcpWKrWu/lkLJbpLpYDahKhkzq5XNTt2P8UjNysBN+hlSfTQ0
xnf0ob15IRLMFXXt2vjGMyLAjnUHiBaBX1nxcLp/ImRv5dRF7HXK2f2DbRhVNkU4xrTp/lckDdrH
7E6Xb61Bzp5aQlFd1HtQkFVR1Cu=