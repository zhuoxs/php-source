<?php
/**
 * @copyright ©2018 浙江禾匠信息科技
 * @author Lu Wei
 * @link http://www.zjhejiang.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/10/15 19:27
 */


namespace app\hejiang\cloud;


class Config
{
    const BASE_URL = 'https://www.baidu.com';
}