<?php

namespace app\hejiang;

class SentryClient extends \Raven_Client
{
    
}