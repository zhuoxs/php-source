<?php

namespace app\hejiang\exceptions;

class InvalidResponseException extends \Exception
{

}
