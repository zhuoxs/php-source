<?php
/**
 * @copyright ©2018 Lu Wei
 * @author Lu Wei
 * @link http://www.luweiss.com/
 * Created by IntelliJ IDEA
 * Date Time: 2018/11/27 15:27
 */


namespace app\controllers\cloud;


use app\controllers\Controller;

class CloudController extends Controller
{
    public $layout = '@app/views/cloud/layout';
}
