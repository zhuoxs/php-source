<?php
return array(
	//'配置项'=>'配置值'
	"url_model"=>3
);