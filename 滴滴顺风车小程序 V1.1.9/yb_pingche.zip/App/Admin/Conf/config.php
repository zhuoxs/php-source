<?php
return array(

    //以下请勿修改，否则会导致程序无法运行

    'UPDATE_URL' => '',

    'NEWS_URL' => '',

    'Version' => '20171111',

    //以上请勿修改，否则会导致程序无法运行
    'TMPL_PARSE_STRING'=>array(           //添加自己的模板变量规则
        '__PUBLIC__'=>__ROOT__.'/Public',
    )
);

?>