<?php

namespace Org\OSS\Http;

class RequestCore_Exception extends \Exception
{

}