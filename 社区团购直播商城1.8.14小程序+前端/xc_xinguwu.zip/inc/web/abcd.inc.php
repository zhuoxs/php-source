<?php
 global $_W, $_GPC, $xcmodule;