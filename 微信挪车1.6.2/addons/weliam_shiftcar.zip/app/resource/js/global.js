$.config = {
	router: false,
    routerFilter: function($link) {
     //    var href = $($link).attr('href');
     //    if ($link.hasClass('external') || $link.hasClass("tab-link") || $link.hasClass("open-popup") || $link.hasClass("open-panel") || $link.hasClass("close-popup")) {
     //        return false;
     //    }
     //    if (href == '' || href == '#' || href == 'javascript:;') {
     //        return false;
     //    }
    	// $.showIndicator();
     //    return true;
    }
};
