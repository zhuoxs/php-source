<?php
require_once IA_ROOT. '/addons/weliam_shiftcar/upgrade.php';
?>