// yzmdwsc_sun/pages/index/shareDet/shareDet.js
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    navTile: '商品详情',
    indicatorDots: false,
    autoplay: false,
    interval: 3000,
    duration: 800,
    goods: [
      {
        imgUrls: [
          'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152540565197.png', 'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152540565217.png', 'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152229433564.png'
        ],
        title: '发财树绿萝栀子花海棠花卉盆栽',
        shareprice:'0.15',
        detail: [
          'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152541264562.png',
          'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152541264579.png',
          'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/15254126459.png',
          'http://cgkqd.img48.wal8.com/img48/569611_20170429191245/152541264601.png'
        ],
        visitnum:6
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.setNavigationBarColor({
      frontColor: wx.getStorageSync('fontcolor'),
      backgroundColor: wx.getStorageSync('color'),
      animation: {
        duration: 0, 
        timingFunc: 'easeIn'
      }
    })
    wx.setNavigationBarTitle({
      title: that.data.navTile
    });
    var gid=options.gid;
  //  gid=10;
    that.setData({
      gid: gid,
    })
    var openid = wx.getStorageSync('openid'); 
    //分享进来
    var share_openid = options.openid; 
   // share_openid ='oC4wb5PsUhWtdXfdj_MV5F5el4BQ_1';
    if (share_openid) {
      //创建分享相关记录
      app.util.request({
        'url': 'entry/wxapp/setShareRecord',
        'cachetime': '30',
        data: {
          gid: gid,
          openid:openid,
          share_openid:share_openid,
        },
        success: function (res) { 
        },
      })
    }
   //生成测试二维码
   /* app.util.request({
      'url': 'entry/wxapp/setEwm', 
      'cachetime': '0',
      success: function (res) {

      }
    })*/

    //---------------------------------- 获取网址----------------------------------
    app.util.request({
      'url': 'entry/wxapp/Url',
      'cachetime': '0',
      success: function (res) {
        // ---------------------------------- 异步保存网址前缀----------------------------------
        wx.setStorageSync('url', res.data)
        that.setData({
          url: res.data
        })
      },
    })
    //----------获取商品详情----------
    app.util.request({
      'url': 'entry/wxapp/GoodsDetails',
      'cachetime': '0',
      data: {
        id: gid,
      },
      success: function (res) {
        that.setData({
          goodinfo: res.data.data
        })
      }
    })
    //增加访问记录
    app.util.request({
      'url': 'entry/wxapp/setShareAccessRecord',
      'cachetime': '0',
      data: {
        openid: openid,
        gid:gid,
      },
      success: function (res) {
        app.util.request({
          'url': 'entry/wxapp/getShareAccessRecord',
          'cachetime': '0',
          data: {
            gid: gid,
          },
          success: function (res) {
            that.setData({
              record: res.data,
              record_length: res.data.length,
            }) 
          }
        })
      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that=this;
    var gid=that.data.gid;
    //获取访问记录
   
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    var that=this;
    var openid=wx.getStorageSync('openid');
    if (res.from === 'button') {
      console.log(res.target)
    }
    return {
      title: that.data.goodinfo.goods_name, 
      path: 'yzmdwsc_sun/pages/index/shareDet/shareDet?gid='+that.data.gid+'&openid='+openid,
      success: function (res) {
        // 转发成功 
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  //去购买
  tobuy:function(){
    wx.navigateTo({
      url: '../goodsDet/goodsDet?gid='+this.data.gid,
    })

  }
})