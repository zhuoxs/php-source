var siteInfo = {
  'uniacid': '92',
  'multiid': '92',
  'acid': '92',
  'version': '1.0.0',
  'siteroot': 'https://sc.lzywzb.com/app/index.php',
}
module.exports = siteInfo 
 