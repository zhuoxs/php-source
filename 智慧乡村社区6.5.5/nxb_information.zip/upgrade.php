<?php 
$sql="";
pdo_run($sql);

 ?>