<?php
global $_W, $_GPC;
include 'common.php';
load() -> func('tpl');
$all_net=$this->get_allnet(); 

$base=$this->get_base(); 
$title=$base['title'];
$mid=$this->get_mid(); 


$gz=$this->guanzhu(); 
//判断是否需要进入强制关注页
if($gz==1){
	if ($_W['fans']['follow']==0){
		include $this -> template('follow');
		exit;
	};
}else{
	//取得用户授权
	mc_oauth_userinfo();
}

//获取当前用户的信息
$member=$this->getmember(); 



	$count=0;
	$pindex = max(1, intval($_GPC['page']));
	$psize = 10;
	$total = pdo_fetchcolumn("SELECT count(id) FROM " . tablename('bc_community_messages_record') . " WHERE weid=:uniacid AND mid=:mid ORDER BY id DESC", array(':uniacid' => $_W['uniacid'],':mid'=>$mid));
	$count = ceil($total / $psize);
	include $this -> template('mymessages');
	

?>