<?php
global $_W, $_GPC;

header('Location: '.$_W['siteroot'].'app/'.$this->createMobileUrl("manage"));

?>