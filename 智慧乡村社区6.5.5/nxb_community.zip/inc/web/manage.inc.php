<?php
global $_W, $_GPC;

include $this->template('web/manage');	


?>