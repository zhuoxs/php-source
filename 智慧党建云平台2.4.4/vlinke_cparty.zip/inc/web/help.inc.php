<?php
global $_W, $_GPC;
load()->func('tpl');
$op = !empty($_GPC['op']) ? $_GPC['op'] : 'display';

if ($op == 'display') { 


}
include $this->template('help', TEMPLATE_INCLUDEPATH, true);
?>