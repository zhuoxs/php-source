<?php
if (!(defined('IN_IA')))
{
	exit('Access Denied');
}

class Web_Repairman extends Web_Base
{

}

?>