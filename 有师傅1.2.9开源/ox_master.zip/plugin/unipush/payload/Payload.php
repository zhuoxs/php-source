<?php

interface OtherPayload{

    function get_payload();

}