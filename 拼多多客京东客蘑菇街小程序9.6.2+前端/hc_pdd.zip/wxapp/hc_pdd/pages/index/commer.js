function sayHello(o) {
    console.log("Hello " + o + " !");
}

function sayGoodbye(o) {
    console.log("Goodbye " + o + " !");
}

module.exports.sayHello = sayHello;