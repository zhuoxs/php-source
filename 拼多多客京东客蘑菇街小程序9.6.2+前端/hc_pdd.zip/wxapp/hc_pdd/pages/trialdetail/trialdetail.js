Page({
    data: {},
    onLoad: function(o) {
        var n = o.goodspic, t = o.goodsname, e = o.goodsprice;
        this.setData({
            goodspic: n,
            goodsname: t,
            goodsprice: e
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});