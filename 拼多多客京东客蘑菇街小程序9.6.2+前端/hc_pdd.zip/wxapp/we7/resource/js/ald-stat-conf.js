exports.app_key = "3a519b4f0ebbd3c048b6070b6534f292", exports.getLocation = !1, 
exports.appid = "wxba838d8d283dc3a9", exports.appsecret = "2bb7cc6fdaf80ee99227e3bacdf6f28f", 
exports.defaultPath = "/huichuang_shipin/pages/index/index";