module.exports = {
    name: "翰飞网络科技",
    uniacid: "2",
    acid: "2",
    multiid: "0",
    version: "8.2.0",
    siteroot: "https://pdd.jxxdvip.com/app/index.php",
    design_method: "3"
};