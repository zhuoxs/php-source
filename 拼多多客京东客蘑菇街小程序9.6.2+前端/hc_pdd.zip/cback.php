<?php
require '../../framework/bootstrap.inc.php';
global $_W,$_GPC;

echo 111;