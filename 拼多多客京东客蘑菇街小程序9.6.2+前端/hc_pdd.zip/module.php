<?php
/**
 * 会创拼团模块定义
 *
 * @author huichuang
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class Hc_groupsModule extends WeModule {



}