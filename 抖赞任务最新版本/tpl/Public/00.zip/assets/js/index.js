function TiMu(){
	for(var i in data1){
		var div = document.createElement("div");
		div.className = "entrance-bottom-frame-line";
		document.querySelector(".entrance-bottom-frame").appendChild(div);
		
		
		var div2 = document.createElement("div");
		div2.className = "entrance-bottom-frame-line-title";
		div2.innerHTML = data1[i].title;
		document.querySelectorAll(".entrance-bottom-frame-line")[i].appendChild(div2);
			
		
		var divli1 = document.createElement("div");
		divli1.innerHTML = parseInt(i) + 1;
		
		var timu = 1
		for(var j in data1[i].xuanxiang){
			var div3 = document.createElement("div");
			div3.className = "entrance-bottom-frame-line-button";
			var div3_id = document.createElement("div");
			div3_id.className = "entrance-bottom-frame-line-button-id";
			if(j == 0){
				 div3_id.innerHTML = "A";
			}else if(j == 1){
				 div3_id.innerHTML = "B";
			}else if(j == 2){
				 div3_id.innerHTML = "C";
			}else{
				 div3_id.innerHTML = "D";
			}
			var div4 = document.createElement("div");
			div4.className = "entrance-bottom-frame-line-button-frame";
			div4.innerHTML = data1[i].xuanxiang[j];
			div3.appendChild(div3_id)
			div3.appendChild(div4);
			document.querySelectorAll(".entrance-bottom-frame-line")[i].appendChild(div3);
			timu++
		}
	}
	mintime = 1; 
	var dact = document.querySelector(".entrance-bottom-frame-line")
	var active = "active"
	var none = "none"
	addClass(dact, active)
	var timu_id = 0
	var select1 = 1
	var frame_left = 0
	document.querySelector(".entrance-bottom-frame").style.marginLeft = frame_left + "%"
	document.querySelector(".topic-frameli").innerHTML = "第 " + "<div>" + select1 + "</div>" + "/" + timu + " 题"
	for(var i = 0;i<document.querySelectorAll(".entrance-bottom-frame-line-button").length;i++){
		document.querySelectorAll(".entrance-bottom-frame-line-button")[i].onclick = function(){
			if(timu_id < document.querySelectorAll(".entrance-bottom-frame-line").length - 1){
				frame_left += -100
				document.querySelector(".entrance-bottom-frame").style.marginLeft = frame_left + "%"
				
				timu_id++;
				select1++;
				document.querySelector(".topic-frameli").innerHTML = "第 " + "<div>" + select1 + "</div>" + "/" + timu + " 题"
				addClass(document.querySelectorAll(".entrance-bottom-frame-line")[timu_id], active)
				removeClass(document.querySelectorAll(".entrance-bottom-frame-line")[timu_id-1], active)
			}else{
				alert("已完成")
			}
		}
	}
}

function addClass(obj, cls){
  var obj_class = obj.className,//获取 class 内容.
  blank = (obj_class != '') ? ' ' : '';//判断获取到的 class 是否为空, 如果不为空在前面加个'空格'.
  added = obj_class + blank + cls;//组合原来的 class 和需要添加的 class.
  obj.className = added;//替换原来的 class.
}

function removeClass(obj, cls){
  var obj_class = ' '+obj.className+' ';//获取 class 内容, 并在首尾各加一个空格. ex) 'abc    bcd' -> ' abc    bcd '
  obj_class = obj_class.replace(/(\s+)/gi, ' '),//将多余的空字符替换成一个空格. ex) ' abc    bcd ' -> ' abc bcd '
  removed = obj_class.replace(' '+cls+' ', ' ');//在原来的 class 替换掉首尾加了空格的 class. ex) ' abc bcd ' -> 'bcd '
  removed = removed.replace(/(^\s+)|(\s+$)/g, '');//去掉首尾空格. ex) 'bcd ' -> 'bcd'
  obj.className = removed;//替换原来的 class.
}

function hasClass(obj, cls){
  var obj_class = obj.className,//获取 class 内容.
  obj_class_lst = obj_class.split(/\s+/);//通过split空字符将cls转换成数组.
  x = 0;
  for(x in obj_class_lst) {
    if(obj_class_lst[x] == cls) {//循环数组, 判断是否包含cls
      return true;
    }
  }
  return false;
}



var data1 =[ {
             "id" : "1",  
             "title": "1. 在【欢乐赞】做任务的必须满足哪些条件？（）",  
            
             "xuanxiang":[
             				"A.没有作品，默认头像，默认昵称",
             				"B.有一个作品，默认头像，默认昵称",
             				"C.有至少3个作品，有自己的头像，取了自己的昵称",
             				"D.没有作品，换了头像和昵称",
             				]
	
        },{  
             "id" : "2",  
             "title": "做评论任务】时，以下哪个评论扣信誉分？（）",  
            
             "xuanxiang":[
             				"A.跟风重复评论",
             				"B.666/真好/真棒/好厉害/好好吃/你好酷等",
             				"C.不走心敷衍了事的评论",
             				"D.高于10字的认真评论，自带笑梗或者被作者回复",
             				]
        },{  
             "id" : "3",  
             "title": "完成媒体任务时以下哪个行为不会扣信誉分？（）",  
            
             "xuanxiang":[
             				"A.报名任务后不做，等任务过期",
             				"B.报名之后占据名额但是不做任务",
             				"C.持续乱传图",
             				"D.确保自己做的任务按照要求正确做完后，却依然不通过时，在未通过页面提交正确截图点击【申请仲裁】",
             				]
        },{  
             "id" : "4",  
             "title": "个人单不通过时，应该如何保证自己的利益？（）",  
            
             "xuanxiang":[
             				"A.与发布者争执甚至捣乱",
             				"B.报名之后占据名额但是不做任务",
             				"C.持续乱传图",
             				"D.确保自己做的任务按照要求正确做完后，却依然不通过时，在未通过页面提交正确截图点击【申请仲裁】",
             				]
        },{  
             "id" : "5",  
             "title": "以下哪个不是敷衍评论？（）",  
             
             "xuanxiang":[
             				"A.哈哈哈哈，小姐姐真棒",
             				"B.哇，好美阿，好想去阿",
             				"C.小哥哥真厉害，666，嘻嘻嘻",
             				"D.根据视频内容自主评论高于10字的走心评论",
             				]
        }
        ];
        

