<?php

/**
 * data
 * @author auto create
 */
class Map
{
	
	/** 
	 * password
	 **/
	public $model;	
}
?>