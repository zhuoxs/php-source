<?php
global $_W, $_GPC;
		$page=$_GPC['page'];
		$cid=$_GPC['cid'];
		$uid=$_GPC['uid'];		

       
       include $this->template ( 'tbgoods/jd/jdyfg/jdyfggz' );
