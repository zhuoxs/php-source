<?php
 global $_W, $_GPC;
       $cfg = $this->module['config'];

       include $this->template ( 'tbgoods/style1/help' );
?>