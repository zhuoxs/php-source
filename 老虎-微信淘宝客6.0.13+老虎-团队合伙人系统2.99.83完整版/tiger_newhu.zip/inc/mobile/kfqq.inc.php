<?php
//http://cs.tigertaoke.com/app/index.php?i=14&c=entry&do=appdh&m=tiger_newhu&fztype=1
	//菜单//广告
global $_W, $_GPC;
		$cfg = $this->module['config'];
 include $this->template ( 'user/kfqq' );
?>