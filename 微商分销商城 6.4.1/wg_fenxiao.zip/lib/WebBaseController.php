<?php
 class WebBaseController extends BaseController { public function __construct() { parent::__construct(); } }