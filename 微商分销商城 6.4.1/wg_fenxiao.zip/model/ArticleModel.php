<?php

class ArticleModel extends BaseModel
{
    protected $table = 'wg_fenxiao_article';

}