<?php

class JifenModel extends BaseModel
{
    protected $table = 'wg_fenxiao_jifen_mingxi';

}