<?php

class CategoryModel extends BaseModel
{
    protected $table = 'wg_fenxiao_category';

}