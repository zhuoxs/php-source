<?php

class OrderDetailModel extends BaseModel
{
    protected $table = 'wg_fenxiao_order_detail';

}