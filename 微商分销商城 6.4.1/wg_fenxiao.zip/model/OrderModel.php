<?php

class OrderModel extends BaseModel
{
    protected $table = 'wg_fenxiao_order';

}