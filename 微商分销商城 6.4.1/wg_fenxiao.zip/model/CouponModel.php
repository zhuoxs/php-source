<?php

class CouponModel extends BaseModel
{
    protected $table = 'wg_fenxiao_getcard_ids';

}