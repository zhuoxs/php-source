<?php

class PosterQrModel extends BaseModel
{
    protected $table = 'wg_fenxiao_poster_qr';

    public function test()
    {
        echo 'this is test';
    }
}