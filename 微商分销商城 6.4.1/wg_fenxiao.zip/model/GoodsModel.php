<?php

class GoodsModel extends BaseModel
{
    protected $table = 'wg_fenxiao_goods';

}