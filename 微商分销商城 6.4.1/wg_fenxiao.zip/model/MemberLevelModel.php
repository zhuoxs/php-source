<?php

class MemberLevelModel extends BaseModel
{
    protected $table = 'wg_fenxiao_member_level';

}