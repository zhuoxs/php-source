<?php

class CollectModel extends BaseModel
{
    protected $table = 'wg_fenxiao_collect';

}