<?php

class PasswdsModel extends BaseModel
{
    protected $table = 'wg_fenxiao_passwds';

    public function test()
    {
        echo 'this is test';
    }
}