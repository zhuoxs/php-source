<?php

class GouModel extends BaseModel
{
    protected $table = 'wg_fenxiao_gou';

}