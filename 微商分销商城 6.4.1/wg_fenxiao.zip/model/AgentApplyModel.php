<?php

class AgentApplyModel extends BaseModel
{
    protected $table = 'wg_fenxiao_agent_apply';

}