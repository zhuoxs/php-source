<?php

class GoodsAttributeModel extends BaseModel
{
    protected $table = 'wg_fenxiao_goods_attribute';

}