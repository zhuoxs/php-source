<?php

class MemberAddressModel extends BaseModel
{
    protected $table = 'wg_fenxiao_member_address';

}