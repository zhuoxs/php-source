<?php

class MemberModel extends BaseModel
{
    protected $table = 'wg_fenxiao_member';

}