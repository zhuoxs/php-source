<?php

class ShoppingCartModel extends BaseModel
{
    protected $table = 'wg_fenxiao_shopping_cart';

}