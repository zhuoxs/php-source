<?php

class PosterModel extends BaseModel
{
    protected $table = 'wg_fenxiao_poster';

    public function test()
    {
        echo 'this is test';
    }
}