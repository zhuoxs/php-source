<?php

class GoodsTypeModel extends BaseModel
{
    protected $table = 'wg_fenxiao_goods_type';

}