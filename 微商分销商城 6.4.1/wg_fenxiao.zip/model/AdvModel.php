<?php

class AdvModel extends BaseModel
{
    protected $table = 'wg_fenxiao_adv';

    public function test()
    {
        echo 'this is test';
    }
}