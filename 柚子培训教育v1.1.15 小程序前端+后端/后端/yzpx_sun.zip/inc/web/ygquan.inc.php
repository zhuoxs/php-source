<?php
global $_GPC, $_W;
$GLOBALS['frames'] = $this->getMainMenu();


include $this->template('web/ygquan');