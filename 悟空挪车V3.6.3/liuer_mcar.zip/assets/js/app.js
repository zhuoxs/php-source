// 兼容Android 键盘弹起时，把确认订单弹窗顶上去影响布局
/*var h = document.body.scrollHeight  // 用onresize事件监控窗口或框架被调整大小，先把一开始的高度记录下来
window.onresize = function () { // 如果当前窗口小于一开始记录的窗口高度，那就让当前窗口等于一开始窗口的高度
    if (document.body.scrollHeight < h) {
        document.body.style.height = h
    }
}*/
