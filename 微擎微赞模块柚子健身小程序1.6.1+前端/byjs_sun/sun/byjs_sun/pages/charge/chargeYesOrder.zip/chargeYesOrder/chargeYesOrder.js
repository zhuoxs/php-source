
// byjs_sun/pages/charge/chargeYesOrder/chargeYesOrder.js
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    product: [
      {
       
      },
     
    ],
    totalPrice:'',
  onLoad: function (options) {
      var that = this
      // --------------------------获取url-----------------------
      app.util.request({
        'url': 'entry/wxapp/Url',
        'cachetime': '30',
        success: function (res) {
          // ---------------------------------- 异步保存网址前缀----------------------------------
          wx.setStorageSync('url', res.data)
          that.setData({
            url: res.data
          })
        },
      })
      var goods = wx.getStorageSync('new')
      console.log(goods+'dsadsada')
      var totalPrice = goods.money - goods.red
      
      goods = Array(goods)
      that.setData({
        product:goods,
        totalPrice:totalPrice
      })
      
      
  },

  /**
   * 我的收货地址
   */
  myAddress: function () {
    var that = this
    wx.chooseAddress({
      success: function (res) {
        that.setData({
          userName: res.userName,
          postalCode: res.postalCode,
          provinceName: res.provinceName,
          cityName: res.cityName,
          countyName: res.countyName,
          detailInfo: res.detailInfo,
          nationalCode: res.nationalCode,
          telNumber: res.telNumber
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  //自定义方法
  yesOrder: function(){
    var that = this 
    var goods = wx.getStorageSync('new')
    var user_id = wx.getStorageSync('users').id
    // *------自行添加
    // var info = wx.getStorageSync('info')

    //-----------付款---------------
    wx.getStorage({
      key: 'openid',
      success: function (res) {
        var openid = res.data;
        var price = that.data.totalPrice
        console.log(price)
        app.util.request({
          'url': 'entry/wxapp/Orderarr',
          'cachetime': '30',
          data: {
            price: price,
            openid: openid,
          },
          success: function (res) {
            var goods = wx.getStorageSync('new')
            var user_id = wx.getStorageSync('users').id
            console.log('-----直接购买=------')
            app.util.request({
              'url': 'entry/wxapp/Order',
              'cachetime': '0',
              data: {
                'user_id': user_id,
                'money': that.data.totalPrcie,
                'user_name': that.data.userName,
                'tel': that.data.telNumber,
                'good_id': goods.goods_id,
                'good_name': goods.goods_name,
                'good_img': goods.img,
                'good_money': goods.picer,
                'good_num': goods.productNumber,
                'address': that.data.provinceName + that.data.cityName + that.data.countyName + that.data.detailInfo
              },
              success: function (o) {
                console.log(o.data)
                var order_id = o.data;
                console.log(res)
                wx.requestPayment({
                  'timeStamp': res.data.timeStamp,
                  'nonceStr': res.data.nonceStr,
                  'package': res.data.package,
                  'signType': 'MD5',
                  'paySign': res.data.paySign,
                  'success': function (result) {
                    wx.showToast({
                      title: '支付成功',
                      icon: 'success',
                      duration: 2000
                    })
                    app.util.request({
                      'url': 'entry/wxapp/PayOrder',
                      'cachetime': '0',
                      data: {
                        order_id: order_id,
                      },
                      success: function (res) {
                        console.log(res)
                        wx.removeStorageSync('new')
                      }
                    })
                    wx.switchTab({
                      url: '../../index/index',
                    })
                   
                  },
                  'fail': function (result) {
                  }
                });
              }
            })

          }
        })
      },
    })



    
  },
  //去填写收货地址
  goAddress: function(){
    wx.navigateTo({
      url: '/byjs_sun/pages/charge/chargeAddressReceipt/chargeAddressReceipt',
    })
  }
  }
})
