<?php

goto AUX3O;
LbZmp:
goto tBRkM;
goto jxwgx;
OUVxX:
$data["viewnavbarzt"] ?: ($data["viewnavbarzt"] = "#ffffff");
goto y61pH;
g6CV8:
$data["rankdbzt"] ?: ($data["rankdbzt"] = "#ffffff");
goto KOvdo;
Qg76T:
$data["hdbt"] ?: ($data["hdbt"] = "#42b9fe");
goto RtOq5;
G7hrr:
$data["zjbtnbj"] ?: ($data["zjbtnbj"] = "#000000");
goto IXu1j;
ZBQpg:
$data["sybj1"] ?: ($data["sybj1"] = "#f5c9dd");
goto Fnmhz;
OaS5V:
$detail["zbzt"] ?: ($detail["zbzt"] = "#fc519e");
goto SU4LB;
NagDk:
$data["zjbt"] ?: ($data["zjbt"] = "#000000");
goto VC9Bi;
FFrdq:
bLJpt:
goto Qg76T;
zg65M:
$data["votebtnzt"] ?: ($data["votebtnzt"] = "#ffffff");
goto O6bCk;
b3S7o:
echo json_encode(array("code" => 0, "msg" => $rr["error"]));
goto Tt1Tv;
Xa23X:
$data["votebtnzt"] ?: ($data["votebtnzt"] = "#ffffff");
goto hwT0e;
XgEGZ:
if ($reply["htmlmode"] == 0) {
    goto wlTE3;
}
goto LN3P1;
sQoCT:
$data["jpjs"] ?: ($data["jpjs"] = "#000000");
goto NagDk;
AUX3O:
defined("IN_IA") or exit("Access Denied");
goto JM7BP;
n4YWm:
$detail["dbqyzt"] ?: ($detail["dbqyzt"] = "#000000");
goto zJyHh;
izFl1:
$data["hdbt"] ?: ($data["hdbt"] = "#42b9fe");
goto sQoCT;
Zk7BI:
echo json_encode(array("code" => 200, "msg" => "选择默认模板主题成功"));
goto hUOeo;
pJcn4:
goto UkGPf;
goto R8GpD;
HBQXE:
$post_data["token"] = md5(sha1(implode('', $post_data)));
goto IJXMs;
yrfIL:
$detail["tabzt"] ?: ($detail["tabzt"] = "#555555");
goto OvcUP;
VI6Ll:
$data["zjbtnzt"] ?: ($data["zjbtnzt"] = "#ffffff");
goto G7hrr;
hwT0e:
$data["votebtnbj"] ?: ($data["votebtnbj"] = "#ff75b3");
goto eXM7Y;
VMrDP:
$detail["ranknumzt"] ?: ($detail["ranknumzt"] = "#42b9fe");
goto yQewl;
qBlz2:
$data["jzgdbj"] ?: ($data["jzgdbj"] = "#ff75b3");
goto Dy38v;
Hx9Y0:
$data["zjbtbj"] = tomedia($data["zjbtbj"]);
goto y6Qi8;
pdLJh:
$data["searchbgbj"] = tomedia($data["searchbgbj"]);
goto Wv2pI;
Wv2pI:
$data["votebtnbj"] = tomedia($data["votebtnbj"]);
goto jV2o0;
TLktL:
$data["ybzt"] ?: ($data["ybzt"] = "#42b9fe");
goto tWTp1;
y6Qi8:
$data["viewxspstb"] = tomedia($data["viewxspstb"]);
goto E7Nnd;
aRyg2:
$rr = json_decode($content["content"], true);
goto lTVUs;
hbLa0:
gf227:
goto t0F8d;
gHhUJ:
echo json_encode(array("code" => 200, "msg" => "选择模板主题成功"));
goto tnqo7;
WhZTw:
$data["dbxfqyzt"] ?: ($data["dbxfqyzt"] = "#000000");
goto qVIco;
HH2Of:
$data["navbarzt"] ?: ($data["navbarzt"] = "#0F4196");
goto XG6RE;
FTdm5:
$detail["xsps"] ?: ($detail["xsps"] = "#ff75b3");
goto Mbe_U;
bJ4vk:
$data["searchzt"] ?: ($data["searchzt"] = "#ffffff");
goto jbUDP;
Renvk:
$data["sybj2"] ?: ($data["sybj2"] = "#a3d9f9");
goto wx83d;
YfebU:
$data["zjbtnbj"] ?: ($data["zjbtnbj"] = "#000000");
goto Pb4f0;
L0ma2:
goto Aiu6C;
goto PtNdE;
zJyHh:
$detail["dbxfxszt"] ?: ($detail["dbxfxszt"] = "#42b9fe");
goto npbQC;
iICrd:
$data["jpjsbj"] = tomedia($data["jpjsbj"]);
goto Hx9Y0;
MmjIL:
$data["dbxfqyzt"] ?: ($data["dbxfqyzt"] = "#000000");
goto VI6Ll;
dfrhe:
$data["viewnavbarbj"] ?: ($data["viewnavbarbj"] = "#42b9fe");
goto Iqa3k;
P3t1s:
$data["zjbtnbj"] ?: ($data["zjbtnbj"] = "#000000");
goto W5LQW;
nJN32:
$detail["navbarzt"] ?: ($detail["navbarzt"] = "#0F4196");
goto gMBr2;
MJXQA:
$url = $this->auth_url . "/index/votehtml/getHtmlModeDetail";
goto e1e1E;
dNZpm:
$data["tpbtnzt"] ?: ($data["tpbtnzt"] = "#ffffff");
goto xjSXZ;
v2cLj:
$rid = intval($_GPC["rid"]);
goto Htcde;
NERqk:
$data["dbxfxszt"] ?: ($data["dbxfxszt"] = "#42b9fe");
goto o52Ng;
Tt1Tv:
exit;
goto L0ma2;
oRJh9:
goto rv3Gs;
goto oSzJX;
W9WyG:
goto OiLoS;
goto Pa_Si;
wHk8k:
Kd2TN:
goto L3X3T;
oSzJX:
b1fH7:
goto F5061;
XB1q2:
Aiu6C:
goto LbZmp;
URtnG:
$data["jzgdbj"] ?: ($data["jzgdbj"] = "#ff75b3");
goto Qe5Ln;
lpIit:
$data["tabxzbj"] ?: ($data["tabxzbj"] = "#feff5d");
goto peh4t;
zCYZ0:
$rr = json_decode($content["content"], true);
goto ilbwa;
xjSXZ:
$data["tpbtnbj"] ?: ($data["tpbtnbj"] = "#ff75b3");
goto OUVxX;
t2Gke:
$yundetail = $rr["detail"];
goto Z5kf0;
ajMU1:
$data["sybj3"] ?: ($data["sybj3"] = "#f5f5f5");
goto bJ4vk;
IXu1j:
$data["zbzt"] ?: ($data["zbzt"] = "#fc519e");
goto lQdm3;
eXM7Y:
$data["jzgdzt"] ?: ($data["jzgdzt"] = "#ffffff");
goto URtnG;
Z5kf0:
$data = yun_localdetail($yundetail, $data);
goto XB1q2;
kECyI:
$data["ranknumzt"] ?: ($data["ranknumzt"] = "#42b9fe");
goto AK2qx;
nZGqJ:
$data["dbxfxszt"] ?: ($data["dbxfxszt"] = "#42b9fe");
goto WhZTw;
SiWLn:
KhsmZ:
goto eIF1A;
tWTp1:
$data["shszt"] ?: ($data["shszt"] = "#000000");
goto SoSlj;
EGKpd:
goto ogwia;
goto wHk8k;
SU4LB:
$detail["ybzt"] ?: ($detail["ybzt"] = "#42b9fe");
goto d7yim;
eIF1A:
ogwia:
goto TfYpd;
DOuYC:
$result = array();
goto T3VNg;
Pzy4G:
$data["ranktabbj"] ?: ($data["ranktabbj"] = "#666666");
goto m9Lsg;
wd3Vj:
$data["tabzt"] ?: ($data["tabzt"] = "#555555");
goto wK6S4;
FQCt6:
$detail["viewnavbarzt"] ?: ($detail["viewnavbarzt"] = "#ffffff");
goto eQYwm;
OvcUP:
$detail["tabbj"] ?: ($detail["tabbj"] = "#ffffff");
goto m42g4;
dao6M:
$data["tabxzbj"] = tomedia($data["tabxzbj"]);
goto SZ0_d;
Mbe_U:
$detail["votebtnzt"] ?: ($detail["votebtnzt"] = "#ffffff");
goto sEqiv;
NZZs1:
if ($reply["htmlmode"] == 2) {
    goto EI3AE;
}
goto ZwYLH;
sEsr6:
exit;
goto IKFdv;
T88I7:
$data["navbarxzbj"] ?: ($data["navbarxzbj"] = "#FF75B3");
goto D9n8z;
TBrNx:
$data["dbxszt"] ?: ($data["dbxszt"] = "#fc519e");
goto smfeO;
tBnjj:
$detail["csjlzt"] ?: ($detail["csjlzt"] = "#999999");
goto Guw17;
O6bCk:
$data["votebtnbj"] ?: ($data["votebtnbj"] = "#ff75b3");
goto Kj179;
DcwBQ:
$data["dbxfxszt"] ?: ($data["dbxfxszt"] = "#42b9fe");
goto MmjIL;
X_iBI:
$result = json_decode($content["content"], true);
goto qJMym;
Cx8a0:
if ($operation == "chosemode") {
    goto qywMA;
}
goto kojiq;
puhvM:
$data["sybj1"] ?: ($data["sybj1"] = "#f5c9dd");
goto T8Ap7;
M3Pht:
$content = ihttp_post($url, array("htmlmode" => $reply["htmlmode"]));
goto iFw3V;
AgsuB:
$data["dbbt"] ?: ($data["dbbt"] = "#fff100");
goto TBrNx;
BupJJ:
$mode = $_GPC["mode"];
goto t412V;
Dy38v:
$data["navbarbj"] ?: ($data["navbarbj"] = "#FEFF5D");
goto Lcvho;
JM7BP:
global $_W, $_GPC;
goto jul7z;
e1e1E:
load()->func("communication");
goto X64Pc;
IZskT:
$data["tpbtnzt"] ?: ($data["tpbtnzt"] = "#ffffff");
goto fYzXW;
qVIco:
$data["zjbtnzt"] ?: ($data["zjbtnzt"] = "#ffffff");
goto P3t1s;
wx83d:
$data["sybj3"] ?: ($data["sybj3"] = "#f5f5f5");
goto JdEnz;
fJOmo:
$data["csjlzt"] ?: ($data["csjlzt"] = "#999999");
goto swxAd;
esNnh:
$data["viewxspstb"] = tomedia($data["viewxspstb"]);
goto kkrzt;
IRIRF:
pdo_update($this->modulename . "_reply", array("htmlmode" => $html_id), array("rid" => $rid, "uniacid" => $uniacid));
goto Zk7BI;
I3C87:
$detail["jzgdzt"] ?: ($detail["jzgdzt"] = "#ffffff");
goto o7geg;
EWOOu:
$data["votebtnbj"] ?: ($data["votebtnbj"] = "#ff75b3");
goto Lffy2;
zGqx8:
$detail["ranktabbj"] ?: ($detail["ranktabbj"] = "#666666");
goto it0sR;
vQwzM:
if ($reply["htmlmode"] == 0) {
    goto ZDg2w;
}
goto ukkQP;
IJXMs:
load()->func("communication");
goto ox2LD;
bmWp2:
$content = ihttp_post($url, array("htmlmode" => $reply["htmlmode"]));
goto aRyg2;
Vk15B:
$data["rankps"] ?: ($data["rankps"] = "#555555");
goto pgBV5;
F5061:
$yundetail = $rr["detail"];
goto i1W1Z;
swxAd:
$data["giftzt"] ?: ($data["giftzt"] = "#666666");
goto dNZpm;
ot52G:
$detail["jpjs"] ?: ($detail["jpjs"] = "#000000");
goto GbmKr;
fzIiH:
exit;
goto EGKpd;
muWd3:
$data["dbqyzt"] ?: ($data["dbqyzt"] = "#000000");
goto nZGqJ;
y0COi:
WIKdw:
goto FTVKw;
SoSlj:
$data["shsps"] ?: ($data["shsps"] = "#fc519e");
goto fJOmo;
R8GpD:
VvN1k:
goto t1mdD;
zHBVS:
$uniacid = !empty($_W["uniacid"]) ? $_W["uniacid"] : intval($_GET["uniacid"]);
goto WHmrK;
MXFpV:
v2Zae:
goto Bv_Mq;
U74rd:
$detail["sybj3"] ?: ($detail["sybj3"] = "#f5f5f5");
goto MkYwL;
VC9Bi:
$data["btfsz"] ?: ($data["btfsz"] = "#ffffff");
goto K7mFJ;
pgBV5:
yY41H:
goto ifk7Y;
FTVKw:
$yundetail = $rr["detail"];
goto NtxIm;
Iqa3k:
$data["rankdbzt"] ?: ($data["rankdbzt"] = "#ffffff");
goto EXjzN;
Htcde:
$reply = pdo_fetch("select * from " . tablename($this->modulename . "_reply") . " where rid = {$rid} and uniacid = {$uniacid}");
goto r42ob;
rdCcG:
$info["detailset"] = serialize($data);
goto q2tiN;
Cr3Fb:
message($rr["error"], referer(), "error");
goto cWBKk;
FX3ou:
$data["votebtnbj"] = tomedia($data["votebtnbj"]);
goto BN_dE;
DJIIQ:
echo json_encode(array("code" => 500, "msg" => $rr["error"]));
goto oRJh9;
jV2o0:
$data["wybmbtnbj"] = tomedia($data["wybmbtnbj"]);
goto iICrd;
be5Te:
$detail["navbarbj"] ?: ($detail["navbarbj"] = "#FEFF5D");
goto nJN32;
DnJQs:
$data["rankdbbj"] ?: ($data["rankdbbj"] = "#42b9fe");
goto AtZcn;
Tvdap:
$detail["shsps"] ?: ($detail["shsps"] = "#fc519e");
goto tBnjj;
rAilb:
$detail["tpbtnbj"] ?: ($detail["tpbtnbj"] = "#ff75b3");
goto FQCt6;
eV52I:
ksort($post_data);
goto HBQXE;
XCY5G:
$data["rankdbzt"] ?: ($data["rankdbzt"] = "#ffffff");
goto DnJQs;
LE_a3:
$data["dbbt"] ?: ($data["dbbt"] = "#fff100");
goto MYdaR;
ueBtw:
$detail["xsmc"] ?: ($detail["xsmc"] = "#42b9fe");
goto FTdm5;
Seuss:
$data["shsps"] ?: ($data["shsps"] = "#fc519e");
goto Zzs2i;
hufXN:
$detail["rankps"] ?: ($detail["rankps"] = "#555555");
goto n2wkF;
MYdaR:
$data["dbxszt"] ?: ($data["dbxszt"] = "#fc519e");
goto SOyQo;
cWBKk:
goto bzeX7;
goto y0COi;
UwxY1:
$data["rankps"] ?: ($data["rankps"] = "#555555");
goto gWVay;
wT9le:
$detail["dbxszt"] ?: ($detail["dbxszt"] = "#fc519e");
goto n4YWm;
ELAHD:
$data["xsps"] ?: ($data["xsps"] = "#ff75b3");
goto Xa23X;
jbUDP:
$data["searchbj"] ?: ($data["searchbj"] = "#ff75b3");
goto twKnf;
Pb4f0:
$data["zbzt"] ?: ($data["zbzt"] = "#fc519e");
goto tF2vr;
MkYwL:
$detail["searchzt"] ?: ($detail["searchzt"] = "#ffffff");
goto b08Tn;
PtNdE:
XIFtW:
goto t2Gke;
npbQC:
$detail["dbxfqyzt"] ?: ($detail["dbxfqyzt"] = "#000000");
goto hWK00;
QRqcW:
$data["xsmc"] ?: ($data["xsmc"] = "#42b9fe");
goto ELAHD;
fO2tC:
$data["ranktabzt"] ?: ($data["ranktabzt"] = "#666666");
goto W8B8t;
W8B8t:
$data["ranktabbj"] ?: ($data["ranktabbj"] = "#666666");
goto SxbIx;
eQYwm:
$detail["viewnavbarbj"] ?: ($detail["viewnavbarbj"] = "#42b9fe");
goto wZijF;
JnJXe:
$data["ranktabbj"] ?: ($data["ranktabbj"] = "#666666");
goto FjdPV;
Qe5Ln:
$data["navbarbj"] ?: ($data["navbarbj"] = "#FEFF5D");
goto O74kh;
jul7z:
checklogin();
goto uJe8_;
Fnmhz:
$data["sybj2"] ?: ($data["sybj2"] = "#a3d9f9");
goto Ns3lM;
H90U2:
$yundetail = $rr["detail"];
goto U_49N;
mcgqO:
$data["giftzt"] ?: ($data["giftzt"] = "#666666");
goto IZskT;
uJe8_:
$cfg = $this->module["config"];
goto nf8tJ;
E7Nnd:
$data["tpbtnbj"] = tomedia($data["tpbtnbj"]);
goto ljtog;
lTVUs:
if ($rr["sta"] == 200) {
    goto XIFtW;
}
goto b3S7o;
bhNEw:
goto yY41H;
goto FFrdq;
O7Vcu:
$data["navbarbj"] ?: ($data["navbarbj"] = "#FEFF5D");
goto HH2Of;
niPnJ:
$data["ranknumzt"] ?: ($data["ranknumzt"] = "#42b9fe");
goto zPUqz;
Pvi36:
$data["searchzt"] ?: ($data["searchzt"] = "#ffffff");
goto gxGIh;
n73mr:
pdo_update($this->modulename . "_reply", $info, array("rid" => $rid, "uniacid" => $uniacid));
goto RZQcS;
iFw3V:
$rr = json_decode($content["content"], true);
goto vpREe;
L3X3T:
$rid = $_GPC["rid"];
goto Qe2vx;
siGkN:
rv3Gs:
goto bhNEw;
K7mFJ:
$data["btfzt"] ?: ($data["btfzt"] = "#ffffff");
goto puhvM;
Y2jKS:
if ($html_id == 0) {
    goto uyFnF;
}
goto YvjIw;
g70r7:
$data["shsps"] ?: ($data["shsps"] = "#fc519e");
goto gtcqm;
qEjmP:
$content = ihttp_post($url, array("ticket" => $this->module["config"]["ticket"]));
goto XRu60;
N0fTY:
$data["btfzt"] ?: ($data["btfzt"] = "#ffffff");
goto ZBQpg;
it0sR:
$detail["ranktabxzbj"] ?: ($detail["ranktabxzbj"] = "#42b9fe");
goto VMrDP;
yQewl:
$detail["rankxszt"] ?: ($detail["rankxszt"] = "#555555");
goto hufXN;
XG6RE:
$data["navbarxzbj"] ?: ($data["navbarxzbj"] = "#FF75B3");
goto LE_a3;
X64Pc:
$content = ihttp_post($url, array("htmlmode" => $reply["htmlmode"]));
goto sE4iY;
wK6S4:
$data["tabbj"] ?: ($data["tabbj"] = "#ffffff");
goto LDvac;
nf8tJ:
$url = $this->auth_url . "/index/vote/checkauth";
goto HzXvG;
mG8a_:
$operation = !empty($_GPC["op"]) ? $_GPC["op"] : "display";
goto zHBVS;
tnqo7:
exit;
goto L9F1h;
LN3P1:
if ($reply["htmlmode"] != 0) {
    goto f16MP;
}
goto s9gkp;
T8Ap7:
$data["sybj2"] ?: ($data["sybj2"] = "#a3d9f9");
goto ajMU1;
JdEnz:
$data["searchzt"] ?: ($data["searchzt"] = "#ffffff");
goto u_QO6;
AK2qx:
$data["rankxszt"] ?: ($data["rankxszt"] = "#555555");
goto UwxY1;
s9gkp:
goto v2Zae;
goto p7Bee;
W5wz8:
$detail["btfzt"] ?: ($detail["btfzt"] = "#ffffff");
goto d4hGO;
pXsb0:
$data["tabbj"] = tomedia($data["tabbj"]);
goto dao6M;
zPUqz:
$data["rankxszt"] ?: ($data["rankxszt"] = "#555555");
goto Vk15B;
Pm30u:
$reply = pdo_fetch("select * from " . tablename($this->modulename . "_reply") . " where rid = {$rid} and uniacid = {$uniacid}");
goto pHKrL;
RZQcS:
//message("网页细节设置成功！", referer(), "success");
goto f0bQN;
qJvRd:
$detail["ranktabzt"] ?: ($detail["ranktabzt"] = "#666666");
goto zGqx8;
hUOeo:
exit;
goto SiWLn;
LDvac:
$data["tabxzbj"] ?: ($data["tabxzbj"] = "#feff5d");
goto km7co;
o52Ng:
$data["dbxfqyzt"] ?: ($data["dbxfqyzt"] = "#000000");
goto K4taS;
fYzXW:
$data["tpbtnbj"] ?: ($data["tpbtnbj"] = "#ff75b3");
goto G0V5O;
G0V5O:
$data["viewnavbarzt"] ?: ($data["viewnavbarzt"] = "#ffffff");
goto dfrhe;
w6Yi9:
f2snt:
goto v2cLj;
O74kh:
$data["navbarzt"] ?: ($data["navbarzt"] = "#0F4196");
goto Szxey;
r42ob:
$url = $this->auth_url . "/index/votehtml/getHtmlModeAccess";
goto mcop6;
gWVay:
tBRkM:
goto rdCcG;
p7Bee:
wlTE3:
goto j32Dn;
u0069:
$detail["sybj2"] ?: ($detail["sybj2"] = "#a3d9f9");
goto U74rd;
ZwYLH:
goto OiLoS;
goto hbLa0;
kbnVZ:
load()->func("communication");
goto OfFND;
kFr6W:
$data["votebtnzt"] ?: ($data["votebtnzt"] = "#ffffff");
goto EWOOu;
j32Dn:
$detail["hdbt"] ?: ($detail["hdbt"] = "#42b9fe");
goto ot52G;
v8_1e:
message("授权错误，请联系客服！", "referer", "error");
goto pJcn4;
RqB7g:
$rid = $_GPC["rid"];
goto Vn5Aw;
SZ0_d:
$data["xspstb"] = tomedia($data["xspstb"]);
goto FX3ou;
OpUde:
uyFnF:
goto IRIRF;
hkTlH:
$data["xsps"] ?: ($data["xsps"] = "#ff75b3");
goto kFr6W;
T3VNg:
Ku_Ro:
goto dahcW;
DEEEn:
$detail["dbbt"] ?: ($detail["dbbt"] = "#fff100");
goto wT9le;
AtZcn:
$data["ranktabzt"] ?: ($data["ranktabzt"] = "#666666");
goto Pzy4G;
kojiq:
goto ogwia;
goto w6Yi9;
peh4t:
$data["xsmc"] ?: ($data["xsmc"] = "#42b9fe");
goto HAYya;
i1W1Z:
$data = yun_localdetail($yundetail, $data);
goto siGkN;
twKnf:
$data["tabzt"] ?: ($data["tabzt"] = "#555555");
goto fZWxl;
GzSQ8:
echo json_encode(array("code" => 200));
goto sEsr6;
ilbwa:
if ($rr["sta"] == 200) {
    goto b1fH7;
}
goto DJIIQ;
W5LQW:
$data["zbzt"] ?: ($data["zbzt"] = "#fc519e");
goto TLktL;
pqYVt:
$info["detailset"] = serialize($data);
goto n73mr;
ATkK9:
$detail["btfsz"] ?: ($detail["btfsz"] = "#ffffff");
goto W5wz8;
K4taS:
$data["zjbtnzt"] ?: ($data["zjbtnzt"] = "#ffffff");
goto YfebU;
NtxIm:
if ($reply["htmlmode"] == 1) {
    goto gf227;
}
goto NZZs1;
m9Lsg:
$data["ranktabxzbj"] ?: ($data["ranktabxzbj"] = "#42b9fe");
goto wabhl;
IKFdv:
goto ogwia;
goto KIJdr;
a_DN6:
$detail["tpbtnzt"] ?: ($detail["tpbtnzt"] = "#ffffff");
goto rAilb;
jxwgx:
ZDg2w:
goto Def0j;
HzXvG:
$post_data = array("time" => time(), "ticket" => $cfg["ticket"], "module_id" => 3);
goto eV52I;
Ns3lM:
$data["sybj3"] ?: ($data["sybj3"] = "#f5f5f5");
goto Pvi36;
ukkQP:
$url = $this->auth_url . "/index/votehtml/getHtmlModeDetail";
goto o_olf;
K_B1x:
$data["shszt"] ?: ($data["shszt"] = "#000000");
goto g70r7;
Qe2vx:
$data = $_GPC["data"];
goto Pm30u;
GHyIg:
$data["searchtextbj"] = tomedia($data["searchtextbj"]);
goto pXsb0;
VNnl1:
if ($operation == "post") {
    goto Kd2TN;
}
goto kPJ9A;
aTP6o:
$html_id = $mode;
goto J1nYA;
hWK00:
$detail["zjbtnzt"] ?: ($detail["zjbtnzt"] = "#ffffff");
goto wQSJy;
o_olf:
load()->func("communication");
goto bmWp2;
gMBr2:
$detail["navbarxzbj"] ?: ($detail["navbarxzbj"] = "#FF75B3");
goto DEEEn;
XRu60:
$result = json_decode($content["content"], true);
goto a93Bz;
Lcvho:
$data["navbarzt"] ?: ($data["navbarzt"] = "#0F4196");
goto T88I7;
Lffy2:
$data["jzgdzt"] ?: ($data["jzgdzt"] = "#ffffff");
goto qBlz2;
GbmKr:
$detail["zjbt"] ?: ($detail["zjbt"] = "#000000");
goto ATkK9;
lQdm3:
$data["ybzt"] ?: ($data["ybzt"] = "#42b9fe");
goto K_B1x;
WHmrK:
if ($operation == "display") {
    goto f2snt;
}
goto VNnl1;
U_49N:
$detail = yun_localdetail($yundetail, $detail);
goto a1EzB;
RtOq5:
$data["jpjs"] ?: ($data["jpjs"] = "#000000");
goto awa6V;
f0bQN:
goto ogwia;
goto bO3i_;
B3gK7:
$data["tpbtnzt"] ?: ($data["tpbtnzt"] = "#ffffff");
goto OES3N;
cQ2Pz:
$data["btfsz"] ?: ($data["btfsz"] = "#ffffff");
goto q24Dz;
kPJ9A:
if ($operation == "hfmr") {
    goto IyOVW;
}
goto Cx8a0;
bO3i_:
IyOVW:
goto RqB7g;
sEqiv:
$detail["votebtnbj"] ?: ($detail["votebtnbj"] = "#ff75b3");
goto I3C87;
kkSQA:
OE2KO:
goto izFl1;
OES3N:
$data["tpbtnbj"] ?: ($data["tpbtnbj"] = "#ff75b3");
goto PMOKC;
mcop6:
load()->func("communication");
goto qEjmP;
wabhl:
$data["ranknumzt"] ?: ($data["ranknumzt"] = "#42b9fe");
goto DV1k8;
smfeO:
$data["dbqyzt"] ?: ($data["dbqyzt"] = "#000000");
goto DcwBQ;
Yxv73:
$data["jzgdbj"] ?: ($data["jzgdbj"] = "#ff75b3");
goto O7Vcu;
wQSJy:
$detail["zjbtnbj"] ?: ($detail["zjbtnbj"] = "#000000");
goto OaS5V;
TyeHp:
$rid = $_GPC["rid"];
goto aTP6o;
SgJks:
$data = yun_localdetail($yundetail, $data);
goto sjFII;
n2wkF:
goto v2Zae;
goto ntbJS;
fxeGI:
$url = $this->auth_url . "/index/votehtml/getHtmlModeDetail";
goto UVjZ6;
SOyQo:
$data["dbqyzt"] ?: ($data["dbqyzt"] = "#000000");
goto NERqk;
G0oX6:
XoqJ6:
goto pqYVt;
Ck_9i:
$data["tabbj"] ?: ($data["tabbj"] = "#ffffff");
goto rqjQX;
KIJdr:
qywMA:
goto BupJJ;
L9F1h:
goto KhsmZ;
goto OpUde;
AUyw6:
$reply["config"] = @unserialize($reply["config"]);
goto y5t2v;
vpREe:
if (!($rr["sta"] == 200)) {
    goto a12dX;
}
goto H90U2;
YvjIw:
pdo_update($this->modulename . "_reply", array("htmlmode" => $html_id), array("rid" => $rid, "uniacid" => $uniacid));
goto gHhUJ;
YXEup:
$data["sybj1"] ?: ($data["sybj1"] = "#f5c9dd");
goto Renvk;
bPn1k:
$data["viewnavbarbj"] ?: ($data["viewnavbarbj"] = "#42b9fe");
goto XCY5G;
d7yim:
$detail["shszt"] ?: ($detail["shszt"] = "#000000");
goto Tvdap;
m42g4:
$detail["tabxzbj"] ?: ($detail["tabxzbj"] = "#feff5d");
goto ueBtw;
rqjQX:
$data["tabxzbj"] ?: ($data["tabxzbj"] = "#feff5d");
goto QRqcW;
Fkekn:
$data["zjbtbj"] = tomedia($data["zjbtbj"]);
goto esNnh;
ntbJS:
f16MP:
goto fxeGI;
uosGa:
pdo_update($this->modulename . "_reply", $info, array("rid" => $rid, "uniacid" => $uniacid));
goto Y2jKS;
sE4iY:
$rr = json_decode($content["content"], true);
goto lJWqr;
HAYya:
$data["xsps"] ?: ($data["xsps"] = "#ff75b3");
goto zg65M;
wZijF:
$detail["rankdbzt"] ?: ($detail["rankdbzt"] = "#ffffff");
goto Drf87;
reQHW:
$data["shszt"] ?: ($data["shszt"] = "#000000");
goto Seuss;
Sx3zD:
$reply = pdo_fetch("select * from " . tablename($this->modulename . "_reply") . " where rid = {$rid} and uniacid = {$uniacid}");
goto vQwzM;
u_QO6:
$data["searchbj"] ?: ($data["searchbj"] = "#ff75b3");
goto XXF1g;
BN_dE:
$data["jpjsbj"] = tomedia($data["jpjsbj"]);
goto Fkekn;
EXjzN:
$data["rankdbbj"] ?: ($data["rankdbbj"] = "#42b9fe");
goto T5TUG;
Pa_Si:
EI3AE:
goto pdLJh;
sjFII:
bzeX7:
goto y0Xy4;
b08Tn:
$detail["searchbj"] ?: ($detail["searchbj"] = "#ff75b3");
goto yrfIL;
lEMF7:
load()->func("tpl");
goto BDjx9;
tF2vr:
$data["ybzt"] ?: ($data["ybzt"] = "#42b9fe");
goto reQHW;
gtcqm:
$data["csjlzt"] ?: ($data["csjlzt"] = "#999999");
goto mcgqO;
U7YVT:
$data["jpjs"] ?: ($data["jpjs"] = "#000000");
goto k7D9k;
a1EzB:
a12dX:
goto MXFpV;
T5TUG:
$data["ranktabzt"] ?: ($data["ranktabzt"] = "#666666");
goto JnJXe;
SxbIx:
$data["ranktabxzbj"] ?: ($data["ranktabxzbj"] = "#42b9fe");
goto kECyI;
Def0j:
$data["hdbt"] ?: ($data["hdbt"] = "#42b9fe");
goto U7YVT;
Szxey:
$data["navbarxzbj"] ?: ($data["navbarxzbj"] = "#FF75B3");
goto AgsuB;
q2tiN:
pdo_update($this->modulename . "_reply", $info, array("rid" => $rid, "uniacid" => $uniacid));
goto GzSQ8;
Vn5Aw:
$data = $_GPC["data"];
goto Sx3zD;
dahcW:
$detail = unserialize($reply["detailset"]);
goto XgEGZ;
gxGIh:
$data["searchbj"] ?: ($data["searchbj"] = "#ff75b3");
goto wd3Vj;
XXF1g:
$data["tabzt"] ?: ($data["tabzt"] = "#555555");
goto Ck_9i;
Guw17:
$detail["giftzt"] ?: ($detail["giftzt"] = "#666666");
goto a_DN6;
J1nYA:
if ($html_id == 0) {
    goto bLJpt;
}
goto qQyNE;
q24Dz:
$data["btfzt"] ?: ($data["btfzt"] = "#ffffff");
goto YXEup;
fZWxl:
$data["tabbj"] ?: ($data["tabbj"] = "#ffffff");
goto lpIit;
y5t2v:
include $this->template("detail_set");
goto fzIiH;
qJMym:
if ($result["sta"]) {
    goto VvN1k;
}
goto v8_1e;
PMOKC:
$data["viewnavbarzt"] ?: ($data["viewnavbarzt"] = "#ffffff");
goto bPn1k;
t412V:
$rid = intval($_GPC["rid"]);
goto TyeHp;
d4hGO:
$detail["sybj1"] ?: ($detail["sybj1"] = "#f5c9dd");
goto u0069;
km7co:
$data["xsmc"] ?: ($data["xsmc"] = "#42b9fe");
goto hkTlH;
ox2LD:
$content = ihttp_post($url, $post_data);
goto X_iBI;
syg1N:
$data["giftzt"] ?: ($data["giftzt"] = "#666666");
goto B3gK7;
Bv_Mq:
$reply = pdo_fetch("SELECT * FROM " . tablename($this->tablereply) . " WHERE rid = :rid ORDER BY `id` DESC", array(":rid" => $_GPC["rid"]));
goto AUyw6;
Kj179:
$data["jzgdzt"] ?: ($data["jzgdzt"] = "#ffffff");
goto Yxv73;
sLgvP:
$data["rankps"] ?: ($data["rankps"] = "#555555");
goto G0oX6;
D9n8z:
$data["dbbt"] ?: ($data["dbbt"] = "#fff100");
goto mDwkJ;
KOvdo:
$data["rankdbbj"] ?: ($data["rankdbbj"] = "#42b9fe");
goto fO2tC;
y0Xy4:
goto XoqJ6;
goto kkSQA;
ljtog:
OiLoS:
goto SgJks;
UVjZ6:
load()->func("communication");
goto M3Pht;
OfFND:
$content = ihttp_post($url, array("htmlmode" => $html_id));
goto zCYZ0;
qQyNE:
$url = $this->auth_url . "/index/votehtml/getHtmlModeDetail";
goto kbnVZ;
Zzs2i:
$data["csjlzt"] ?: ($data["csjlzt"] = "#999999");
goto syg1N;
FjdPV:
$data["ranktabxzbj"] ?: ($data["ranktabxzbj"] = "#42b9fe");
goto niPnJ;
t1mdD:
UkGPf:
goto lEMF7;
Drf87:
$detail["rankdbbj"] ?: ($detail["rankdbbj"] = "#42b9fe");
goto qJvRd;
mDwkJ:
$data["dbxszt"] ?: ($data["dbxszt"] = "#fc519e");
goto muWd3;
awa6V:
$data["zjbt"] ?: ($data["zjbt"] = "#000000");
goto cQ2Pz;
DV1k8:
$data["rankxszt"] ?: ($data["rankxszt"] = "#555555");
goto sLgvP;
pHKrL:
if ($reply["htmlmode"] == 0) {
    goto OE2KO;
}
goto MJXQA;
y61pH:
$data["viewnavbarbj"] ?: ($data["viewnavbarbj"] = "#42b9fe");
goto g6CV8;
a93Bz:
if (!$result["error"]) {
    goto Ku_Ro;
}
goto DOuYC;
k7D9k:
$data["zjbt"] ?: ($data["zjbt"] = "#000000");
goto LV8L5;
BDjx9:
$_W["page"]["title"] = "模板主题管理";
goto mG8a_;
t0F8d:
$data["searchbj"] = tomedia($data["searchbj"]);
goto GHyIg;
ifk7Y:
$info["detailset"] = serialize($data);
goto uosGa;
kkrzt:
$data["tpbtnbj"] = tomedia($data["tpbtnbj"]);
goto W9WyG;
LV8L5:
$data["btfsz"] ?: ($data["btfsz"] = "#ffffff");
goto N0fTY;
o7geg:
$detail["jzgdbj"] ?: ($detail["jzgdbj"] = "#ff75b3");
goto be5Te;
lJWqr:
if ($rr["sta"] == 200) {
    goto WIKdw;
}
goto Cr3Fb;
TfYpd:
function yun_localdetail($yun, $local)
{
    goto BLR9f;
    S9oCd:
    $local["ranknumzt"] ?: ($local["ranknumzt"] = $yun["ranknumzt"]);
    goto XNfUb;
    dyEHP:
    $local["navbarztz"] ?: ($local["navbarztz"] = $yun["navbarztz"]);
    goto fBvHm;
    T3cCt:
    $local["zjbtnbj"] ?: ($local["zjbtnbj"] = $yun["zjbtnbj"]);
    goto nuXN1;
    wOwMm:
    $local["navbarbj"] ?: ($local["navbarbj"] = $yun["navbarbj"]);
    goto z1lk7;
    F67IY:
    $local["viewnavbarzt"] ?: ($local["viewnavbarzt"] = $yun["viewnavbarzt"]);
    goto uLkOu;
    fBvHm:
    $local["navbarzty"] ?: ($local["navbarzty"] = $yun["navbarzty"]);
    goto Vjgir;
    ml1xm:
    $local["votebtnbj"] ?: ($local["votebtnbj"] = $yun["votebtnbj"]);
    goto uGgX7;
    JxNzk:
    $local["navbarbjy"] ?: ($local["navbarbjy"] = $yun["navbarbjy"]);
    goto W9exC;
    ymGmx:
    $local["xsmc"] ?: ($local["xsmc"] = $yun["xsmc"]);
    goto FBm41;
    JkpXT:
    $local["xsbhbj"] ?: ($local["xsbhbj"] = $yun["xsbhbj"]);
    goto n93eF;
    l4Aql:
    $local["ranktabbj"] ?: ($local["ranktabbj"] = $yun["ranktabbj"]);
    goto LbqJu;
    uksht:
    $local["jpjs"] ?: ($local["jpjs"] = $yun["jpjs"]);
    goto vWOS7;
    OywZ3:
    $local["rankps"] ?: ($local["rankps"] = $yun["rankps"]);
    goto u8Hyz;
    LbqJu:
    $local["ranktabxzbj"] ?: ($local["ranktabxzbj"] = $yun["ranktabxzbj"]);
    goto S9oCd;
    uLkOu:
    $local["viewnavbarbj"] ?: ($local["viewnavbarbj"] = $yun["viewnavbarbj"]);
    goto Z0jWy;
    XxXkt:
    $local["wybmbtnzt"] ?: ($local["wybmbtnzt"] = $yun["wybmbtnzt"]);
    goto b0TOQ;
    HymWy:
    $local["tpbtnbj"] ?: ($local["tpbtnbj"] = $yun["tpbtnbj"]);
    goto F67IY;
    fw146:
    $local["zjbtbj"] ?: ($local["zjbtbj"] = $yun["zjbtbj"]);
    goto L0CEA;
    GABzx:
    $local["shszt"] ?: ($local["shszt"] = $yun["shszt"]);
    goto wzUKE;
    aZm1D:
    $local["viewxszc"] ?: ($local["viewxszc"] = $yun["viewxszc"]);
    goto VY6Sp;
    g3ahN:
    return $local;
    goto td180;
    FhjZr:
    $local["viewxsxm"] ?: ($local["viewxsxm"] = $yun["viewxsxm"]);
    goto aZm1D;
    QesAP:
    $local["xsbhzt"] ?: ($local["xsbhzt"] = $yun["xsbhzt"]);
    goto JkpXT;
    u8Hyz:
    $local["searchtextzt"] ?: ($local["searchtextzt"] = $yun["searchtextzt"]);
    goto nVweq;
    GXvgB:
    $local["jzgdbj"] ?: ($local["jzgdbj"] = $yun["jzgdbj"]);
    goto wOwMm;
    FBm41:
    $local["xsps"] ?: ($local["xsps"] = $yun["xsps"]);
    goto JtN8c;
    nuXN1:
    $local["zjbtnzt"] ?: ($local["zjbtnzt"] = $yun["zjbtnzt"]);
    goto thR7U;
    kQ8_2:
    $local["yqmcs"] ?: ($local["yqmcs"] = $yun["yqmcs"]);
    goto XxXkt;
    W7nzY:
    $local["dbbt"] ?: ($local["dbbt"] = $yun["dbbt"]);
    goto KxA_y;
    a1tRx:
    $local["xspstb"] ?: ($local["xspstb"] = $yun["xspstb"]);
    goto OcJI8;
    FNftW:
    $local["zjbtbjys"] ?: ($local["zjbtbjys"] = $yun["zjbtbjys"]);
    goto JYIeK;
    AClAv:
    $local["sybj1"] ?: ($local["sybj1"] = $yun["sybj1"]);
    goto w91dt;
    r5SR4:
    $local["rankdbbj"] ?: ($local["rankdbbj"] = $yun["rankdbbj"]);
    goto KritK;
    KxA_y:
    $local["dbxszt"] ?: ($local["dbxszt"] = $yun["dbxszt"]);
    goto iSODJ;
    DcxhA:
    $local["navbarbjz"] ?: ($local["navbarbjz"] = $yun["navbarbjz"]);
    goto JxNzk;
    XNfUb:
    $local["rankxszt"] ?: ($local["rankxszt"] = $yun["rankxszt"]);
    goto OywZ3;
    kKUvw:
    $local["viewxspm"] ?: ($local["viewxspm"] = $yun["viewxspm"]);
    goto m_mJH;
    h3NM2:
    $local["dbxfqyzt"] ?: ($local["dbxfqyzt"] = $yun["dbxfqyzt"]);
    goto T3cCt;
    GPuRE:
    $local["searchbj"] ?: ($local["searchbj"] = $yun["searchbj"]);
    goto tUF8v;
    GRDTz:
    $local["btfsz"] ?: ($local["btfsz"] = $yun["btfsz"]);
    goto DzKJi;
    VWYF7:
    $local["tpbtnzt"] ?: ($local["tpbtnzt"] = $yun["tpbtnzt"]);
    goto HymWy;
    VYFzZ:
    $local["tabxzzt"] ?: ($local["tabxzzt"] = $yun["tabxzzt"]);
    goto a1tRx;
    w91dt:
    $local["sybj2"] ?: ($local["sybj2"] = $yun["sybj2"]);
    goto SLGA1;
    KritK:
    $local["ranktabzt"] ?: ($local["ranktabzt"] = $yun["ranktabzt"]);
    goto l4Aql;
    wzUKE:
    $local["shsps"] ?: ($local["shsps"] = $yun["shsps"]);
    goto hFJPw;
    kS0oK:
    $local["navbarxzbj"] ?: ($local["navbarxzbj"] = $yun["navbarxzbj"]);
    goto W7nzY;
    L0CEA:
    $local["searchbgbj"] ?: ($local["searchbgbj"] = $yun["searchbgbj"]);
    goto oi67I;
    JtN8c:
    $local["votebtnzt"] ?: ($local["votebtnzt"] = $yun["votebtnzt"]);
    goto ml1xm;
    m_mJH:
    $local["yqmms"] ?: ($local["yqmms"] = $yun["yqmms"]);
    goto kQ8_2;
    XzEE3:
    $local["dbxfxszt"] ?: ($local["dbxfxszt"] = $yun["dbxfxszt"]);
    goto h3NM2;
    JYIeK:
    $local["navbarztl"] ?: ($local["navbarztl"] = $yun["navbarztl"]);
    goto dyEHP;
    wJHSS:
    $local["ybzt"] ?: ($local["ybzt"] = $yun["ybzt"]);
    goto GABzx;
    tUF8v:
    $local["tabzt"] ?: ($local["tabzt"] = $yun["tabzt"]);
    goto YZA7n;
    thR7U:
    $local["zbzt"] ?: ($local["zbzt"] = $yun["zbzt"]);
    goto wJHSS;
    nVweq:
    $local["searchtextbj"] ?: ($local["searchtextbj"] = $yun["searchtextbj"]);
    goto VYFzZ;
    z1lk7:
    $local["navbarzt"] ?: ($local["navbarzt"] = $yun["navbarzt"]);
    goto kS0oK;
    bnoVt:
    $local["xsybj"] ?: ($local["xsybj"] = $yun["xsybj"]);
    goto FhjZr;
    b0TOQ:
    $local["wybmbtnbj"] ?: ($local["wybmbtnbj"] = $yun["wybmbtnbj"]);
    goto QesAP;
    rywu5:
    $local["searchzt"] ?: ($local["searchzt"] = $yun["searchzt"]);
    goto GPuRE;
    n93eF:
    $local["jpjsbj"] ?: ($local["jpjsbj"] = $yun["jpjsbj"]);
    goto fw146;
    VY6Sp:
    $local["viewxspstb"] ?: ($local["viewxspstb"] = $yun["viewxspstb"]);
    goto kKUvw;
    W9exC:
    $local["viewnavbarztyou"] ?: ($local["viewnavbarztyou"] = $yun["viewnavbarztyou"]);
    goto g3ahN;
    SLGA1:
    $local["sybj3"] ?: ($local["sybj3"] = $yun["sybj3"]);
    goto rywu5;
    DzKJi:
    $local["btfzt"] ?: ($local["btfzt"] = $yun["btfzt"]);
    goto AClAv;
    OcJI8:
    $local["xszc"] ?: ($local["xszc"] = $yun["xszc"]);
    goto bnoVt;
    SzhTi:
    $local["tabxzbj"] ?: ($local["tabxzbj"] = $yun["tabxzbj"]);
    goto ymGmx;
    MoYjf:
    $local["giftzt"] ?: ($local["giftzt"] = $yun["giftzt"]);
    goto VWYF7;
    oi67I:
    $local["hdbtbjys"] ?: ($local["hdbtbjys"] = $yun["hdbtbjys"]);
    goto FNftW;
    vWOS7:
    $local["zjbt"] ?: ($local["zjbt"] = $yun["zjbt"]);
    goto GRDTz;
    uGgX7:
    $local["jzgdzt"] ?: ($local["jzgdzt"] = $yun["jzgdzt"]);
    goto GXvgB;
    hFJPw:
    $local["csjlzt"] ?: ($local["csjlzt"] = $yun["csjlzt"]);
    goto MoYjf;
    YZA7n:
    $local["tabbj"] ?: ($local["tabbj"] = $yun["tabbj"]);
    goto SzhTi;
    BLR9f:
    $local["hdbt"] ?: ($local["hdbt"] = $yun["hdbt"]);
    goto uksht;
    Z0jWy:
    $local["rankdbzt"] ?: ($local["rankdbzt"] = $yun["rankdbzt"]);
    goto r5SR4;
    iSODJ:
    $local["dbqyzt"] ?: ($local["dbqyzt"] = $yun["dbqyzt"]);
    goto XzEE3;
    Vjgir:
    $local["navbarbjl"] ?: ($local["navbarbjl"] = $yun["navbarbjl"]);
    goto DcxhA;
    td180:
}