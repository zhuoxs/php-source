<?php

defined('IN_IA') or exit('Access Denied');
define("YPUK_FFYD", "ypuk_ffyd");
require_once IA_ROOT . "/addons/" . YPUK_FFYD . "/dbconfig.class.php";

class Ypuk_ffydModuleProcessor extends WeModuleProcessor {


}
