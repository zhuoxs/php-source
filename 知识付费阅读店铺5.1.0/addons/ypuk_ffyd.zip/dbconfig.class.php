<?php

class DBCONFIG
{

    public static $TABLE_FFYD_ARTICLE = "ypuk_ffyd_article";

    public static $TABLE_FFYD_AUDIO_CONTENT = "ypuk_ffyd_audio_content";

    public static $TABLE_FFYD_PDF_CONTENT = "ypuk_ffyd_pdf_content";

    public static $TABLE_FFYD_VIDEO_CONTENT = "ypuk_ffyd_video_content";

    public static $TABLE_FFYD_TEXT_CONTENT = "ypuk_ffyd_text_content";

    public static $TABLE_FFYD_PIC_CONTENT = "ypuk_ffyd_pic_content";

    public static $TABLE_FFYD_VIPGROUP = "ypuk_ffyd_vipgroup";

    public static $TABLE_FFYD_VIP = "ypuk_ffyd_vip";

    public static $TABLE_FFYD_RECORD = "ypuk_ffyd_record";

    public static $TABLE_FFYD_SETTING = "ypuk_ffyd_setting";

    public static $TABLE_FFYD_FORMID = "ypuk_ffyd_formid";

    public static $TABLE_FFYD_FAVLOG = "ypuk_ffyd_favlog";

    public static $TABLE_FFYD_COMMENT = "ypuk_ffyd_comment";

    public static $TABLE_FFYD_CATEGORY = "ypuk_ffyd_category";

    public static $TABLE_FFYD_PACKAGE = "ypuk_ffyd_package";

    public static $TABLE_FFYD_PACKAGE_BIND = "ypuk_ffyd_package_bind";

    public static $TABLE_FFYD_PACKAGE_RECORD = "ypuk_ffyd_package_record";

    public static $TABLE_FFYD_USERWITHDRAW = "ypuk_ffyd_userwithdraw";

    public static $TABLE_FFYD_DISTRIBUTION = "ypuk_ffyd_distribution";

    public static $TABLE_FFYD_DISTRIBUTION_USERBIND = "ypuk_ffyd_distribution_userbind";

    public static $TABLE_FFYD_PACKAGE_CODE = "ypuk_ffyd_package_code";
}