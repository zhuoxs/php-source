<?php 
$xiaof_config = array();
$xiaof_config['credit'] = array (
  0 => 5,
  1 => 10,
  2 => 20,
  3 => 50,
  4 => 100,
  5 => 200,
);
$xiaof_config['shortcutvote'] = 1;
$xiaof_config['enablemusic'] = 1;
$xiaof_config['enableshare'] = 1;
$xiaof_config['enablefollow'] = 1;
