$(function() {
    'use strict'
    $(document).on('pageInit', "#superpage_join", function(e, id, page) {

    });
});