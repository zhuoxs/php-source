$(function() {
    'use strict'
    $(document).on('pageInit', "#superpage_index", function(e, id, page) {
        fitPlayer();
        function fitPlayer(){
            var list = $('.act-player-list');
            for(var i=0;i<list.length;i++){
                if(i%2 != '0'){
                    $(list[i]).css('margin-left', '4%');
                }
            }
        }

        $(".act-search-input-btn").click(function(){
            var key = $('input[name="key"]').val();
            var url = window.location.href;
            var data = '&key='+key;
            $.ajax({
                url: url,
                dataType: 'json',
                data: data,
                success: function(response) {
                    var str = '', item;
                    for (var i=0; i<response.length; i++) {
                        //查询采取异步加载方式
                        //TODO
                    }
                }
            });
        });

        //导航切换
        $(".act-navigation-title").click(function(){
            $(".act-navigation-title").removeClass('act-navigation-title-active');
            $(".act-navigation-title").removeClass('custom-font-color');
            $(this).addClass('act-navigation-title-active');
            $(this).addClass('custom-font-color');
        });

        //背景音乐
        var audioSrc = $('.back_music').attr('data-audioSrc');
        var isplayer = $('.isplayer').val();
        if(isplayer == '0'){
            $("#media")[0].pause();
            $(".back_music").removeClass("begin_play");
        }
        if (audioSrc != '') {
            wx.ready(function(){
                if ($("#media").attr('autoplay') && isplayer != '0') {
                    $("#media")[0].play();
                }
            });
            $('.back_music').click(function () {
                if ($(this).hasClass("begin_play")) {
                    $("#media")[0].pause();
                    $(this).removeClass("begin_play");
                    changePlayer('0');
                } else {
                    $("#media")[0].play();
                    $(this).addClass("begin_play");
                    changePlayer('1');
                }
                //自动播放关闭默认一天
                if ($("#media").attr('autoplay')) {
                    var cookie_url = $(this).attr('data-cookie-url');
                    $.ajax({
                        url: cookie_url,
                        type: 'post',
                        dataType: 'json',
                        success: function(resp){
                            //不需要执行什么操作
                        }
                    });
                }
            });
            function changePlayer(val) {
                var data = '&val='+val+'&from=changeplayer';
                $.ajax({
                    type: 'post',
                    url: $.xiaof.appUrl("index"),
                    dataType: 'json',
                    data: data,
                    success: function (resp) {
                        console.log(resp);
                    }
                })
            }
            /**
             * 首页查询选手
             *
             * @param loadUrl
             * @param type
             */

            $('.act-search-input-btn').click(function () {
                $.showIndicator();
                var key = $('input[name="key"]').val();
                var data = '&key='+key+'&from=indexajax';
                $.ajax({
                    type: 'post',
                    url: $.xiaof.appUrl("index"),
                    dataType: 'json',
                    data: data,
                    success: function (resp) {
                        //console.log(resp);
                        if(resp.length > '0'){
                            var html = '';
                            for(var i=0;i<resp.length;i++){
                                html +='<div class="act-player-list act-player-list-left">\n' +
                                    '                    <a class="pic-a" href="'+resp[i]['purl']+'">\n' +
                                    '\n' +
                                    '                        <div class="player-photo-item">\n' +
                                    '                            <img class="player-photo" src="'+resp[i]['imgurl']+'" alt=""/>\n' +
                                    '                            <div class="player-uid custom-color">'+resp[i]['uid']+'号</div>\n' +
                                    '                        </div>\n' +
                                    '                    </a>\n' +
                                    '                    <div class="player-name">'+resp[i]['name']+'</div>\n' +
                                    '                    <div class="player-goods custom-font-color">'+resp[i]['good']+'票</div>\n' +
                                    '                    <div class="votes custom-color" data-id="'+resp[i]['id']+'">'+resp[i]['xiaofvotekeys']+'</div>\n' +
                                    '                </div>';
                            }
                            $('.act-player').html(html);
                            $('.show-more').html('点击加载更多...');
                            fitPlayer();
                        }else{
                            $('.act-player').html('');
                            $('.show-more').html('未查询到该选手');
                        }
                        $.hideIndicator();
                    }
                });
            })

            /**
             * 首页ajax加载选手
             *
             * @param loadUrl
             * @param type
             */
            $('.show-more').click(function () {
                $.showIndicator();
                var playerNumNow = $('.act-player-list').length;
                var setNum = $('input[name="setNum"]').val();
                var type = $('input[name="type"]').val();
                var groups = $('input[name="groups"]').val();
                var page = Math.ceil(playerNumNow/setNum);
                page++;

                var data = '&page='+page+'&type='+type+'&groups='+groups+'&from=indexajax';
                $.ajax({
                    type: 'post',
                    url: $.xiaof.appUrl("index"),
                    dataType: 'json',
                    data: data,
                    success: function (resp) {
                        //console.log(resp);
                        if(resp.length > '0'){
                            var html = '';
                            for(var i=0;i<resp.length;i++){
                                html +='<div class="act-player-list act-player-list-left">\n' +
                                    '                    <a class="pic-a" href="'+resp[i]['purl']+'">\n' +
                                    '\n' +
                                    '                        <div class="player-photo-item">\n' +
                                    '                            <img class="player-photo" src="'+resp[i]['imgurl']+'" alt=""/>\n' +
                                    '                            <div class="player-uid custom-color">'+resp[i]['uid']+'号</div>\n' +
                                    '                        </div>\n' +
                                    '                    </a>\n' +
                                    '                    <div class="player-name">'+resp[i]['name']+'</div>\n' +
                                    '                    <div class="player-goods custom-font-color">'+resp[i]['good']+'票</div>\n' +
                                    '                    <div class="votes custom-color" data-id="'+resp[i]['id']+'">'+resp[i]['xiaofvotekeys']+'</div>\n' +
                                    '                </div>';
                            }
                            $('.act-player').append(html);
                            fitPlayer();
                        }else{
                            $('.show-more').html('没有更多了');
                        }
                        $.hideIndicator();
                    }
                });
            })
        }
    });
    $.init();
});