$(function() {
    'use strict'
    $(document).on('pageInit', "#superpage_show", function(e, id, page) {

    });

});