$(function() {
    'use strict'
    $(document).on('pageInit', "#superpage_top", function(e, id, page) {

    });
});