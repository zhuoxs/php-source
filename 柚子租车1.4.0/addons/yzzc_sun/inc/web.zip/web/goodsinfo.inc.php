<?php
global $_GPC, $_W;
$GLOBALS['frames'] = $this->getMainMenu();
$info=pdo_get('yzzc_sun_goods',array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
$nowshop=pdo_get('yzzc_sun_branch',array('id'=>$info['sid']),array('id','name'));
$cartype=pdo_getall('yzzc_sun_cartype',array('uniacid'=>$_W['uniacid']));
$shop=pdo_getall('yzzc_sun_branch',array('uniacid'=>$_W['uniacid']),array('id','name'));
//$sql="SELECT a.*,b.store_name as seller_name FROM ".tablename('chbl_sun_order') .  " a"  . " left join " . tablename("chbl_sun_store") . " b on a.store_id=b.id".$where." ORDER BY a.time DESC";

if(checksubmit('submit')){
//	 p($_GPC);die;
	if($_GPC['name']==null){
		message('请您车辆名称', '', 'error');
	}elseif($_GPC['carnum']==null){
        message('请您填写车牌号码','','error');
    }elseif($_GPC['carnum']==null){
		message('请您写完整汽车租金','','error');
	}elseif($_GPC['pic']==null){
		message('请您写上传图片','','error');die;
	}elseif($_GPC['sid']==null){
        message('请您先添加门店','','error');die;
    }
	$data['uniacid']=$_W['uniacid'];
	$data['sid']=$_GPC['sid'];
	$data['name']=$_GPC['name'];
	$data['carnum']=$_GPC['carnum'];
	$data['colour']=$_GPC['colour'];
	$data['structure']=$_GPC['structure'];
	$data['grarbox']=$_GPC['grarbox'];
	$data['displacement']=$_GPC['displacement'];
	$data['num'] = $_GPC['num'];
//	$data['moneytype'] = $_GPC['moneytype'];
	$data['money'] = $_GPC['money'];
	$data['act_money'] = $_GPC['act_money'];
	$data['cartype'] = $_GPC['cartype'];
	$data['content'] = $_GPC['content'];
	$data['fee'] = $_GPC['fee'];
	$data['service_fee'] = $_GPC['service_fee'];
	$data['zx_service_fee'] = $_GPC['zx_service_fee'];
	$data['hot'] = $_GPC['hot'];
	$data['rec'] = $_GPC['rec'];
	$data['pic'] = $_GPC['pic'];
	$data['createtime'] = date('Y-m-d H:i:s', time());

	if(empty($_GPC['id'])){
		$res = pdo_insert('yzzc_sun_goods', $data,array('uniacid'=>$_W['uniacid']));

		if($res){
			message('添加成功',$this->createWebUrl('goods',array()),'success');
		}else{
			message('添加失败','','error');
		}
	}else{

		$res = pdo_update('yzzc_sun_goods', $data, array('id' => $_GPC['id'],'uniacid'=>$_W['uniacid']));
	}
	if($res){
		message('修改成功',$this->createWebUrl('goods',array()),'success');
	}else{
		message('修改失败','','error');
	}
}
include $this->template('web/goodsinfo');