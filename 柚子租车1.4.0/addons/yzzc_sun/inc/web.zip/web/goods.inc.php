<?php

global $_GPC, $_W;

$GLOBALS['frames'] = $this->getMainMenu();
$where=" WHERE  uniacid=".$_W['uniacid'];
if($_GPC['keywords']){
    $op=$_GPC['keywords'];
    $where.=" and name LIKE  '%$op%'";
    $data[':name']=$op;
}
if($_GPC['status']){
    $where.=" and status={$_GPC['status']} ";

}
if(!empty($_GPC['time'])){
    $start=strtotime($_GPC['time']['start']);
    $end=strtotime($_GPC['time']['end']);
    $where.=" and ime >={$start} and time<={$end}";

}
$states=$_GPC['states'];

$type=isset($_GPC['type'])?$_GPC['type']:'all';
$data[':uniacid']=$_W['uniacid'];
$page = max(1, intval($_GPC['page']));
$size = intval($_GPC['psize']) ? intval($_GPC['psize']) : 10;
$sql = 'SELECT * FROM '.tablename('yzzc_sun_goods')."{$where} ORDER BY id DESC LIMIT ".(($page-1) * $size).','.$size;
$list = pdo_fetchall($sql);
$total=pdo_fetchcolumn("select count(*) from " . tablename("yzzc_sun_goods") .$where);
$pager = pagination($total, $page, $size);
//$total = pdo_fetchcolumn("SELECT COUNT(*) FROM ".tablename('yzzc_sun_goods')." . $where");
//$sql='SELECT * FROM'.tablename('yzzc_sun_goods')."{$where} ORDER BY id DESC LIMIT ".(($page-1) * $size).','.$size;
//$list= pdo_fetchall($sql);

if($_GPC['op']=='delete'){
    $res=pdo_delete('yzzc_sun_goods',array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('删除成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('删除失败！','','error');
    }
}
if($_GPC['op']=='rec2'){
    $res=pdo_update('yzzc_sun_goods',array('rec'=>1),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('推荐成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('推荐失败！','','error');
    }
}
if($_GPC['op']=='rec1'){
    $res=pdo_update('yzzc_sun_goods',array('rec'=>2),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('取消推荐成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('取消推荐失败！','','error');
    }
}
if($_GPC['op']=='hot2'){
    $res=pdo_update('yzzc_sun_goods',array('hot'=>1),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('设置成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('设置失败！','','error');
    }
}
if($_GPC['op']=='hot1'){
    $res=pdo_update('yzzc_sun_goods',array('hot'=>2),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('设置成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('设置失败！','','error');
    }
}
if($_GPC['op']=='xj'){
    $res=pdo_update('yzzc_sun_goods',array('status'=>3),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('下架成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('下架失败！','','error');
    }
}
if($_GPC['op']=='sj'){
    $res=pdo_update('yzzc_sun_goods',array('status'=>1),array('id'=>$_GPC['id'],'uniacid'=>$_W['uniacid']));
    if($res){
        message('上架成功！', $this->createWebUrl('goods'), 'success');
    }else{
        message('上架失败！','','error');
    }
}
include $this->template('web/goods');