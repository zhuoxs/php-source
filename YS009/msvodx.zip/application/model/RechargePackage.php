<?php

namespace app\model;

use think\Model;

class RechargePackage extends Model{


}