<?php
namespace app\model;

use think\Model;

class Atlas extends Model {

}