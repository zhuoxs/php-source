<?php
namespace app\model;

use think\Model;

class Image extends Model {

}