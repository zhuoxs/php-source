<?php
//000000000000
 exit();?>
a:1:{s:5:"zh-cn";a:5:{s:4:"code";s:5:"zh-cn";s:2:"id";i:1;s:4:"name";s:12:"简体中文";s:4:"icon";s:0:"";s:4:"pack";s:1:"1";}}