<?php
//000000000000
 exit();?>
a:1:{i:1;a:5:{s:2:"id";i:1;s:4:"name";s:12:"注册会员";s:8:"discount";i:100;s:9:"min_exper";i:0;s:9:"max_exper";i:0;}}