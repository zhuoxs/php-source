<?php
//000000000000
 exit();?>
a:3:{i:0;s:5:"index";i:1;s:7:"install";i:2;s:5:"route";}