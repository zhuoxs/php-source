


        <textarea class="layui-layer-input" style="width: 500px; height: 200px;"></textarea>
