<div class="layui-collapse page-tips">
  <div class="layui-colla-item">
    <h2 class="layui-colla-title">温馨提示</h2>
    <div class="layui-colla-content">
      <p>此页面为后台数据管理标准模板，您可以直接复制使用修改</p>
    </div>
  </div>
</div>
<div class="layui-form">
</div>