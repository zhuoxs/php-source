{if condition="input('param.hisi_iframe') || cookie('hisi_iframe')"}
</body>
</html>
{else /}
        </div>
    </div>
    <div class="layui-footer footer">
      	<span class="fl" style="color: #ff0072 !important;font-weight: 700 !important;font-size: 16px !important; display:block !important;"> 更多X站模板，百度：YM源码</span>
        <span class="fr"> © 2017-2018 MsvodX All Rights Reserved</span>
    </div>
</div>
</body>
</html>
{/if}