<?php
 function xc_ht_config($bvalue = false) { }