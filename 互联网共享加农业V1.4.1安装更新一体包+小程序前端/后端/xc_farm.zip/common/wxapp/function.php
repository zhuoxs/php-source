<?php
 function htcofnig() { }