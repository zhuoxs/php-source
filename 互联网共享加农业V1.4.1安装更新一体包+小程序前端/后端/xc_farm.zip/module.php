<?php
/**
 * 懒人源码www.lanrenzhijia.com
 */
 defined('IN_IA') or exit('Access Denied'); class xc_farmModule extends WeModule { public function fieldsFormDisplay($rid = 0) { } public function fieldsFormValidate($rid = 0) { return ''; } public function fieldsFormSubmit($rid) { } public function ruleDeleted($rid) { } public function welcomeDisplay() { header('location: ' . $this->createWebUrl('webhome')); } } ?>