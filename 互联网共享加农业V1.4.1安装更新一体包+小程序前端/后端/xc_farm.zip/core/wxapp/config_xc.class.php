<?php
 class config_xc { }