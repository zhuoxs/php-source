<?php
 global $_GPC, $_W; include $this->template("\x73\x65\x6c\145\143\164\137\x71\x72\x63\x6f\144\145");