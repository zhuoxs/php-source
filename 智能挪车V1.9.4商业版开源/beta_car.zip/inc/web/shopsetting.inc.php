<?php
 global $_GPC, $_W; include $this->template("\x77\x65\142\x2f\x73\x68\157\160\x73\145\164\164\151\156\x67");