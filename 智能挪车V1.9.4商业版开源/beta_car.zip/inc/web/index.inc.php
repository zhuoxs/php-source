<?php
 goto xOEyl; cgPKe: header("\x6c\x6f\143\141\x74\x69\x6f\156\72\40" . $this->createWebUrl("\165\x72\154")); goto zCWd3; xOEyl: global $_GPC, $_W; goto cgPKe; zCWd3: exit;